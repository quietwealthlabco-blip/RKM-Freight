/**
 * mailStore: Local mail storage for Inbox, Sent, Drafts, Trash, and custom folders.
 * - Provides CRUD-like helpers and persists to localStorage.
 * - Used to emulate Gmail-like folders with a single-page UI.
 * - Extended: supports user-defined folders with colors (stored under `custom` and `userFolders`).
 */

export type SystemFolder = 'inbox' | 'sent' | 'drafts' | 'trash'
/**
 * MailFolder can be system ('inbox' | 'sent' | 'drafts' | 'trash') or a custom folder key: 'custom:{id}'
 */
export type MailFolder = SystemFolder | `custom:${string}`

/** Attachment meta stored with a mail item */
/**
 * Attachment meta stored with a mail item.
 * - For local attachments, we may include dataBase64 to enable preview/download without API calls.
 * - For Gmail attachments, we include the Gmail messageId and attachment id, and fetch on demand.
 */
export interface MailAttachment {
  /** Display name (with extension) */
  name: string
  /** MIME type hint (e.g., 'application/pdf') */
  type?: string
  /** Size in bytes (optional for display) */
  size?: number
  /** Optional unique id; for Gmail this is the attachmentId */
  id?: string
  /** Source of the attachment (local or gmail) */
  source?: 'local' | 'gmail'
  /** Gmail message id for Gmail attachments */
  messageId?: string
  /** Base64 (standard, not URL-safe) content when stored locally for direct preview/download */
  dataBase64?: string
}

/** Mail item stored in folders */
export interface MailItem {
  id: string
  folder: MailFolder
  from: string
  to: string[]
  subject: string
  /** HTML body */
  bodyHtml: string
  /** Unix timestamp (ms) */
  date: number
  read: boolean
  attachments?: MailAttachment[]
}

/** User-defined folder (custom) */
export interface UserFolder {
  id: string
  name: string
  /** Hex color like '#1a1a38' */
  color: string
}

/** Internal persisted shape */
interface MailStoreData {
  inbox: MailItem[]
  sent: MailItem[]
  drafts: MailItem[]
  trash: MailItem[]
  /** Map of custom folder id -> MailItem[] */
  custom?: Record<string, MailItem[]>
  /** List of user folders metadata */
  userFolders?: UserFolder[]
}

const KEY = 'rkm_mail_v1'

/**
 * Ensure store has required fields for new versions (migration in-place).
 */
function normalizeData(data: any): MailStoreData {
  const out: MailStoreData = {
    inbox: Array.isArray(data?.inbox) ? data.inbox : [],
    sent: Array.isArray(data?.sent) ? data.sent : [],
    drafts: Array.isArray(data?.drafts) ? data.drafts : [],
    trash: Array.isArray(data?.trash) ? data.trash : [],
    custom: data?.custom && typeof data.custom === 'object' ? data.custom : {},
    userFolders: Array.isArray(data?.userFolders) ? data.userFolders : [],
  }
  return out
}

/**
 * Load store from localStorage or seed with demo messages.
 */
function load(): MailStoreData {
  try {
    const raw = localStorage.getItem(KEY)
    if (raw) {
      return normalizeData(JSON.parse(raw))
    }
  } catch {
    // ignore
  }
  const now = Date.now()
  const seed: MailStoreData = {
    inbox: [
      {
        id: crypto.randomUUID(),
        folder: 'inbox',
        from: 'ops@partnerlogix.com',
        to: ['me@rkmfreight.com'],
        subject: 'New lane opportunity: Dallas → Austin',
        bodyHtml: '<p>Hi,</p><p>We have a recurring lane Dallas → Austin, 3x/week.</p><p>Interested?</p><p>– Partner Logix</p>',
        date: now - 1000 * 60 * 60 * 6,
        read: false,
      },
      {
        id: crypto.randomUUID(),
        folder: 'inbox',
        from: 'ap@shipfast.io',
        to: ['me@rkmfreight.com'],
        subject: 'Documents received',
        bodyHtml: '<p>Hello,</p><p>We received the PODs. Payment processing this week.</p><p>— AP</p>',
        date: now - 1000 * 60 * 60 * 24,
        read: true,
      },
    ],
    sent: [
      {
        id: crypto.randomUUID(),
        folder: 'sent',
        from: 'me@rkmfreight.com',
        to: ['sourcing@retailco.com'],
        subject: 'Re: Lane proposal for Q4',
        bodyHtml: '<p>Thanks for the details. Please see attached our Q4 proposal.</p>',
        date: now - 1000 * 60 * 60 * 2,
        read: true,
        attachments: [{ name: 'RKM_Q4_Proposal.pdf', type: 'application/pdf', size: 241172 }],
      },
    ],
    drafts: [],
    trash: [],
    custom: {},
    userFolders: [],
  }
  save(seed)
  return seed
}

/** Save store to localStorage */
function save(data: MailStoreData) {
  try {
    localStorage.setItem(KEY, JSON.stringify(data))
  } catch {
    // ignore quota
  }
}

/** Return a deep copy to avoid external mutation */
function clone<T>(v: T): T {
  return JSON.parse(JSON.stringify(v))
}

/** Check if a folder key is custom and extract id */
function parseCustomKey(folder: MailFolder): { isCustom: boolean; id?: string } {
  if (typeof folder === 'string' && folder.startsWith('custom:')) {
    return { isCustom: true, id: folder.slice('custom:'.length) }
  }
  return { isCustom: false }
}

/** Ensure a custom container array exists */
function ensureCustomContainer(data: MailStoreData, id: string) {
  if (!data.custom) data.custom = {}
  if (!data.custom[id]) data.custom[id] = []
}

/** Get a reference to the array for a given folder (mutable). */
function getFolderArrayRef(data: MailStoreData, folder: MailFolder): MailItem[] {
  const parsed = parseCustomKey(folder)
  if (parsed.isCustom && parsed.id) {
    ensureCustomContainer(data, parsed.id)
    return data.custom![parsed.id]
  }
  return data[folder as SystemFolder] as MailItem[]
}

/** List messages in a folder, sorted by date desc */
export function list(folder: MailFolder): MailItem[] {
  const data = load()
  const arr = clone(getFolderArrayRef(data, folder))
  return arr.sort((a, b) => b.date - a.date)
}

/** Get a single mail by id (search all folders, including custom) */
export function getById(id: string): MailItem | null {
  const data = load()
  const pools: MailItem[][] = [
    data.inbox,
    data.sent,
    data.drafts,
    data.trash,
    ...Object.values(data.custom || {}),
  ]
  for (const arr of pools) {
    const found = arr.find((m) => m.id === id)
    if (found) return clone(found)
  }
  return null
}

/** Mark mail as read/unread by id */
export function setRead(id: string, read: boolean) {
  const data = load()
  const pools: MailItem[][] = [
    data.inbox,
    data.sent,
    data.drafts,
    data.trash,
    ...Object.values(data.custom || {}),
  ]
  let changed = false
  for (const arr of pools) {
    const idx = arr.findIndex((m) => m.id === id)
    if (idx >= 0) {
      arr[idx].read = read
      changed = true
      break
    }
  }
  if (changed) save(data)
}

/** Move mail to a new folder */
export function move(id: string, toFolder: MailFolder) {
  const data = load()
  let moved: MailItem | null = null

  // Remove from system folders
  const sys: SystemFolder[] = ['inbox', 'sent', 'drafts', 'trash']
  for (const f of sys) {
    const idx = data[f].findIndex((m) => m.id === id)
    if (idx >= 0) {
      const [item] = data[f].splice(idx, 1)
      moved = { ...item, folder: toFolder }
      break
    }
  }
  // Remove from custom folders if not found yet
  if (!moved && data.custom) {
    for (const key of Object.keys(data.custom)) {
      const arr = data.custom[key]
      const idx = arr.findIndex((m) => m.id === id)
      if (idx >= 0) {
        const [item] = arr.splice(idx, 1)
        moved = { ...item, folder: toFolder }
        break
      }
    }
  }

  if (moved) {
    getFolderArrayRef(data, toFolder).unshift(moved)
    save(data)
  }
}

/** Permanently delete a mail by id (from its current folder) */
export function removeForever(id: string) {
  const data = load()

  const sys: SystemFolder[] = ['inbox', 'sent', 'drafts', 'trash']
  for (const f of sys) {
    const idx = data[f].findIndex((m) => m.id === id)
    if (idx >= 0) {
      data[f].splice(idx, 1)
      save(data)
      return
    }
  }

  if (data.custom) {
    for (const key of Object.keys(data.custom)) {
      const arr = data.custom[key]
      const idx = arr.findIndex((m) => m.id === id)
      if (idx >= 0) {
        arr.splice(idx, 1)
        save(data)
        return
      }
    }
  }
}

/** Empty trash folder */
export function emptyTrash() {
  const data = load()
  data.trash = []
  save(data)
}

/** Create a draft (new or update existing) */
export function saveDraft(payload: Partial<MailItem>): MailItem {
  const data = load()
  const id = payload.id || crypto.randomUUID()
  const draft: MailItem = {
    id,
    folder: 'drafts',
    from: payload.from || 'me@rkmfreight.com',
    to: Array.isArray(payload.to) ? payload.to : [],
    subject: payload.subject || '',
    bodyHtml: payload.bodyHtml || '',
    date: Date.now(),
    read: true,
    attachments: (payload.attachments || []).map((att: any) => ({
      name: att.name || att.fileName || 'file',
      type: att.type || att.mimeType || 'application/octet-stream',
      size: typeof att.size === 'number' ? att.size : undefined,
      dataBase64: att.dataBase64 || att.content || undefined,
      source: att.source || 'local',
    })),
  }
  const idx = data.drafts.findIndex((d) => d.id === id)
  if (idx >= 0) data.drafts[idx] = draft
  else data.drafts.unshift(draft)
  save(data)
  return clone(draft)
}

/** Add a sent email to Sent folder */
export function addSent(payload: Omit<MailItem, 'id' | 'folder' | 'date' | 'read'>): MailItem {
  const data = load()
  const item: MailItem = {
    id: crypto.randomUUID(),
    folder: 'sent',
    from: payload.from,
    to: payload.to,
    subject: payload.subject,
    bodyHtml: payload.bodyHtml,
    attachments: payload.attachments || [],
    date: Date.now(),
    read: true,
  }
  data.sent.unshift(item)
  save(data)
  return clone(item)
}

/** Soft-delete (move to trash) */
export function deleteToTrash(id: string) {
  move(id, 'trash')
}

/* ==============================
   Inbox upsert helpers
   ============================== */

/**
 * upsertInboxItem: Insert or update an Inbox item by id.
 * - Ensures folder is 'inbox'
 * - Preserves existing attachments unless overridden
 */
export function upsertInboxItem(item: MailItem) {
  const data = load()
  const idx = data.inbox.findIndex((m) => m.id === item.id)
  const normalized: MailItem = { ...item, folder: 'inbox' }
  if (idx >= 0) {
    const prev = data.inbox[idx]
    data.inbox[idx] = { ...prev, ...normalized }
  } else {
    data.inbox.unshift(normalized)
  }
  save(data)
}

/**
 * upsertInbox: Merge a batch of items, newest-first after insertion.
 * @returns number of newly inserted items
 */
export function upsertInbox(items: MailItem[]): number {
  if (!Array.isArray(items) || items.length === 0) return 0
  const data = load()
  let added = 0
  for (const item of items) {
    const idx = data.inbox.findIndex((m) => m.id === item.id)
    const normalized: MailItem = { ...item, folder: 'inbox' }
    if (idx >= 0) {
      const prev = data.inbox[idx]
      data.inbox[idx] = { ...prev, ...normalized }
    } else {
      data.inbox.unshift(normalized)
      added++
    }
  }
  // Keep sorted by date desc
  data.inbox.sort((a, b) => b.date - a.date)
  save(data)
  return added
}

/* ==============================
   Custom folders API
   ============================== */

/** List all user-defined folders */
export function listFolders(): UserFolder[] {
  const data = load()
  return clone(data.userFolders || [])
}

/** Get a folder by id (or null) */
export function getFolderById(id: string): UserFolder | null {
  const data = load()
  const f = (data.userFolders || []).find((x) => x.id === id)
  return f ? clone(f) : null
}

/** Create a new folder with name and color */
export function createFolder(name: string, color: string): UserFolder {
  const data = load()
  const id = crypto.randomUUID()
  const folder: UserFolder = { id, name: name.trim() || 'New Folder', color: color || '#1a1a38' }
  data.userFolders = data.userFolders || []
  data.userFolders.push(folder)
  ensureCustomContainer(data, id)
  save(data)
  return clone(folder)
}

/** Update folder metadata (name and/or color) */
export function updateFolder(id: string, patch: Partial<Pick<UserFolder, 'name' | 'color'>>): UserFolder | null {
  const data = load()
  const idx = (data.userFolders || []).findIndex((f) => f.id === id)
  if (idx < 0) return null
  const current = data.userFolders![idx]
  const next = { ...current, ...patch, name: (patch.name ?? current.name).trim() }
  data.userFolders![idx] = next
  save(data)
  return clone(next)
}

/**
 * Delete a folder.
 * @param id Folder id
 * @param onDelete Where to move messages before removal: 'inbox' | 'trash' (default 'inbox')
 */
export function deleteFolder(id: string, onDelete: 'inbox' | 'trash' = 'inbox') {
  const data = load()
  const arr = (data.userFolders || [])
  const idx = arr.findIndex((f) => f.id === id)
  if (idx < 0) return

  // Move messages out
  const container = data.custom?.[id] || []
  if (container.length) {
    const target = onDelete === 'trash' ? 'trash' : 'inbox'
    for (const item of container) {
      const moved: MailItem = { ...item, folder: target }
      getFolderArrayRef(data, target).unshift(moved)
    }
  }
  // Remove custom container
  if (data.custom && data.custom[id]) {
    delete data.custom[id]
  }
  // Remove metadata
  arr.splice(idx, 1)
  data.userFolders = arr
  save(data)
}
