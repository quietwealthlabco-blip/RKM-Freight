/**
 * syncRules: Store Gmail sync rules locally.
 * - markAsRead: set new synced messages to read
 * - moveToFolderId: if set, move newly synced items to this custom folder (id)
 */

export interface SyncRules {
  markAsRead: boolean
  moveToFolderId: string | null
}

const KEY = 'rkm_sync_rules_v1'

/** Load rules from localStorage or return defaults */
export function getSyncRules(): SyncRules {
  try {
    const raw = localStorage.getItem(KEY)
    if (raw) return JSON.parse(raw) as SyncRules
  } catch {
    // ignore
  }
  return { markAsRead: false, moveToFolderId: null }
}

/** Update and persist rules; returns the new rules */
export function setSyncRules(patch: Partial<SyncRules>): SyncRules {
  const current = getSyncRules()
  const next: SyncRules = {
    markAsRead: patch.markAsRead ?? current.markAsRead,
    moveToFolderId: patch.moveToFolderId === undefined ? current.moveToFolderId : patch.moveToFolderId,
  }
  localStorage.setItem(KEY, JSON.stringify(next))
  return next
}
