/**
 * Email service: Sends email via Google Apps Script Web App if configured.
 * - If not configured, it now returns an explicit failure (no more "mock success"),
 *   so users are not misled when nothing is actually delivered.
 * - Requests are guarded by a QPS limiter and exponential backoff with jitter
 *   (via limitedFetch + appsScriptLimiter) to reduce 429 errors.
 */

import { appsScriptLimiter, limitedFetch } from './network'

export interface EmailAttachment {
  /** File name including extension */
  fileName: string
  /** MIME type like 'application/pdf' */
  mimeType: string
  /** Base64-encoded content (no data: prefix) */
  content: string
}

export interface SendEmailPayload {
  /** Comma-separated list of recipients */
  to: string
  /** Email subject */
  subject: string
  /** HTML body (the Apps Script should treat as HTML) */
  body: string
  /** Optional attachments */
  attachments?: EmailAttachment[]
}

export interface SendEmailResult {
  success: boolean
  message?: string
  error?: string
}

/** Optional overrides for sending */
export interface SendEmailOptions {
  /** Per-user Apps Script Web App URL takes priority if provided */
  appsScriptUrlOverride?: string
}

/**
 * Resolve Apps Script URL from environment.
 * Reads process.env if present (esbuild will replace at build if configured).
 */
function getAppsScriptUrlFromEnv(): string | null {
  try {
    const env = (process as any)?.env ?? {}
    const v = env.VITE_GOOGLE_APPS_SCRIPT_URL || env.GOOGLE_APPS_SCRIPT_URL || null
    return typeof v === 'string' && v.trim() ? v : null
  } catch {
    return null
  }
}

/**
 * sendEmail: Posts to Apps Script when URL is available,
 * otherwise returns a clear error (no silent success).
 *
 * Expected Apps Script behavior:
 *   POST JSON: { action: 'sendEmail', to, subject, body, attachments }
 *   Response JSON: { success: boolean, message?: string, error?: string }
 */
export async function sendEmail(
  payload: SendEmailPayload,
  options?: SendEmailOptions
): Promise<SendEmailResult> {
  const url =
    (options?.appsScriptUrlOverride && options.appsScriptUrlOverride.trim()) ||
    getAppsScriptUrlFromEnv()

  if (!url) {
    // No delivery provider configured for Apps Script.
    // We now fail fast so the UI can inform the user accurately.
    const msg =
      'No Apps Script Web App URL configured. Configure it in Email Settings or connect Gmail.'
    console.warn('[emailService] ' + msg, { payloadSummary: summarizePayload(payload) })
    return { success: false, error: msg }
  }

  try {
    const data = await limitedFetch<any>(
      url,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'sendEmail', ...payload }),
      },
      appsScriptLimiter
    )

    // If limitedFetch returned a Response (non-JSON), adapt it
    if (data && typeof data === 'object' && 'ok' in data && 'status' in data) {
      const res = data as Response
      if (!res.ok) {
        const text = await safeReadText(res)
        return { success: false, error: `HTTP ${res.status}: ${text || 'Request failed'}` }
      }
      // If the Apps Script returns non-JSON 200, treat it as success.
      return { success: true, message: 'Email sent' }
    }

    // JSON path
    return {
      success: data?.success !== false,
      message: data?.message || 'Email sent',
      error: data?.error,
    }
  } catch (err: any) {
    return { success: false, error: String(err?.message || err) }
  }
}

/** Create a concise summary for safe logging */
function summarizePayload(p: SendEmailPayload) {
  const to = (p?.to || '')
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean)
  return {
    toCount: to.length,
    subjectLen: (p?.subject || '').length,
    bodyLen: (p?.body || '').length,
    attCount: p?.attachments?.length || 0,
  }
}

/** safeReadText: Reads response text, swallowing errors */
async function safeReadText(res: Response) {
  try {
    return await res.text()
  } catch {
    return ''
  }
}
