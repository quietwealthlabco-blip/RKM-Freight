/**
 * Distance calculation service
 * - Primary: OpenStreetMap Nominatim geocoding (no API key, browser-friendly)
 * - Fallback: Texas city mock coordinates
 * - Caches geocoding results in localStorage to avoid repeated lookups
 *
 * Exports:
 * - calculateDistanceFromOffice(address, city, state, zipCode): Promise<number>
 * - calculateDistance alias for backward compatibility
 */

interface Coordinates {
  /** Latitude in decimal degrees */
  lat: number
  /** Longitude in decimal degrees */
  lng: number
}

/** Grand Prairie, TX (RKM Freight office) */
const OFFICE_COORDS: Coordinates = { lat: 32.7459, lng: -97.003 }

/** Storage key for simple geocode cache */
const GEO_CACHE_KEY = 'rkm_geo_cache_v1'

/** Load geocode cache from localStorage */
function loadCache(): Record<string, Coordinates> {
  try {
    const raw = localStorage.getItem(GEO_CACHE_KEY)
    return raw ? (JSON.parse(raw) as Record<string, Coordinates>) : {}
  } catch {
    return {}
  }
}

/** Save geocode cache to localStorage */
function saveCache(cache: Record<string, Coordinates>) {
  try {
    localStorage.setItem(GEO_CACHE_KEY, JSON.stringify(cache))
  } catch {
    // ignore quota errors
  }
}

/**
 * Compose a geocoding query from parts.
 * If city/state are missing, use the full address string.
 */
function buildQuery(address: string, city?: string, state?: string, zipCode?: string): string {
  const parts = [address?.trim(), city?.trim(), [state?.trim(), zipCode?.trim()].filter(Boolean).join(' ')].filter(
    Boolean
  ) as string[]
  return parts.join(', ')
}

/** Haversine distance in miles */
function haversineMiles(a: Coordinates, b: Coordinates): number {
  const R = 3958.8
  const dLat = ((b.lat - a.lat) * Math.PI) / 180
  const dLon = ((b.lng - a.lng) * Math.PI) / 180
  const s1 = Math.sin(dLat / 2)
  const s2 = Math.sin(dLon / 2)
  const q = s1 * s1 + Math.cos((a.lat * Math.PI) / 180) * Math.cos((b.lat * Math.PI) / 180) * s2 * s2
  const c = 2 * Math.atan2(Math.sqrt(q), Math.sqrt(1 - q))
  return R * c
}

/** Fallback mock coordinates for common Texas metros (case-insensitive) */
const mockCoordinates: Record<string, Coordinates> = {
  'dallas, tx': { lat: 32.7767, lng: -96.797 },
  'fort worth, tx': { lat: 32.7555, lng: -97.3308 },
  'arlington, tx': { lat: 32.7357, lng: -97.1081 },
  'grand prairie, tx': { lat: 32.7459, lng: -97.003 },
  'houston, tx': { lat: 29.7604, lng: -95.3698 },
  'austin, tx': { lat: 30.2672, lng: -97.7431 },
  'san antonio, tx': { lat: 29.4241, lng: -98.4936 },
}

/**
 * Try geocoding with OSM Nominatim
 * - Uses browser fetch
 * - Rate-limited by OSM, so we also cache
 */
async function geocodeUsingNominatim(query: string): Promise<Coordinates | null> {
  if (!query) return null

  // Check cache first
  const key = query.toLowerCase()
  const cache = loadCache()
  if (cache[key]) return cache[key]

  try {
    const url = `https://nominatim.openstreetmap.org/search?format=json&addressdetails=1&q=${encodeURIComponent(query)}`
    const res = await fetch(url, {
      headers: {
        // The browser sets a proper Referer/User-Agent automatically.
        'Accept-Language': 'en',
      },
    })
    if (!res.ok) return null
    const data: any[] = await res.json()
    if (!Array.isArray(data) || data.length === 0) return null

    const first = data[0]
    const coords: Coordinates = {
      lat: Number(first.lat),
      lng: Number(first.lon),
    }

    cache[key] = coords
    saveCache(cache)
    return coords
  } catch {
    return null
  }
}

/**
 * Geocode address:
 * - Try Nominatim with full query
 * - If fails and we have a recognizable TX city, return mock
 * - Else return null
 */
async function geocodeAddress(address: string, city?: string, state?: string, zipCode?: string): Promise<Coordinates | null> {
  const query = buildQuery(address, city, state, zipCode)

  // Primary: Nominatim
  const nom = await geocodeUsingNominatim(query)
  if (nom) return nom

  // Fallbacks: try a looser query (address only) then mock TX metros
  const looser = await geocodeUsingNominatim(address)
  if (looser) return looser

  const metroKey = [city, state].filter(Boolean).join(', ').toLowerCase()
  if (metroKey && mockCoordinates[metroKey]) return mockCoordinates[metroKey]

  return null
}

/**
 * Calculate distance from RKM Freight office in Grand Prairie, TX.
 * Works even when only Address is provided (no city/state/zip).
 * Returns miles rounded to 1 decimal, or 0 when unable to geocode.
 */
export const calculateDistanceFromOffice = async (
  address: string,
  city?: string,
  state?: string,
  zipCode?: string
): Promise<number> => {
  try {
    const leadCoords = await geocodeAddress(address, city, state, zipCode)
    if (!leadCoords) return 0

    const miles = haversineMiles(OFFICE_COORDS, leadCoords)
    return Math.round(miles * 10) / 10
  } catch {
    return 0
  }
}

// Backward compatibility export name
export { calculateDistanceFromOffice as calculateDistance }
