/**
 * Sheety API service for Leads.
 * Maps Google Sheet headers to internal Lead fields.
 * Extended: numberOfEmployees, jobTitle, industries, keywords.
 */

export interface Lead {
  id?: string
  name: string
  email: string
  phone?: string
  address: string
  company: string
  status: 'New' | 'Contacted' | 'Qualified' | 'Converted' | string
  city?: string
  state?: string
  zipCode?: string
  notes?: string
  distance?: number
  /** Optional: number of employees (parsed to number when possible) */
  numberOfEmployees?: number
  /** Optional: job title for the contact */
  jobTitle?: string
  /** Optional: industries classification */
  industries?: string
  /** Optional: free-form keywords/tags */
  keywords?: string
}

/** Base URL can be overridden via environment; falls back to your provided endpoint */
const BASE_URL =
  (typeof process !== 'undefined' &&
    (process as any).env &&
    (process as any).env.VITE_SHEETY_API_URL) ||
  'https://api.sheety.co/213fd6fc5304489db59ee16c55c8cdd4/rkmEmail/leads'

/**
 * Parse an employee count from mixed string/number (e.g., "200+", "50-100", "approx 80").
 */
function parseEmployees(v: any): number | undefined {
  if (v === null || v === undefined) return undefined
  if (typeof v === 'number' && Number.isFinite(v)) return v
  const s = String(v).trim()
  if (!s) return undefined
  const m = s.replace(/[, ]/g, '').match(/\d{1,7}/)
  if (m) {
    const n = Number(m[0])
    return Number.isFinite(n) ? n : undefined
  }
  return undefined
}

/**
 * Map Sheety record (with keys from sheet) to internal Lead
 */
function mapFromSheety(item: any): Lead {
  const emp =
    item?.numberOfEmployees ??
    item?.employees ??
    item?.headcount ??
    item?.staff ??
    item?.teamSize

  return {
    id: String(item?.id ?? ''),
    name: item?.name ?? '',
    email: item?.email ?? '',
    phone: item?.phoneNumber ?? item?.phone ?? '',
    address: item?.address ?? '',
    company: item?.companyName ?? item?.company ?? '',
    status: item?.status ?? 'New',
    // Optional fields absent in your sheet
    city: item?.city ?? '',
    state: item?.state ?? '',
    zipCode: item?.zipCode ?? '',
    notes: item?.notes ?? '',
    // New fields
    numberOfEmployees: parseEmployees(emp),
    jobTitle: item?.jobTitle ?? item?.title ?? item?.role ?? '',
    industries: item?.industries ?? item?.industry ?? '',
    keywords: item?.keywords ?? item?.tags ?? '',
  }
}

/**
 * Map internal Lead to Sheety payload shape.
 * Sheety expects body key matching singular sheet name: { lead: {...} }
 */
function mapToSheetyPayload(lead: Lead) {
  return {
    lead: {
      name: lead.name,
      email: lead.email,
      phoneNumber: lead.phone ?? '',
      address: lead.address,
      companyName: lead.company,
      status: lead.status || 'New',
      // Preserve optional data even if not present in sheet (Sheety will ignore unknown columns)
      city: lead.city ?? '',
      state: lead.state ?? '',
      zipCode: lead.zipCode ?? '',
      notes: lead.notes ?? '',
      // New fields
      numberOfEmployees: lead.numberOfEmployees ?? '',
      jobTitle: lead.jobTitle ?? '',
      industries: lead.industries ?? '',
      keywords: lead.keywords ?? '',
    },
  }
}

/**
 * getLeads: Fetch all leads
 */
export async function getLeads(): Promise<Lead[]> {
  const res = await fetch(BASE_URL)
  if (!res.ok) throw new Error('Failed to fetch leads')
  const data = await res.json()
  const list: any[] = data?.leads || []
  return list.map(mapFromSheety)
}

/**
 * createLead: Add a new lead
 */
export async function createLead(lead: Lead): Promise<Lead> {
  const res = await fetch(BASE_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(mapToSheetyPayload(lead)),
  })
  if (!res.ok) throw new Error('Failed to create lead')
  const data = await res.json()
  return mapFromSheety(data?.lead || {})
}

/**
 * updateLead: Update existing lead by id
 */
export async function updateLead(id: string, lead: Lead): Promise<Lead> {
  const url = `${BASE_URL}/${id}`
  const res = await fetch(url, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(mapToSheetyPayload(lead)),
  })
  if (!res.ok) throw new Error('Failed to update lead')
  const data = await res.json()
  return mapFromSheety(data?.lead || {})
}

/**
 * deleteLead: Remove lead by id
 */
export async function deleteLead(id: string): Promise<void> {
  const url = `${BASE_URL}/${id}`
  const res = await fetch(url, { method: 'DELETE' })
  if (!res.ok) throw new Error('Failed to delete lead')
}
