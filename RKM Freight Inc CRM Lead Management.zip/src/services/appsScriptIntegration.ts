/**
 * Apps Script integration helpers:
 * - syncInboxViaAppsScript: POST to your Web App doPost(action=syncInbox) with form-encoded body
 * - Protected with QPS limit + exponential backoff for 429/5xx handling
 * - Debounced to coalesce bursts caused by rapid UI triggers
 */

import { appsScriptLimiter, createDebouncedAsync, limitedFetch } from './network'

export interface SyncInboxOptions {
  appsScriptUrl: string
  sheetyEmailsUrl: string
  sheetyToken?: string
  /** Gmail query, e.g., 'newer_than:7d label:inbox' */
  query?: string
  /** Limit threads/messages processed by the Apps Script */
  max?: number
}

/** Build x-www-form-urlencoded body */
function toFormBody(params: Record<string, string | number | undefined>): string {
  const usp = new URLSearchParams()
  Object.entries(params).forEach(([k, v]) => {
    if (v === undefined || v === null) return
    usp.append(k, String(v))
  })
  return usp.toString()
}

/**
 * Internal: actual POST call with limiter + backoff.
 */
async function doSyncInbox(opts: SyncInboxOptions): Promise<{
  success: boolean
  inserted?: number
  failures?: number
  scannedThreads?: number
  error?: string
}> {
  const body = toFormBody({
    action: 'syncInbox',
    sheetUrl: opts.sheetyEmailsUrl,
    sheetToken: opts.sheetyToken,
    query: opts.query,
    max: typeof opts.max === 'number' ? opts.max : undefined,
  })

  return limitedFetch(
    opts.appsScriptUrl,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body,
    },
    appsScriptLimiter
  )
}

/**
 * Debounced wrapper: multiple calls within 2s collapse into one network call (shared promise).
 * - Keyed by Apps Script URL so different environments don't interfere.
 */
const debouncers = new Map<string, (o: SyncInboxOptions) => Promise<any>>()

/**
 * Call Apps Script doPost with action=syncInbox (debounced + rate-limited + backoff).
 */
export async function syncInboxViaAppsScript(
  opts: SyncInboxOptions
): Promise<{ success: boolean; inserted?: number; failures?: number; scannedThreads?: number; error?: string }> {
  const key = opts.appsScriptUrl
  if (!debouncers.has(key)) {
    debouncers.set(
      key,
      createDebouncedAsync((o: SyncInboxOptions) => doSyncInbox(o), 2000) // 2s debounce
    )
  }
  const fn = debouncers.get(key)!
  const result = await fn(opts)
  return result || { success: true }
}
