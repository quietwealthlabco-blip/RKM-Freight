/**
 * Networking helpers:
 * - QPS limiter to prevent request bursts (simple queue).
 * - Exponential backoff with jitter for 429/5xx and transient failures.
 * - Thin wrappers for fetch and gapi calls to apply both behaviors.
 *
 * Keep it dependency-free to avoid extra bundle weight.
 */

export type BackoffShouldRetry = (err: unknown, response?: Response | any) => boolean

/** Options for exponential backoff */
export interface BackoffOptions {
  /** Max attempts (initial try + retries), default 5 */
  maxAttempts?: number
  /** Initial delay in ms, default 400 */
  initialDelayMs?: number
  /** Max delay in ms, default 10_000 */
  maxDelayMs?: number
  /** Growth factor, default 2 */
  factor?: number
  /** Add full jitter, default true */
  jitter?: boolean
  /** Optional predicate to decide retry, default: 429/5xx or Google rateLimit errors */
  shouldRetry?: BackoffShouldRetry
}

/**
 * Default retry predicate:
 * - HTTP 429 or 5xx
 * - gapi error structures containing rate limit signals: userRateLimitExceeded, rateLimitExceeded
 */
export function defaultShouldRetry(err: unknown, response?: Response | any): boolean {
  // Fetch Response case
  if (response && typeof response === 'object' && 'status' in response) {
    const res = response as Response
    if (res.status === 429) return true
    if (res.status >= 500) return true
  }

  // gapi error case: err or response may carry details
  const payload = (response && response.result) || response || err
  const asText = typeof payload === 'string' ? payload : JSON.stringify(payload || {})
  return /\b(userRateLimitExceeded|rateLimitExceeded|backendError|internalError)\b/i.test(asText)
}

/**
 * Exponential backoff with full jitter.
 * - Attempts the provided task; if it throws or returns a retriable state, retries.
 */
export async function withBackoff<T>(
  task: () => Promise<T>,
  opts: BackoffOptions = {}
): Promise<T> {
  const {
    maxAttempts = 5,
    initialDelayMs = 400,
    maxDelayMs = 10_000,
    factor = 2,
    jitter = true,
    shouldRetry = defaultShouldRetry,
  } = opts

  let attempt = 0
  let delay = initialDelayMs

  // eslint-disable-next-line no-constant-condition
  while (true) {
    attempt++
    try {
      const result = await task()
      // Allow task to surface a "response" to be evaluated if needed
      if (result && (result as any).__rawResponse) {
        const res = (result as any).__rawResponse
        if (shouldRetry(null, res) && attempt < maxAttempts) {
          throw { __forceRetry: true, res }
        }
      }
      return result
    } catch (e: any) {
      const retriable = shouldRetry(e, e?.res)
      if (!retriable || attempt >= maxAttempts) throw e

      const capped = Math.min(delay, maxDelayMs)
      const wait = jitter ? Math.random() * capped : capped
      await new Promise((r) => setTimeout(r, wait))
      delay = Math.min(delay * factor, maxDelayMs)
    }
  }
}

/**
 * Very small QPS limiter: ensures spacing between tasks.
 * - Example: qps=2 ⇒ at least 500ms between starts.
 */
export class QpsLimiter {
  private readonly intervalMs: number
  private nextAvailable = 0
  private queue: Array<() => void> = []

  constructor(qps = 2) {
    this.intervalMs = Math.max(1, Math.floor(1000 / Math.max(1, qps)))
  }

  /** Schedule a function for execution adhering to QPS */
  schedule<T>(fn: () => Promise<T>): Promise<T> {
    return new Promise<T>((resolve, reject) => {
      const run = async () => {
        const now = Date.now()
        const startAt = Math.max(this.nextAvailable, now)
        const delay = startAt - now
        this.nextAvailable = startAt + this.intervalMs

        setTimeout(async () => {
          try {
            resolve(await fn())
          } catch (e) {
            reject(e)
          } finally {
            // Dequeue next if present
            const next = this.queue.shift()
            if (next) next()
          }
        }, delay)
      }

      if (this.queue.length === 0) {
        this.queue.push(run)
        run()
      } else {
        this.queue.push(run)
      }
    })
  }
}

/** Global limiters (tune as needed) */
export const gmailLimiter = new QpsLimiter(2)        // ~2 QPS for Gmail API
export const appsScriptLimiter = new QpsLimiter(1)   // ~1 QPS for Apps Script web app

/**
 * Wrap fetch with limiter + backoff. Returns the parsed JSON if possible,
 * or the Response if no JSON body is present.
 */
export async function limitedFetch<T = any>(
  input: RequestInfo | URL,
  init: RequestInit,
  limiter: QpsLimiter = gmailLimiter,
  backoffOpts: BackoffOptions = {}
): Promise<T> {
  return limiter.schedule(() =>
    withBackoff(async () => {
      const res = await fetch(input, init)
      // Mark raw response for retry predicate
      const clone = res.clone()
      // If retryable, bubble up so withBackoff retries
      if (defaultShouldRetry(null, clone)) {
        // create a special marker for withBackoff to interpret
        return { __rawResponse: clone } as any
      }
      let data: any = null
      try {
        data = await res.json()
      } catch {
        // non-JSON payload; return ok/Response-like info
        return (res as unknown) as T
      }
      if (!res.ok) {
        const error = new Error(
          (data && (data.error || data.message)) || `HTTP ${res.status}`
        )
        ;(error as any).data = data
        throw error
      }
      return data as T
    }, backoffOpts)
  )
}

/**
 * Wrap a gapi request with limiter + backoff.
 * Pass a function that executes an authenticated gapi call.
 */
export async function limitedGapi<T>(
  call: () => Promise<T>,
  limiter: QpsLimiter = gmailLimiter,
  backoffOpts: BackoffOptions = {}
): Promise<T> {
  return limiter.schedule(() => withBackoff(call, backoffOpts))
}

/**
 * Create a debounced async function that returns one shared promise for calls
 * within the debounce window. Useful to coalesce repeated sync triggers.
 */
export function createDebouncedAsync<F extends (...args: any[]) => Promise<any>>(
  fn: F,
  waitMs: number
): F {
  let timer: any = null
  let pending: Promise<any> | null = null
  let lastArgs: any[] = []

  const wrapped = ((...args: any[]) => {
    lastArgs = args
    if (timer) clearTimeout(timer)
    if (!pending) {
      pending = new Promise((resolve, reject) => {
        timer = setTimeout(async () => {
          timer = null
          try {
            const res = await fn(...(lastArgs as any))
            resolve(res)
          } catch (e) {
            reject(e)
          } finally {
            pending = null
          }
        }, waitMs)
      })
    } else {
      // A call is already pending; just return it.
    }
    return pending!
  }) as F

  return wrapped
}
