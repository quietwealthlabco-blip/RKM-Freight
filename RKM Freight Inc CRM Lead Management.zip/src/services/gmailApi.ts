/**
 * Gmail API client using Google Identity Services (GIS) + gapi client.
 * - Uses a QPS limiter and exponential backoff to avoid 429/userRateLimitExceeded.
 * - Loads gapi client for Gmail discovery and sets the access token from GIS.
 * - Provides sendViaGmail (HTML + attachments), and helpers to connect/disconnect/check status.
 *
 * Public API:
 *   sendViaGmail({ clientId, to, subject, html, attachments, from })
 *   connectGmail(clientId)
 *   disconnectGmail()
 *   isGmailSignedIn(clientId)
 *   getSignedInEmail(clientId)
 *
 * Added:
 *   fetchGmailInbox(clientId, query, maxResults) -> MailItem[]
 *     - Fetches recent inbox messages as normalized MailItem[] for local store
 */

import { limitedGapi } from './network'
import type { MailItem, MailAttachment } from './mailStore'

declare global {
  interface Window {
    gapi?: any
    google?: any
  }
}

/** Attachment shape compatible with ComposeEmailPanel */
export interface GmailAttachment {
  /** File name including extension */
  fileName: string
  /** MIME type like 'application/pdf' */
  mimeType: string
  /** Base64 content (no data: prefix) */
  content: string
}

/** Parameters for sending a message via Gmail API */
export interface GmailSendParams {
  /** Google OAuth Client ID (Web application) */
  clientId: string
  /** Comma-separated recipients */
  to: string
  /** Subject text */
  subject: string
  /** HTML body */
  html: string
  /** Optional attachments (base64) */
  attachments?: GmailAttachment[]
  /** Optional From (header). Gmail will send as the authenticated user */
  from?: string
}

/** Gmail discovery doc endpoint */
const DISCOVERY_DOC = 'https://www.googleapis.com/discovery/v1/apis/gmail/v1/rest'
/** Scopes: gmail.send for sending; email so we can show the account email in Settings
 * For inbox fetch we rely on the same token; if you prefer more granular scopes we can extend.
 */
const OAUTH_SCOPES = 'https://www.googleapis.com/auth/gmail.readonly https://www.googleapis.com/auth/gmail.send email'

/** Internal singleton state */
let gapiClientPromise: Promise<void> | null = null
let discoveryLoadedPromise: Promise<void> | null = null
let gisLoadPromise: Promise<void> | null = null
let tokenClientById: Record<string, any> = {}

/** Current token cache */
interface TokenInfo {
  accessToken: string
  /** ms timestamp when token expires */
  expiresAt: number
  clientId: string
}
let currentToken: TokenInfo | null = null

/**
 * Load the Google API client (no auth2).
 */
function ensureGapiClient(): Promise<void> {
  if (window.gapi?.client) return Promise.resolve()
  if (gapiClientPromise) return gapiClientPromise

  gapiClientPromise = new Promise<void>((resolve, reject) => {
    const script = document.createElement('script')
    script.src = 'https://apis.google.com/js/api.js'
    script.async = true
    script.defer = true
    script.onload = () => {
      try {
        window.gapi.load('client', async () => {
          try {
            resolve()
          } catch (err) {
            reject(err)
          }
        })
      } catch (err) {
        reject(err)
      }
    }
    script.onerror = () => reject(new Error('Failed to load gapi client script'))
    document.head.appendChild(script)
  })

  return gapiClientPromise
}

/**
 * Load Gmail discovery doc (only once).
 */
async function ensureDiscoveryLoaded(): Promise<void> {
  await ensureGapiClient()
  if (discoveryLoadedPromise) return discoveryLoadedPromise
  discoveryLoadedPromise = window.gapi.client.init({ discoveryDocs: [DISCOVERY_DOC] }).then(() => {})
  return discoveryLoadedPromise
}

/**
 * Load Google Identity Services script (GIS).
 */
function ensureGisLoaded(): Promise<void> {
  if (window.google?.accounts?.oauth2) return Promise.resolve()
  if (gisLoadPromise) return gisLoadPromise
  gisLoadPromise = new Promise<void>((resolve, reject) => {
    const script = document.createElement('script')
    script.src = 'https://accounts.google.com/gsi/client'
    script.async = true
    script.defer = true
    script.onload = () => resolve()
    script.onerror = () => reject(new Error('Failed to load Google Identity Services script'))
    document.head.appendChild(script)
  })
  return gisLoadPromise
}

/**
 * True if a valid token exists for this clientId.
 */
function hasValidToken(clientId: string): boolean {
  if (!currentToken) return false
  if (currentToken.clientId !== clientId) return false
  const now = Date.now()
  return now < currentToken.expiresAt - 5_000 // 5s safety
}

/**
 * Request an access token via GIS. If prompt is 'consent', forces account chooser/consent UI.
 */
async function requestAccessToken(clientId: string, prompt: '' | 'consent' = ''): Promise<void> {
  await ensureGisLoaded()

  if (!tokenClientById[clientId]) {
    tokenClientById[clientId] = window.google.accounts.oauth2.initTokenClient({
      client_id: clientId,
      scope: OAUTH_SCOPES,
      callback: (resp: any) => {
        // callback handled below via a Promise wrapper
      },
    })
  }

  const tokenClient = tokenClientById[clientId]

  // Wrap the callback in a Promise for flow control
  await new Promise<void>((resolve, reject) => {
    tokenClient.callback = (resp: any) => {
      try {
        if (resp?.error) {
          reject(new Error(resp.error_description || resp.error || 'Token error'))
          return
        }
        const accessToken = resp?.access_token
        const expiresIn = Number(resp?.expires_in || 3600)
        if (!accessToken) {
          reject(new Error('No access token received'))
          return
        }
        currentToken = {
          accessToken,
          expiresAt: Date.now() + expiresIn * 1000,
          clientId,
        }
        // Pass the token to gapi client for authenticated requests
        window.gapi.client.setToken({ access_token: accessToken })
        resolve()
      } catch (e) {
        reject(e)
      }
    }

    try {
      tokenClient.requestAccessToken({ prompt })
    } catch (e) {
      reject(e)
    }
  })
}

/**
 * Ensure we have a valid token for the given clientId, requesting it if needed.
 */
async function ensureToken(clientId: string, forceConsent = false): Promise<void> {
  if (hasValidToken(clientId) && !forceConsent) return
  await requestAccessToken(clientId, forceConsent ? 'consent' : '')
}

/**
 * Build a MIME message supporting HTML body + multiple attachments.
 * Returns a base64url string ready for Gmail API.
 */
function buildMimeMessage(params: {
  from?: string
  to: string
  subject: string
  html: string
  attachments?: GmailAttachment[]
}): string {
  const boundary = 'mixed_' + Math.random().toString(36).slice(2)
  const lines: string[] = []

  // Headers
  lines.push(`Content-Type: multipart/mixed; boundary="${boundary}"`)
  lines.push('MIME-Version: 1.0')
  lines.push(`to: ${params.to}`)
  if (params.from) lines.push(`from: ${params.from}`)
  lines.push(`subject: ${params.subject}`)
  lines.push('') // blank line

  // HTML part
  lines.push(`--${boundary}`)
  lines.push('Content-Type: text/html; charset="UTF-8"')
  lines.push('MIME-Version: 1.0')
  lines.push('Content-Transfer-Encoding: 7bit')
  lines.push('')
  lines.push(params.html || '')

  // Attachments
  const atts = params.attachments || []
  for (const att of atts) {
    lines.push('')
    lines.push(`--${boundary}`)
    lines.push(
      `Content-Type: ${att.mimeType || 'application/octet-stream'}; name="${sanitizeHeader(
        att.fileName || 'file'
      )}"`
    )
    lines.push('MIME-Version: 1.0')
    lines.push('Content-Transfer-Encoding: base64')
    lines.push(
      `Content-Disposition: attachment; filename="${sanitizeHeader(att.fileName || 'file')}"`
    )
    lines.push('')
    lines.push(chunkBase64(att.content, 76))
  }

  // End boundary
  lines.push('')
  lines.push(`--${boundary}--`)

  const mime = lines.join('\r\n')
  const base64 = base64EncodeUtf8(mime)
  return toBase64Url(base64)
}

/** Escape CRLF and quotes in headers (basic sanitize) */
function sanitizeHeader(s: string): string {
  return s.replace(/[\r\n"]/g, '_')
}

/** Convert a base64 string to base64url */
function toBase64Url(b64: string): string {
  return b64.replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '')
}

/** Chunk a base64 string into fixed-length lines */
function chunkBase64(b64: string, size = 76): string {
  return b64.replace(new RegExp(`(.{${size}})`, 'g'), '$1\r\n')
}

/** Base64-encode UTF-8 text safely in browsers */
function base64EncodeUtf8(text: string): string {
  // encodeURIComponent -> percent-encode -> convert to raw string -> btoa
  return btoa(unescape(encodeURIComponent(text)))
}

/**
 * Send via Gmail API using GIS access token.
 * - Ensures gapi client + discovery loaded
 * - Ensures access token (requests if needed)
 * - Builds MIME and calls gmail.users.messages.send
 * - Protected by QPS limiter and exponential backoff (handles 429/5xx)
 */
export async function sendViaGmail(params: GmailSendParams): Promise<{ id?: string }> {
  await ensureDiscoveryLoaded()
  await ensureToken(params.clientId)

  const raw = buildMimeMessage({
    from: params.from,
    to: params.to,
    subject: params.subject,
    html: params.html,
    attachments: params.attachments,
  })

  const res = await limitedGapi(async () => {
    const r = await window.gapi.client.gmail.users.messages.send({
      userId: 'me',
      resource: { raw },
    })
    return r
  })

  const id = (res as any)?.result?.id
  return { id }
}

/**
 * Trigger OAuth token acquisition with user consent UI.
 * Use this from Settings' "Connect Gmail" button.
 */
export async function connectGmail(clientId: string): Promise<void> {
  await ensureDiscoveryLoaded()
  await ensureToken(clientId, /* forceConsent */ true)
}

/**
 * Revoke token via GIS and clear cached token.
 */
export async function disconnectGmail(): Promise<void> {
  try {
    await ensureGisLoaded()
    const token = currentToken?.accessToken
    if (token && window.google?.accounts?.oauth2?.revoke) {
      await new Promise<void>((resolve) => {
        window.google.accounts.oauth2.revoke(token, () => resolve())
      })
    }
  } finally {
    currentToken = null
    // Clear gapi client token as well
    if (window.gapi?.client?.setToken) {
      window.gapi.client.setToken(null)
    }
  }
}

/**
 * Returns true if we currently hold a valid (non-expired) token for this clientId.
 */
export async function isGmailSignedIn(clientId: string): Promise<boolean> {
  await ensureGisLoaded()
  return hasValidToken(clientId)
}

/**
 * Try to obtain the user's email.
 * - We requested 'email' scope, so fetch userinfo.
 */
export async function getSignedInEmail(clientId: string): Promise<string | null> {
  if (!hasValidToken(clientId)) return null
  try {
    const token = currentToken!.accessToken
    const resp = await fetch('https://www.googleapis.com/oauth2/v2/userinfo', {
      headers: { Authorization: `Bearer ${token}` },
    })
    if (!resp.ok) return null
    const data = await resp.json()
    return (data?.email as string) || null
  } catch {
    return null
  }
}

/* ==============================
   Inbox fetching (new)
   ============================== */

/**
 * Convert base64url -> standard base64 string.
 */
function base64UrlToBase64(u: string): string {
  const b = u.replace(/-/g, '+').replace(/_/g, '/')
  const pad = b.length % 4
  return pad ? b + '='.repeat(4 - pad) : b
}

/**
 * fetchGmailAttachment: Download attachment content for a Gmail message.
 * - Returns standard base64 data. Caller can create a Blob for preview/download.
 */
export async function fetchGmailAttachment(
  clientId: string,
  messageId: string,
  attachmentId: string
): Promise<{ dataBase64: string }> {
  await ensureDiscoveryLoaded()
  await ensureToken(clientId)

  const resp = await limitedGapi(async () => {
    const r = await window.gapi.client.gmail.users.messages.attachments.get({
      userId: 'me',
      messageId,
      id: attachmentId,
    })
    return r
  })

  const dataUrlSafe = (resp as any)?.result?.data as string | undefined
  if (!dataUrlSafe) throw new Error('No attachment data returned')
  return { dataBase64: base64UrlToBase64(dataUrlSafe) }
}

/**
 * Extract attachment metadata from a Gmail message payload recursively.
 * - Collects filename, mimeType, size, and Gmail attachmentId.
 * - Does NOT download content; used to render list in the UI.
 */
function listGmailAttachments(payload: any, messageId: string): MailAttachment[] {
  const out: MailAttachment[] = []
  if (!payload) return out

  const stack: any[] = [payload]
  while (stack.length) {
    const part = stack.pop()
    if (!part) continue

    const filename = part.filename || ''
    // An attachment part typically has a filename and an attachmentId in body
    if (filename && part.body && part.body.attachmentId) {
      out.push({
        name: filename,
        type: part.mimeType || 'application/octet-stream',
        size: typeof part.body.size === 'number' ? part.body.size : undefined,
        id: part.body.attachmentId,
        source: 'gmail',
        messageId,
      })
    }

    if (Array.isArray(part.parts)) {
      for (const p of part.parts) stack.push(p)
    }
  }

  return out
}
/**
 * fetchGmailInbox: Fetch recent inbox messages via Gmail API and normalize to MailItem[].
 * - Uses the current OAuth token (must be connected).
 * - Respects the provided Gmail query (e.g., "in:inbox newer_than:7d -from:me").
 * - maxResults: number of messages to pull per sync tick (small is safer to avoid quotas).
 */
export async function fetchGmailInbox(
  clientId: string,
  query: string,
  maxResults: number
): Promise<MailItem[]> {
  await ensureDiscoveryLoaded()
  await ensureToken(clientId)

  // 1) List message ids
  const listResp = await limitedGapi(async () => {
    const r = await window.gapi.client.gmail.users.messages.list({
      userId: 'me',
      q: query || 'in:inbox newer_than:7d -from:me',
      maxResults: Math.max(1, Math.min(maxResults || 25, 100)),
    })
    return r
  })

  const messageRefs = ((listResp as any)?.result?.messages as Array<{ id: string; threadId: string }>) || []
  if (!messageRefs.length) return []

  // 2) Fetch each message details (format 'full' to get headers/payload)
  const items: MailItem[] = []
  for (const m of messageRefs) {
    try {
      const msgResp = await limitedGapi(async () => {
        const r = await window.gapi.client.gmail.users.messages.get({
          userId: 'me',
          id: m.id,
          format: 'full',
        })
        return r
      })
      const result = (msgResp as any)?.result
      if (!result) continue

      const headers = headerMap(result?.payload?.headers || [])
      const subject = headers.get('subject') || '(No subject)'
      const from = headers.get('from') || ''
      const to = headers.get('to') || ''

      const fromEmail = extractEmails(from)[0] || from || 'unknown'
      const toEmails = extractEmails(to)
      const dateTs = parseDate(headers.get('date'))

      const html = extractHtmlBody(result?.payload) || wrapPlain(result?.snippet || '')

      const unread = Array.isArray(result?.labelIds) && result.labelIds.includes('UNREAD')

      const attachments = listGmailAttachments(result?.payload, String(result.id))

      const item: MailItem = {
        id: String(result.id), // use Gmail message id for stable dedupe
        folder: 'inbox',
        from: fromEmail,
        to: toEmails.length ? toEmails : ['me@rkmfreight.com'],
        subject,
        bodyHtml: html,
        date: dateTs || Date.now(),
        read: !unread,
        attachments: attachments.length ? attachments : undefined,
      }
      items.push(item)
    } catch {
      // ignore individual message fetch errors to keep sync resilient
    }
  }

  // Sort newest first
  items.sort((a, b) => b.date - a.date)
  return items
}

/** Convert header array to Map for quick access (lowercased keys) */
function headerMap(headers: Array<{ name: string; value: string }>): Map<string, string> {
  const map = new Map<string, string>()
  for (const h of headers || []) {
    if (!h?.name) continue
    map.set(h.name.toLowerCase(), h.value || '')
  }
  return map
}

/** Extract first-class HTML body from Gmail payload; fallback to text/plain if needed. */
function extractHtmlBody(payload: any): string {
  if (!payload) return ''
  // Single part with body.data
  if (payload.mimeType === 'text/html' && payload.body?.data) {
    return decodeBase64UrlToUtf8(payload.body.data)
  }
  if (payload.mimeType === 'text/plain' && payload.body?.data) {
    const text = decodeBase64UrlToUtf8(payload.body.data)
    return wrapPlain(text)
  }
  // Multipart tree
  const stack = [...(payload.parts || [])]
  while (stack.length) {
    const part = stack.shift()
    if (!part) continue
    if (part.mimeType === 'text/html' && part.body?.data) {
      return decodeBase64UrlToUtf8(part.body.data)
    }
    if (part.parts?.length) stack.push(...part.parts)
    // Save text/plain in case we never find HTML
    if (part.mimeType === 'text/plain' && part.body?.data) {
      const text = decodeBase64UrlToUtf8(part.body.data)
      // Keep last seen text/plain as fallback
      var lastPlain = text
    }
  }
  return typeof (lastPlain as any) === 'string' ? wrapPlain(lastPlain as any) : ''
}

/** Decode base64url -> UTF-8 string */
function decodeBase64UrlToUtf8(data: string): string {
  try {
    const b64 = data.replace(/-/g, '+').replace(/_/g, '/')
    // pad
    const pad = b64.length % 4
    const padded = pad ? b64 + '='.repeat(4 - pad) : b64
    const binStr = atob(padded)
    // decode UTF-8
    const bytes = Uint8Array.from(binStr, (c) => c.charCodeAt(0))
    const dec = new TextDecoder('utf-8')
    return dec.decode(bytes)
  } catch {
    try {
      return atob(data)
    } catch {
      return ''
    }
  }
}

/** Wrap plain text as minimal HTML with preserved line breaks */
function wrapPlain(text: string): string {
  if (!text) return ''
  const safe = escapeHtml(text).replace(/\r?\n/g, '<br/>')
  return `<div>${safe}</div>`
}

/** Very small HTML escape */
function escapeHtml(s: string): string {
  return s
    .replace(/&/g, '&')
    .replace(/</g, '<')
    .replace(/>/g, '>')
}

/** Extract emails from header values like: "John Doe <john@x.com>, jane@x.com" */
function extractEmails(s: string): string[] {
  if (!s) return []
  const emails: string[] = []
  // split on commas not inside quotes (basic approach)
  const parts = s.split(',')
  for (const p of parts) {
    const m = p.match(/<([^>]+)>/)
    if (m && m[1]) {
      emails.push(m[1].trim().toLowerCase())
      continue
    }
    // fallback raw email
    const m2 = p.match(/([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})/)
    if (m2 && m2[1]) emails.push(m2[1].trim().toLowerCase())
  }
  // unique
  return Array.from(new Set(emails))
}

/** Parse Date header into ms timestamp */
function parseDate(s?: string | null): number {
  if (!s) return Date.now()
  const t = Date.parse(s)
  return Number.isFinite(t) ? t : Date.now()
}
