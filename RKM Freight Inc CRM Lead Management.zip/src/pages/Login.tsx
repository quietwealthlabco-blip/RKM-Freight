/**
 * Login page with Reset Password modal.
 * - Demo auth via AuthContext (localStorage)
 * - Adds self-service Reset Password on the login screen
 */

import React, { useState } from 'react'
import { useNavigate } from 'react-router'
import { useAuth } from '../contexts/AuthContext'
import { Button } from '../components/ui/button'
import { Input } from '../components/ui/input'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card'
import { LogIn, Mail, Lock, KeyRound } from 'lucide-react'
import { Label } from '../components/ui/label'
import { useToast } from '../hooks/use-toast'

/**
 * Small inline modal for password reset (login screen)
 */
function ResetPasswordModal({
  open,
  onClose,
  onSubmit,
}: {
  open: boolean
  onClose: () => void
  onSubmit: (email: string, newPassword: string) => Promise<void>
}) {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [busy, setBusy] = useState(false)

  if (!open) return null
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/50" onClick={() => !busy && onClose()} />
      <Card className="relative w-full max-w-md bg-white/95 dark:bg-white/5 text-black dark:text-white backdrop-blur-sm border-white/20 dark:border-white/10">
        <CardHeader>
          <CardTitle>Reset password</CardTitle>
          <CardDescription>Enter your email and a new password (min 6 chars)</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="space-y-1">
              <Label htmlFor="rp-email">Email</Label>
              <Input
                id="rp-email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="name@example.com"
              />
            </div>
            <div className="space-y-1">
              <Label htmlFor="rp-pass">New password</Label>
              <Input
                id="rp-pass"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
              />
            </div>
            <div className="flex items-center justify-end gap-2 pt-2">
              <Button variant="outline" className="bg-transparent" onClick={onClose} disabled={busy}>
                Cancel
              </Button>
              <Button
                onClick={async () => {
                  setBusy(true)
                  try {
                    await onSubmit(email.trim(), password)
                  } finally {
                    setBusy(false)
                  }
                }}
                disabled={busy}
                className="bg-[#f47b20] hover:bg-[#f47b20]/90 text-white"
              >
                <KeyRound className="h-4 w-4 mr-2" />
                {busy ? 'Saving…' : 'Reset password'}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

/**
 * Login page component
 */
const LoginPage: React.FC = () => {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [resetOpen, setResetOpen] = useState(false)
  const { login, selfResetPassword } = useAuth()
  const { toast } = useToast()
  const navigate = useNavigate()

  /** Handle login submit */
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    const success = await login(email, password)
    if (success) {
      navigate('/dashboard')
    } else {
      toast({ title: 'Login failed', description: 'Check your email/password', variant: 'destructive' })
    }

    setIsLoading(false)
  }

  /** Handle self-serve reset */
  const handleSelfReset = async (targetEmail: string, newPass: string) => {
    if (!targetEmail || !newPass) return
    const res = await selfResetPassword(targetEmail, newPass)
    if (res.ok) {
      toast({ title: 'Password updated', description: 'You can now sign in with the new password.' })
      setResetOpen(false)
      setEmail(targetEmail)
      setPassword('')
    } else {
      toast({ title: 'Reset failed', description: res.error || 'Unknown error', variant: 'destructive' })
    }
  }

  return (
    <div className="min-h-[80vh] flex items-center justify-center">
      <Card className="w-full max-w-md bg-[#1a1a38]/80 backdrop-blur-sm border-white/20">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl font-bold text-white">Welcome Back</CardTitle>
          <CardDescription className="text-white/70">Sign in to your RKM Freight CRM</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <div className="relative">
                <Mail className="absolute left-3 top-3 h-4 w-4 text-white/50" />
                <Input
                  type="email"
                  placeholder="Email address"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="pl-10 bg-white/10 border-white/20 text-white placeholder:text-white/50"
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <div className="relative">
                <Lock className="absolute left-3 top-3 h-4 w-4 text-white/50" />
                <Input
                  type="password"
                  placeholder="Password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="pl-10 bg-white/10 border-white/20 text-white placeholder:text-white/50"
                  required
                />
              </div>
            </div>

            <Button
              type="submit"
              className="w-full bg-white text-[#1a1a38] hover:bg-white/90 hover:text-[#1a1a38]"
              disabled={isLoading}
            >
              <LogIn className="h-4 w-4 mr-2" />
              {isLoading ? 'Signing in...' : 'Sign In'}
            </Button>

            <div className="flex items-center justify-between pt-2">
              <button
                type="button"
                className="text-sm text-white/80 hover:text-white underline-offset-2 hover:underline"
                onClick={() => setResetOpen(true)}
              >
                Forgot password?
              </button>
            </div>
          </form>

          <div className="mt-6 pt-6 border-t border-white/20">
            <p className="text-center text-white/70 text-sm">
              Demo: Enter any email/password to login, or reset if forgotten.
            </p>
          </div>
        </CardContent>
      </Card>

      <ResetPasswordModal open={resetOpen} onClose={() => setResetOpen(false)} onSubmit={handleSelfReset} />
    </div>
  )
}

export default LoginPage
