/**
 * Home page
 * - Shows the Login screen by default when user is not authenticated (no routing change).
 * - When authenticated, shows quick entrances to Dashboard, Inbox, and Leads.
 */

import React from 'react'
import { useAuth } from '../contexts/AuthContext'
import Login from './Login'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '../components/ui/card'
import { Button } from '../components/ui/button'
import { Link } from 'react-router'
import { Mail, LayoutDashboard, Users } from 'lucide-react'

/** Home component */
const Home: React.FC = () => {
  const { isAuthenticated, user } = useAuth()

  if (!isAuthenticated) {
    return (
      <div className="min-h-[80vh] flex items-center justify-center">
        <Login />
      </div>
    )
  }

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-[#1a1a38] dark:text-white">Welcome back{user?.name ? `, ${user.name}` : ''}</h1>
          <p className="text-gray-700 dark:text-gray-300">Choose where to go next</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="bg-white/80 backdrop-blur-sm border-white/20 dark:bg-white/5 dark:border-white/10">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <LayoutDashboard className="h-5 w-5" /> Dashboard
            </CardTitle>
            <CardDescription>KPIs, activities, and shortcuts</CardDescription>
          </CardHeader>
          <CardContent>
            <Link to="/dashboard">
              <Button className="bg-[#1a1a38] hover:bg-[#1a1a38]/90 text-white">Open Dashboard</Button>
            </Link>
          </CardContent>
        </Card>

        <Card className="bg-white/80 backdrop-blur-sm border-white/20 dark:bg-white/5 dark:border-white/10">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Mail className="h-5 w-5" /> Inbox
            </CardTitle>
            <CardDescription>Read, reply, and compose emails</CardDescription>
          </CardHeader>
          <CardContent>
            <Link to="/inbox">
              <Button className="bg-[#f47b20] hover:bg-[#f47b20]/90 text-white">Go to Inbox</Button>
            </Link>
          </CardContent>
        </Card>

        <Card className="bg-white/80 backdrop-blur-sm border-white/20 dark:bg-white/5 dark:border-white/10">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5" /> Leads
            </CardTitle>
            <CardDescription>Manage prospects and contacts</CardDescription>
          </CardHeader>
          <CardContent>
            <Link to="/leads">
              <Button variant="outline" className="bg-transparent">Manage Leads</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

export default Home
