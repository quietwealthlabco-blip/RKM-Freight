/**
 * Manage Leads page with advanced table:
 * - Uses LeadsTable for frozen columns, per-header filters, sorting, and grouping.
 * - Supports selection with bulk actions (delete/email) that work regardless of sort/group.
 * - Loads leads from Sheety, computes distance in background, and dispatches 'leads-changed' for dashboard sync.
 */

import React, { useState, useEffect, useMemo } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card'
import { Button } from '../components/ui/button'
import { Input } from '../components/ui/input'
import { Upload, Download, Plus, Search, Trash2, Mail } from 'lucide-react'
import { useToast } from '../hooks/use-toast'
import CsvUpload from '../components/CsvUpload'
import AddLeadForm from '../components/AddLeadForm'
import { getLeads, deleteLead, Lead } from '../services/sheetyApi'
import { calculateDistance } from '../services/distanceCalculator'
import ComposeEmailPanel from '../components/mail/ComposeEmailPanel'
import LeadsTable from '../components/leads/LeadsTable'
import type { LeadsFilters, SortSpec, GroupByOption } from '../components/leads/LeadsTable'

/**
 * ManageLeadsPage component:
 * - Lists, filters, sorts, groups, and manages leads.
 * - Per-column filters, column freezing (sticky), grouping, and bulk actions (delete/email).
 * - CSV and manual add already prevent duplicates; distance computed in background.
 * - Triggers global 'leads-changed' for dashboard sync.
 */
const ManageLeadsPage: React.FC = () => {
  const [leads, setLeads] = useState<Lead[]>([])
  const [searchTerm, setSearchTerm] = useState('')
  const [isLoading, setIsLoading] = useState(true)
  const [showCsvUpload, setShowCsvUpload] = useState(false)
  const [showAddLead, setShowAddLead] = useState(false)
  const [editLead, setEditLead] = useState<Lead | null>(null)

  // Compose controls
  const [composeOpen, setComposeOpen] = useState(false)
  const [composeDraft, setComposeDraft] = useState<any | null>(null)

  // Selection & bulk actions
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set())

  // Table UI state: filters, sort, group, freeze
  const [filters, setFilters] = useState<LeadsFilters>({
    name: '',
    email: '',
    company: '',
    city: '',
    state: '',
    zipCode: '',
    status: '',
    jobTitle: '',
    industries: '',
    keywords: '',
    minEmployees: '',
    maxEmployees: '',
  })
  const [sort, setSort] = useState<SortSpec>({ key: 'name', dir: 'asc' })
  const [groupBy, setGroupBy] = useState<GroupByOption>('none')
  const [freezeColumns] = useState<boolean>(true)

  const { toast } = useToast()

  useEffect(() => {
    loadLeads()
  }, [])

  /**
   * Load leads quickly, compute distances in the background for perceived speed
   */
  const loadLeads = async () => {
    try {
      setIsLoading(true)
      const leadsData = await getLeads()

      // Show immediately (fast perceived load)
      setLeads(leadsData)

      // Compute distances in background and update once (improves perceived performance)
      ;(async () => {
        try {
          const results = await Promise.allSettled(
            leadsData.map(async (lead: any) => {
              const distance = await calculateDistance(lead.address, lead.city, lead.state, lead.zipCode)
              return { id: lead.id, distance: distance || 0 }
            })
          )

          // Merge distances
          setLeads((prev) =>
            prev.map((l) => {
              const found = results.find(
                (r) => r.status === 'fulfilled' && (r as any).value.id === l.id
              ) as PromiseFulfilledResult<{ id: string; distance: number }> | undefined
              if (found) {
                return { ...l, distance: found.value.distance }
              }
              return l
            })
          )
        } catch {
          // ignore background errors
        } finally {
          // Notify other parts of the app (e.g., Dashboard) to refresh their data
          window.dispatchEvent(new Event('leads-changed'))
        }
      })()
    } catch (error) {
      toast({
        title: 'Error loading leads',
        description: 'Failed to fetch leads from database',
        variant: 'destructive',
      })
    } finally {
      setIsLoading(false)
    }
  }

  /**
   * Delete a lead by id, update state and dispatch global event
   */
  const handleDeleteLead = async (leadId: string) => {
    try {
      await deleteLead(leadId)
      setLeads((prev) => prev.filter((lead) => lead.id !== leadId))
      // Trigger a global update for dashboards
      window.dispatchEvent(new Event('leads-changed'))
      toast({
        title: 'Lead deleted',
        description: 'Lead has been successfully removed',
      })
    } catch (error) {
      toast({
        title: 'Error deleting lead',
        description: 'Failed to delete lead from database',
        variant: 'destructive',
      })
    }
  }

  /**
   * Open compose with a prefilled draft for a specific lead
   */
  const openComposeForLead = (lead: Lead) => {
    const subject = `Hello ${lead.name || ''}`.trim()
    const body = `<p>Hello ${lead.name || ''},</p><p></p><p>Best regards,</p>`
    setComposeDraft({
      to: [lead.email],
      subject,
      bodyHtml: body,
    })
    setComposeOpen(true)
  }

  /**
   * Open compose for selected leads (bulk)
   */
  const openComposeForSelected = () => {
    const emails = leads
      .filter((l) => l.email && selectedIds.has(String(l.id)))
      .map((l) => String(l.email).toLowerCase().trim())
    const unique = Array.from(new Set(emails))
    if (unique.length === 0) return
    setComposeDraft({
      to: unique,
      subject: '',
      bodyHtml: '<p>Hello,</p><p></p><p>Best regards,</p>',
    })
    setComposeOpen(true)
  }

  // Global search preview count (LeadsTable applies filtering internally too)
  const filteredLeads = useMemo(() => {
    const g = searchTerm.trim().toLowerCase()
    if (!g) return leads
    return leads.filter((lead) => {
      const hay =
        [
          lead.name,
          lead.email,
          lead.company,
          lead.address,
          lead.city,
          lead.state,
          lead.zipCode,
          lead.jobTitle,
          lead.industries,
          lead.keywords,
        ]
          .map((x) => (x || '').toLowerCase())
          .join(' ')
      return hay.includes(g)
    })
  }, [leads, searchTerm])

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-[#1a1a38] dark:text-white">Manage Leads</h1>
          <p className="text-gray-700 dark:text-gray-300">
            Upload, manage, and track your leads with real-time data
          </p>
        </div>
        <div className="flex space-x-3">
          <Button onClick={() => setShowCsvUpload(true)} className="bg-[#1a1a38] hover:bg-[#1a1a38]/90 text-white">
            <Upload className="h-4 w-4 mr-2" />
            Upload CSV
          </Button>
          <Button
            variant="outline"
            className="bg-transparent border-[#1a1a38]/20 text-[#1a1a38] hover:bg-[#1a1a38]/10 dark:border-white/15 dark:text-white dark:hover:bg-white/10"
            onClick={() => {
              // Simple export stub; can be implemented to fetch and download CSV
              toast({ title: 'Export coming soon', description: 'CSV export can be added on request.' })
            }}
          >
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
          <Button onClick={() => setShowAddLead(true)} className="bg-[#f47b20] hover:bg-[#f47b20]/90 text-white">
            <Plus className="h-4 w-4 mr-2" />
            Add Lead
          </Button>
        </div>
      </div>

      {/* Global search */}
      <Card className="bg-white/80 backdrop-blur-sm border-white/20 dark:bg-white/5 dark:border-white/10">
        <CardContent className="p-4">
          <div className="flex items-center gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search by any field..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 text-sm dark:bg-white/10 dark:border-white/10 dark:text-white dark:placeholder:text-gray-400"
              />
            </div>
            <div className="text-xs text-gray-600 dark:text-gray-300">
              Showing {filteredLeads.length} of {leads.length}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Leads Table (advanced) */}
      <LeadsTable
        leads={leads}
        loading={isLoading}
        globalQuery={searchTerm}
        selectedIds={selectedIds}
        onToggleSelect={(id, checked) =>
          setSelectedIds((prev) => {
            const next = new Set(prev)
            if (checked) next.add(String(id))
            else next.delete(String(id))
            return next
          })
        }
        onToggleSelectAll={(checked, ids) =>
          setSelectedIds((prev) => {
            const next = new Set(prev)
            if (checked) ids.forEach((id) => next.add(String(id)))
            else ids.forEach((id) => next.delete(String(id)))
            return next
          })
        }
        onEdit={(lead) => setEditLead(lead)}
        onDelete={handleDeleteLead}
        onComposeLead={openComposeForLead}
        filters={filters}
        setFilters={setFilters}
        sort={sort}
        setSort={setSort}
        groupBy={groupBy}
        setGroupBy={setGroupBy}
        freezeColumns={freezeColumns}
      />

      {/* Bulk actions bar */}
      {selectedIds.size > 0 && (
        <div className="sticky bottom-3 z-40">
          <div className="mx-auto max-w-full md:max-w-none">
            <div className="rounded-lg shadow-lg border border-white/20 dark:border-white/10 bg-white/95 dark:bg-[#0b1020]/60 backdrop-blur p-3 flex items-center justify-between">
              <div className="text-sm">
                <span className="font-medium">{selectedIds.size}</span> selected
              </div>
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  className="bg-transparent border-red-200 text-red-600 hover:bg-red-50 dark:border-red-300/30 dark:text-red-300 dark:hover:bg-white/10"
                  onClick={async () => {
                    if (!confirm('Delete selected leads? This cannot be undone.')) return
                    try {
                      for (const id of Array.from(selectedIds)) {
                        await deleteLead(String(id))
                      }
                      setLeads((prev) => prev.filter((l) => !selectedIds.has(String(l.id))))
                      setSelectedIds(new Set())
                      window.dispatchEvent(new Event('leads-changed'))
                      toast({ title: 'Leads deleted' })
                    } catch (e) {
                      toast({ title: 'Bulk delete failed', variant: 'destructive' })
                    }
                  }}
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  Delete selected
                </Button>
                <Button className="bg-[#1a1a38] hover:bg-[#1a1a38]/90 text-white" onClick={openComposeForSelected}>
                  <Mail className="h-4 w-4 mr-2" />
                  Email selected
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* CSV Upload Modal */}
      {showCsvUpload && (
        <CsvUpload onClose={() => setShowCsvUpload(false)} onUploadSuccess={loadLeads} />
      )}

      {/* Add Lead Modal */}
      {showAddLead && (
        <AddLeadForm onClose={() => setShowAddLead(false)} onSuccess={loadLeads} mode="create" />
      )}

      {/* Edit Lead Modal */}
      {editLead && (
        <AddLeadForm onClose={() => setEditLead(null)} onSuccess={loadLeads} initial={editLead} mode="edit" />
      )}

      {/* Compose Email Modal (prefilled for a lead or bulk) */}
      {composeOpen && (
        <ComposeEmailPanel
          open={composeOpen}
          onClose={() => setComposeOpen(false)}
          leads={leads}
          draft={composeDraft || undefined}
          onSent={loadLeads}
          onDraftSaved={loadLeads}
        />
      )}
    </div>
  )
}

export default ManageLeadsPage
