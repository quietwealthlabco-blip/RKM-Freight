/**
 * Dashboard: Live lead status overview
 * - Fetches leads from Sheety and computes counts by status.
 * - Listens for global "leads-changed" to auto-refresh after any lead updates.
 */

import React, { useEffect, useMemo, useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card'
import { Users, Mail, CheckCircle2, PhoneCall } from 'lucide-react'
import { getLeads, Lead } from '../services/sheetyApi'

/** Shape of computed aggregate stats for the dashboard */
interface StatusStats {
  total: number
  new: number
  contacted: number
  qualified: number
  converted: number
}

/** Compute aggregate counts by status from a list of leads */
function computeStatusStats(leads: Lead[]): StatusStats {
  const base: StatusStats = { total: 0, new: 0, contacted: 0, qualified: 0, converted: 0 }
  return leads.reduce((acc, l) => {
    acc.total += 1
    const s = (l.status || 'New').toLowerCase()
    if (s === 'new') acc.new += 1
    else if (s === 'contacted') acc.contacted += 1
    else if (s === 'qualified') acc.qualified += 1
    else if (s === 'converted') acc.converted += 1
    return acc
  }, base)
}

/**
 * Dashboard page for monitoring leads by status.
 */
const DashboardPage: React.FC = () => {
  const [leads, setLeads] = useState<Lead[]>([])
  const [loading, setLoading] = useState<boolean>(true)
  const [error, setError] = useState<string | null>(null)

  const stats = useMemo(() => computeStatusStats(leads), [leads])

  /** Load leads from Sheety */
  const load = async () => {
    try {
      setLoading(true)
      setError(null)
      const rows = await getLeads()
      setLeads(rows || [])
    } catch (e: any) {
      setError(e?.message || 'Failed to load leads')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    load()
    // Listen for global updates (ManageLeads dispatches this after changes)
    const handler = () => load()
    window.addEventListener('leads-changed', handler)
    return () => window.removeEventListener('leads-changed', handler)
  }, [])

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Dashboard</h1>
        <p className="opacity-80">Live overview of leads by status</p>
      </div>

      {/* Status Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {/* New */}
        <Card className="bg-white/80 backdrop-blur-sm border-white/20 dark:bg-white/5 dark:border-white/10">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium opacity-80">New</p>
                <p className="text-2xl font-bold mt-1">{loading ? '—' : stats.new}</p>
              </div>
              <div className="bg-[#f47b20] p-3 rounded-lg">
                <Users className="h-6 w-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Contacted */}
        <Card className="bg-white/80 backdrop-blur-sm border-white/20 dark:bg-white/5 dark:border-white/10">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium opacity-80">Contacted</p>
                <p className="text-2xl font-bold mt-1">{loading ? '—' : stats.contacted}</p>
              </div>
              <div className="bg-[#1a1a38] p-3 rounded-lg">
                <PhoneCall className="h-6 w-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Qualified */}
        <Card className="bg-white/80 backdrop-blur-sm border-white/20 dark:bg-white/5 dark:border-white/10">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium opacity-80">Qualified</p>
                <p className="text-2xl font-bold mt-1">{loading ? '—' : stats.qualified}</p>
              </div>
              <div className="bg-[#1a1a38] p-3 rounded-lg">
                <CheckCircle2 className="h-6 w-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Converted */}
        <Card className="bg-white/80 backdrop-blur-sm border-white/20 dark:bg-white/5 dark:border-white/10">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium opacity-80">Converted</p>
                <p className="text-2xl font-bold mt-1">{loading ? '—' : stats.converted}</p>
              </div>
              <div className="bg-[#1a1a38] p-3 rounded-lg">
                <Mail className="h-6 w-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Secondary Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="bg-white/80 backdrop-blur-sm border-white/20 dark:bg-white/5 dark:border-white/10">
          <CardHeader>
            <CardTitle>Summary</CardTitle>
            <CardDescription>Totals by current lead statuses</CardDescription>
          </CardHeader>
          <CardContent>
            {error ? (
              <div className="text-red-600">{error}</div>
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                <div className="p-3 rounded-md border border-gray-200/70 dark:border-white/10">
                  <div className="opacity-70">Total</div>
                  <div className="text-xl font-semibold">{loading ? '—' : stats.total}</div>
                </div>
                <div className="p-3 rounded-md border border-gray-200/70 dark:border-white/10">
                  <div className="opacity-70">New</div>
                  <div className="text-xl font-semibold">{loading ? '—' : stats.new}</div>
                </div>
                <div className="p-3 rounded-md border border-gray-200/70 dark:border-white/10">
                  <div className="opacity-70">Contacted</div>
                  <div className="text-xl font-semibold">{loading ? '—' : stats.contacted}</div>
                </div>
                <div className="p-3 rounded-md border border-gray-200/70 dark:border-white/10">
                  <div className="opacity-70">Qualified</div>
                  <div className="text-xl font-semibold">{loading ? '—' : stats.qualified}</div>
                </div>
                <div className="p-3 rounded-md border border-gray-200/70 dark:border-white/10">
                  <div className="opacity-70">Converted</div>
                  <div className="text-xl font-semibold">{loading ? '—' : stats.converted}</div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="bg-white/80 backdrop-blur-sm border-white/20 dark:bg-white/5 dark:border-white/10">
          <CardHeader>
            <CardTitle>Actions</CardTitle>
            <CardDescription>Refresh data if you updated leads elsewhere</CardDescription>
          </CardHeader>
          <CardContent>
            <button
              onClick={load}
              className="inline-flex items-center rounded-md px-4 py-2 bg-[#f47b20] text-white hover:bg-[#f47b20]/90 transition-colors"
            >
              Reload
            </button>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

export default DashboardPage
