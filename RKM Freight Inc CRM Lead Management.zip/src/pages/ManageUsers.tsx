/**
 * ManageUsers page: Admin-only view of locally stored users
 * - Lists users from localStorage (via AuthContext helpers)
 * - Create, delete users
 * - Reset password per user (admin-only)
 * - Assign roles (admin or staff) per user (admin-only)
 * - Non-admins see a restricted message (no routing change)
 */

import React, { useEffect, useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card'
import { Button } from '../components/ui/button'
import { Input } from '../components/ui/input'
import { Label } from '../components/ui/label'
import { Trash2, UserPlus, ShieldAlert, Save, KeyRound } from 'lucide-react'
import { useAuth } from '../contexts/AuthContext'
import { Link } from 'react-router'
import { useToast } from '../hooks/use-toast'

/**
 * Inline modal to reset a user's password (admin)
 */
function ResetUserPasswordModal({
  open,
  email,
  onClose,
  onSubmit,
}: {
  open: boolean
  email: string | null
  onClose: () => void
  onSubmit: (email: string, newPassword: string) => Promise<void>
}) {
  const [password, setPassword] = useState('')
  const [busy, setBusy] = useState(false)
  if (!open || !email) return null
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/50" onClick={() => !busy && onClose()} />
      <div className="relative w-full max-w-md rounded-md border bg-white/95 dark:bg白/5 text-black dark:text-white p-4">
        <div className="mb-3 font-semibold text-lg">Reset password</div>
        <div className="space-y-3">
          <div className="text-sm text-gray-700 dark:text-gray-300">{email}</div>
          <div className="space-y-1">
            <Label htmlFor="rpw">New password</Label>
            <Input
              id="rpw"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
            />
          </div>
        </div>
        <div className="mt-4 flex items-center justify-end gap-2">
          <Button variant="outline" className="bg-transparent" onClick={onClose} disabled={busy}>
            Cancel
          </Button>
          <Button
            className="bg-[#f47b20] hover:bg-[#f47b20]/90 text-white"
            onClick={async () => {
              if (!email) return
              setBusy(true)
              try {
                await onSubmit(email, password)
              } finally {
                setBusy(false)
              }
            }}
            disabled={busy}
          >
            <KeyRound className="h-4 w-4 mr-2" />
            {busy ? 'Saving…' : 'Reset'}
          </Button>
        </div>
      </div>
    </div>
  )
}

/**
 * ManageUsersPage component
 */
const ManageUsersPage: React.FC = () => {
  const { listUsers, deleteUser, isAdmin, createUser, resetPassword, setUserRole } = useAuth()
  const { toast } = useToast()

  // Local state for users and create form
  const [users, setUsers] = useState(listUsers())
  const [showCreate, setShowCreate] = useState(false)
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [creating, setCreating] = useState(false)

  // Reset password modal state
  const [resetOpen, setResetOpen] = useState(false)
  const [resetEmail, setResetEmail] = useState<string | null>(null)

  /** Refresh users from store */
  const refreshUsers = () => setUsers(listUsers())

  useEffect(() => {
    refreshUsers()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  /** Delete user and refresh */
  const handleDelete = (userEmail: string) => {
    deleteUser(userEmail)
    refreshUsers()
    toast({ title: 'User deleted', description: userEmail })
  }

  /** Validate a basic email */
  const isEmail = (s: string) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s)

  /** Create user via context (admin-only) */
  const handleCreate = async () => {
    if (!name.trim() || !email.trim() || !password.trim()) {
      toast({ title: 'Missing fields', description: 'Please fill in name, email, and password', variant: 'destructive' })
      return
    }
    if (!isEmail(email)) {
      toast({ title: 'Invalid email', description: 'Please enter a valid email address', variant: 'destructive' })
      return
    }
    setCreating(true)
    try {
      const res = await createUser(name.trim(), email.trim(), password)
      if (!res.ok) {
        toast({ title: 'Could not create user', description: res.error || 'Unknown error', variant: 'destructive' })
        return
      }
      toast({ title: 'User created', description: email.trim() })
      setName('')
      setEmail('')
      setPassword('')
      setShowCreate(false)
      refreshUsers()
    } finally {
      setCreating(false)
    }
  }

  /** Save new password for a user (admin) */
  const handleResetPassword = async (userEmail: string, newPass: string) => {
    if (!newPass) return
    const res = await resetPassword(userEmail, newPass)
    if (res.ok) {
      toast({ title: 'Password updated', description: userEmail })
      setResetOpen(false)
      setResetEmail(null)
    } else {
      toast({ title: 'Reset failed', description: res.error || 'Unknown error', variant: 'destructive' })
    }
  }

  /** Update role handler */
  const handleRoleChange = async (userEmail: string, role: 'admin' | 'staff') => {
    const res = await setUserRole(userEmail, role)
    if (res.ok) {
      toast({ title: 'Role updated', description: `${userEmail} → ${role}` })
      refreshUsers()
    } else {
      toast({ title: 'Update failed', description: res.error || 'Unknown error', variant: 'destructive' })
    }
  }

  if (!isAdmin) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-[#1a1a38] dark:text-white">Manage Users</h1>
            <p className="text-gray-600 dark:text-gray-300">Access restricted</p>
          </div>
        </div>

        <Card className="bg-white/80 backdrop-blur-sm border-white/20 dark:bg-white/5 dark:border-white/10">
          <CardHeader className="flex flex-row items-center gap-3">
            <ShieldAlert className="h-5 w-5 text-amber-600 dark:text-amber-400" />
            <div>
              <CardTitle>Access restricted</CardTitle>
              <CardDescription>Only admins can view Manage Users.</CardDescription>
            </div>
          </CardHeader>
          <CardContent className="flex items-center gap-3">
            <Link to="/dashboard">
              <Button variant="outline" className="bg-transparent">
                Back to Dashboard
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-[#1a1a38] dark:text-white">Manage Users</h1>
          <p className="text-gray-600 dark:text-gray-300">Add/remove users, assign roles, and reset passwords</p>
        </div>
        <Button className="bg-[#1a1a38] hover:bg-[#1a1a38]/90 text-white" onClick={() => setShowCreate((s) => !s)}>
          <UserPlus className="h-4 w-4 mr-2" />
          {showCreate ? 'Close' : 'Add New User'}
        </Button>
      </div>

      {/* Create User form */}
      {showCreate && (
        <Card className="bg-white/80 backdrop-blur-sm border-white/20 dark:bg-white/5 dark:border-white/10">
          <CardHeader>
            <CardTitle>Create a new user</CardTitle>
            <CardDescription>Users are stored locally for demo purposes</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name">Name</Label>
                <Input id="name" placeholder="Full name" value={name} onChange={(e) => setName(e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input id="email" placeholder="name@example.com" value={email} onChange={(e) => setEmail(e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
              </div>
            </div>

            <div className="mt-4 flex items-center justify-end gap-2">
              <Button
                variant="outline"
                className="bg-transparent"
                onClick={() => {
                  setShowCreate(false)
                  setName('')
                  setEmail('')
                  setPassword('')
                }}
              >
                Cancel
              </Button>
              <Button onClick={handleCreate} disabled={creating} className="bg-[#f47b20] hover:bg-[#f47b20]/90 text-white">
                <Save className="h-4 w-4 mr-2" />
                {creating ? 'Creating...' : 'Create User'}
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      <Card className="bg-white/80 backdrop-blur-sm border-white/20 dark:bg-white/5 dark:border-white/10">
        <CardHeader>
          <CardTitle>Users ({users.length})</CardTitle>
          <CardDescription>Local demo user store with role assignment</CardDescription>
        </CardHeader>
        <CardContent>
          {users.length === 0 ? (
            <div className="text-center py-8 text-gray-600 dark:text-gray-300">
              No users yet. Click "Add New User" to create one.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b">
                    <th className="text-left p-3 font-medium">Name</th>
                    <th className="text-left p-3 font-medium">Email</th>
                    <th className="text-left p-3 font-medium">Role</th>
                    <th className="text-left p-3 font-medium">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {users.map((u) => (
                    <tr key={u.id} className="border-b hover:bg-white/50 transition-colors">
                      <td className="p-3 font-medium">{u.name}</td>
                      <td className="p-3">{u.email}</td>
                      <td className="p-3">
                        <select
                          value={(u as any).role || 'staff'}
                          onChange={(e) => handleRoleChange(u.email, e.target.value as 'admin' | 'staff')}
                          className="h-9 px-2 rounded border bg-transparent"
                          aria-label={`Role for ${u.email}`}
                        >
                          <option value="staff">Staff</option>
                          <option value="admin">Admin</option>
                        </select>
                      </td>
                      <td className="p-3 flex items-center gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          className="bg-transparent"
                          onClick={() => {
                            setResetEmail(u.email)
                            setResetOpen(true)
                          }}
                          title="Reset password"
                        >
                          <KeyRound className="h-3.5 w-3.5 mr-1" /> Reset
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          className="bg-transparent border-red-200 text-red-600 hover:bg-red-50 dark:border-red-300/30 dark:text-red-300 dark:hover:bg-white/10"
                          onClick={() => handleDelete(u.email)}
                        >
                          <Trash2 className="h-3.5 w-3.5 mr-1" /> Delete
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      <ResetUserPasswordModal
        open={resetOpen}
        email={resetEmail}
        onClose={() => {
          setResetOpen(false)
          setResetEmail(null)
        }}
        onSubmit={handleResetPassword}
      />
    </div>
  )
}

export default ManageUsersPage
