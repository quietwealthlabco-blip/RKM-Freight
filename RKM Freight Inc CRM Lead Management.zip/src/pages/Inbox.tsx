/**
 * Mailbox page: Gmail-like folders + message list + reader + compose.
 * - Folders: Inbox, Sent, Drafts, Trash (localStorage via mailStore)
 * - Compose supports multi-recipient selection from Leads and manual entry
 * - Email Settings modal access with Connect Gmail
 * - Readability: Wrapped with `.light-readable` so light theme text is dark on grey surfaces.
 * - Auto-sync: If Gmail OAuth is connected, poll for new inbox messages periodically.
 * - New: Reply, Reply all, Forward actions via MailViewer.
 */

import React, { useEffect, useMemo, useRef, useState } from 'react'
import { Card } from '../components/ui/card'
import { Button } from '../components/ui/button'
import MailSidebar from '../components/mail/MailSidebar'
import MailList from '../components/mail/MailList'
import MailViewer from '../components/mail/MailViewer'
import ComposeEmailPanel from '../components/mail/ComposeEmailPanel'
import EmailIntegrationSettings from '../components/settings/EmailIntegrationSettings'
import { useToast } from '../hooks/use-toast'
import { deleteToTrash, emptyTrash, getById, list, MailFolder, MailItem, setRead, upsertInbox, move } from '../services/mailStore'
import { getLeads, Lead } from '../services/sheetyApi'
import { Trash2, Settings as SettingsIcon } from 'lucide-react'
import { useUserSettings } from '../contexts/UserSettingsContext'
import { fetchGmailInbox } from '../services/gmailApi'
import { useAuth } from '../contexts/AuthContext'

/**
 * Extracts a bare email address from a string like "Name <user@example.com>" or "user@example.com".
 */
function extractEmailAddress(s: string): string {
  const m = /<([^>]+)>/.exec(s)
  return (m ? m[1] : s).trim().toLowerCase()
}

/** Ensure a prefix (Re: / Fwd:) only once, case-insensitive. */
function ensureSubjectPrefix(subj: string, prefix: 'Re:' | 'Fwd:'): string {
  const trimmed = (subj || '').trim()
  const lower = trimmed.toLowerCase()
  if (lower.startsWith('re:') && prefix === 'Re:') return trimmed
  if (lower.startsWith('fwd:') && prefix === 'Fwd:') return trimmed
  return `${prefix} ${trimmed || ''}`.trim()
}

/** Quote original HTML with a simple header line. */
function quoteOriginalHtml(item: MailItem): string {
  const when = new Date(item.date).toLocaleString()
  const from = item.from
  const body = item.bodyHtml || ''
  return `<p>On ${when}, ${from} wrote:</p><blockquote style="margin:0 0 0 1rem;border-left:3px solid #ddd;padding-left:0.75rem">${body}</blockquote>`
}

/**
 * MailboxPage component
 * - Manages mailbox folders, selection, searching
 * - Provides access to Email Settings (Gmail API, Apps Script, Sheety)
 */
const MailboxPage: React.FC = () => {
  const { toast } = useToast()
  const { settings } = useUserSettings()
  const { user } = useAuth()

  const [folder, setFolder] = useState<MailFolder>('inbox')
  const [query, setQuery] = useState('')
  const [messages, setMessages] = useState<MailItem[]>([])
  const [selectedId, setSelectedId] = useState<string | null>(null)
  const [selected, setSelected] = useState<MailItem | null>(null)

  // Leads for compose recipient selector
  const [leads, setLeads] = useState<Lead[]>([])
  const [composeOpen, setComposeOpen] = useState(false)
  const [draftForCompose, setDraftForCompose] = useState<Partial<MailItem> | undefined>(undefined)

  // Settings modal
  const [settingsOpen, setSettingsOpen] = useState(false)

  /** Load folder messages */
  const loadFolder = (f: MailFolder) => {
    const items = list(f)
    setMessages(items)
    // reset selected if not present
    if (selectedId && !items.some((m) => m.id === selectedId)) {
      setSelectedId(items[0]?.id || null)
      setSelected(items[0] || null)
    }
  }

  // Initial data
  useEffect(() => {
    loadFolder(folder)
    ;(async () => {
      try {
        const data = await getLeads()
        setLeads(data)
      } catch {
        // ignore
      }
    })()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  // Reload when folder changes
  useEffect(() => {
    loadFolder(folder)
    setQuery('')
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [folder])

  // Keep selected in sync
  useEffect(() => {
    if (!selectedId) {
      setSelected(null)
      return
    }
    const s = getById(selectedId)
    setSelected(s)
  }, [selectedId, messages])

  const counts = useMemo(
    () => ({
      inbox: list('inbox').length,
      sent: list('sent').length,
      drafts: list('drafts').length,
      trash: list('trash').length,
    }),
    [messages, folder]
  )

  const onSelectMessage = (id: string) => {
    setSelectedId(id)
    setRead(id, true)
    // refresh shallow state to flip read badge quickly
    setMessages((prev) => prev.map((m) => (m.id === id ? { ...m, read: true } : m)))
  }

  const onToggleRead = (id: string, read: boolean) => {
    setRead(id, read)
    setMessages((prev) => prev.map((m) => (m.id === id ? { ...m, read } : m)))
  }

  const onTrash = (id: string) => {
    deleteToTrash(id)
    toast({ title: 'Moved to Trash' })
    loadFolder(folder)
  }

  const onComposeClosed = () => {
    setComposeOpen(false)
    setDraftForCompose(undefined)
  }

  const refreshAfterSentOrDraft = () => {
    loadFolder(folder)
  }

  /* ==============================
     Auto-sync from Gmail
     ============================== */
  const syncTimerRef = useRef<number | null>(null)
  const isSyncingRef = useRef(false)

  useEffect(() => {
    // Preconditions for Gmail sync
    const clientId = settings.gmailClientId?.trim()
    const wantSync = !!clientId

    let cancelled = false

    async function tickSync() {
      if (!wantSync || isSyncingRef.current) return
      isSyncingRef.current = true
      try {
        const items = await fetchGmailInbox(
          clientId!,
          settings.syncQuery || 'in:inbox newer_than:7d -from:me',
          Math.max(5, Math.min(settings.syncMaxThreads || 50, 25))
        )
        // Merge into local store
        const added = upsertInbox(items)
        // If user is viewing Inbox and we added anything, reload list
        if (!cancelled && added > 0 && folder === 'inbox') {
          loadFolder('inbox')
        }
      } catch {
        // silent during background sync
      } finally {
        isSyncingRef.current = false
      }
    }

    function startTimer() {
      syncTimerRef.current = window.setInterval(tickSync, 10_000)
      // Immediate
      tickSync()
    }
    function stopTimer() {
      if (syncTimerRef.current) {
        clearInterval(syncTimerRef.current)
        syncTimerRef.current = null
      }
    }

    if (wantSync) startTimer()
    else stopTimer()

    return () => {
      cancelled = true
      stopTimer()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [settings.gmailClientId, settings.syncQuery, settings.syncMaxThreads, folder])

  /* ==============================
     Reply / Reply all / Forward
     ============================== */
  const currentUserEmail = (user?.email || '').toLowerCase()

  const handleReply = () => {
    if (!selected) return
    const to = [extractEmailAddress(selected.from)]
    const subject = ensureSubjectPrefix(selected.subject || '', 'Re:')
    const bodyHtml = quoteOriginalHtml(selected)

    setDraftForCompose({
      to,
      subject,
      bodyHtml,
      from: currentUserEmail || 'me@rkmfreight.com',
    })
    setComposeOpen(true)
  }

  const handleReplyAll = () => {
    if (!selected) return
    const sender = extractEmailAddress(selected.from)
    const others = (selected.to || []).map(extractEmailAddress)
    const set = new Set<string>([sender, ...others])
    if (currentUserEmail) set.delete(currentUserEmail)
    const to = Array.from(set)
    const subject = ensureSubjectPrefix(selected.subject || '', 'Re:')
    const bodyHtml = quoteOriginalHtml(selected)

    setDraftForCompose({
      to,
      subject,
      bodyHtml,
      from: currentUserEmail || 'me@rkmfreight.com',
    })
    setComposeOpen(true)
  }

  const handleForward = () => {
    if (!selected) return
    const subject = ensureSubjectPrefix(selected.subject || '', 'Fwd:')
    const bodyHtml = quoteOriginalHtml(selected)

    setDraftForCompose({
      to: [],
      subject,
      bodyHtml,
      from: currentUserEmail || 'me@rkmfreight.com',
    })
    setComposeOpen(true)
  }

  return (
    <div className="light-readable space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-[#1a1a38] dark:text-white">Mailbox</h1>
          <p className="text-gray-700 dark:text-gray-300">Inbox, Sent, Drafts, and Trash</p>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            className="bg-transparent border-[#1a1a38]/20 text-[#1a1a38] hover:bg-[#1a1a38]/10 dark:border-white/20 dark:text-white dark:hover:bg-white/10"
            onClick={() => setSettingsOpen(true)}
            title="Email Integration Settings"
          >
            <SettingsIcon className="h-4 w-4 mr-2" />
            Email Settings
          </Button>

          {folder === 'trash' && (
            <Button
              variant="outline"
              className="bg-transparent border-red-200 text-red-600 hover:bg-red-50 dark:hover:bg-white/10 dark:text-red-300 dark:border-red-300/30"
              onClick={() => {
                emptyTrash()
                toast({ title: 'Trash emptied' })
                loadFolder('trash')
              }}
            >
              <Trash2 className="h-4 w-4 mr-2" />
              Empty Trash
            </Button>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-[16rem_1fr] gap-6 min-h-[64vh]">
        <MailSidebar
          active={folder}
          counts={counts as any}
          onSelect={(f) => setFolder(f)}
          onCompose={() => setComposeOpen(true)}
          onDropMessage={(target, id) => {
            try {
              move(id, target)
              // If the moved message is currently selected, clear the viewer
              setSelectedId((prev) => (prev === id ? null : prev))
              // Refresh current folder
              loadFolder(folder)
              toast({ title: 'Message moved' })
            } catch (e: any) {
              toast({ title: 'Move failed', description: String(e?.message || e), variant: 'destructive' })
            }
          }}
        />

        <div className="grid grid-rows-[1fr] md:grid-cols-[minmax(0,0.55fr)_minmax(0,0.45fr)] gap-6">
          <Card className="h-full bg-transparent border-none shadow-none">
            <MailList
              items={messages}
              query={query}
              onQueryChange={setQuery}
              selectedId={selectedId}
              onSelect={onSelectMessage}
              onToggleRead={onToggleRead}
              onTrash={onTrash}
            />
          </Card>

          <div className="hidden md:block">
            <MailViewer
              item={selected}
              onReply={handleReply}
              onReplyAll={handleReplyAll}
              onForward={handleForward}
              gmailClientId={settings.gmailClientId}
            />
          </div>
        </div>
      </div>

      {composeOpen && (
        <ComposeEmailPanel
          open={composeOpen}
          onClose={onComposeClosed}
          leads={leads}
          draft={draftForCompose}
          onSent={refreshAfterSentOrDraft}
          onDraftSaved={refreshAfterSentOrDraft}
        />
      )}

      {settingsOpen && (
        <EmailIntegrationSettings open={settingsOpen} onClose={() => setSettingsOpen(false)} />
      )}
    </div>
  )
}

export default MailboxPage
