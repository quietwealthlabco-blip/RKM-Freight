/**
 * UserSettingsContext: Per-user email integration settings (Apps Script + Sheety + Gmail API send).
 * - Stores settings in localStorage keyed by user email
 * - Provides read/update via React context
 */

import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react'
import { useAuth } from './AuthContext'

/** Persisted per-user email integration settings */
export interface UserEmailSettings {
  /** Google Apps Script Web App URL (deployed "web app" endpoint) */
  appsScriptUrl: string
  /** Sheety REST endpoint for Emails sheet (e.g., https://api.sheety.co/.../rkmEmails/emails) */
  sheetyEmailsUrl: string
  /** Optional bearer token for Sheety (do not include "Bearer " prefix) */
  sheetyToken?: string
  /** Gmail query for syncInbox (GmailApp.search) */
  syncQuery: string
  /** Max threads to scan in syncInbox */
  syncMaxThreads: number
  /** Gmail OAuth Client ID for Gmail API send (Web application) */
  gmailClientId: string
  /** If true, Compose will use Gmail API send instead of Apps Script */
  useGmailApiSend: boolean
}

/** Defaults used when user has no saved settings */
const DEFAULT_SETTINGS: UserEmailSettings = {
  appsScriptUrl: '',
  sheetyEmailsUrl: '',
  sheetyToken: '',
  syncQuery: 'in:inbox newer_than:7d -from:me',
  syncMaxThreads: 50,
  gmailClientId: '',
  useGmailApiSend: false,
}

/** Shape of the context value */
interface UserSettingsContextValue {
  settings: UserEmailSettings
  updateSettings: (partial: Partial<UserEmailSettings>) => void
  resetSettings: () => void
}

/** LocalStorage key for the settings map */
const KEY = 'rkm_user_settings_v1'

/** Internal map shape: email -> settings */
type SettingsMap = Record<string, UserEmailSettings>

const UserSettingsContext = createContext<UserSettingsContextValue | undefined>(undefined)

/** Load full settings map from localStorage */
function loadMap(): SettingsMap {
  try {
    const raw = localStorage.getItem(KEY)
    return raw ? (JSON.parse(raw) as SettingsMap) : {}
  } catch {
    return {}
  }
}

/** Save full settings map to localStorage */
function saveMap(map: SettingsMap) {
  try {
    localStorage.setItem(KEY, JSON.stringify(map))
  } catch {
    // ignore quota errors
  }
}

/**
 * UserSettingsProvider: Provides per-user settings based on current auth user
 */
export const UserSettingsProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useAuth()
  const userKey = user?.email?.toLowerCase() || 'guest'

  const [settings, setSettings] = useState<UserEmailSettings>(DEFAULT_SETTINGS)

  // Load user-specific settings when auth user changes
  useEffect(() => {
    const map = loadMap()
    const raw = map[userKey] as Partial<UserEmailSettings> | undefined
    // Merge with defaults to include any newly added fields
    const merged: UserEmailSettings = { ...DEFAULT_SETTINGS, ...(raw || {}) }
    setSettings(merged)
  }, [userKey])

  const updateSettings = useCallback((partial: Partial<UserEmailSettings>) => {
    setSettings((prev) => {
      const next = { ...prev, ...partial }
      const map = loadMap()
      map[userKey] = next
      saveMap(map)
      return next
    })
  }, [userKey])

  const resetSettings = useCallback(() => {
    setSettings(() => {
      const map = loadMap()
      map[userKey] = DEFAULT_SETTINGS
      saveMap(map)
      return DEFAULT_SETTINGS
    })
  }, [userKey])

  const value = useMemo<UserSettingsContextValue>(() => ({
    settings,
    updateSettings,
    resetSettings,
  }), [settings, updateSettings, resetSettings])

  return <UserSettingsContext.Provider value={value}>{children}</UserSettingsContext.Provider>
}

/** useUserSettings: Hook to access per-user settings */
export const useUserSettings = () => {
  const ctx = useContext(UserSettingsContext)
  if (!ctx) throw new Error('useUserSettings must be used within UserSettingsProvider')
  return ctx
}
