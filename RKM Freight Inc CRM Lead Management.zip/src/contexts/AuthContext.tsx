/**
 * AuthContext: Demo authentication and user management using localStorage.
 * - Stores users in "rkm_users"
 * - Stores session in "rkm_current_user"
 * - Provides login, signup, logout, list/delete users
 * - Adds an isAdmin flag based on a fixed admin email allowlist.
 * - Adds createUser for admin-only user creation without changing session.
 */

import React, { createContext, useContext, useEffect, useMemo, useState } from 'react'

/** User object used across the app */
export interface User {
  id: string
  name: string
  email: string
}

/** Internal storage user record */
/** Internal storage user record */
interface UserStoreItem {
  id: string
  name: string
  email: string
  password: string
  /** Optional role flag; defaults to 'staff' if missing (migrated on load) */
  role?: 'admin' | 'staff'
}

/** Auth context value shape */
interface AuthContextType {
  user: User | null
  isAuthenticated: boolean
  /** True if current user is allowed to administer users (role or allowlist) */
  isAdmin: boolean
  /** Login with email/password (demo only) */
  login: (email: string, password: string) => Promise<boolean>
  /** Signup and auto-login (enforces unique email) */
  signup: (name: string, email: string, password: string) => Promise<boolean>
  /** Clear session */
  logout: () => void
  // Admin helpers for Manage Users page
  listUsers: () => UserStoreItem[]
  deleteUser: (email: string) => void
  /** Admin-only: create a user without logging them in */
  createUser: (name: string, email: string, password: string) => Promise<{ ok: boolean; error?: string }>
  /** User self-service: change their own password (requires current password) */
  changePassword: (currentPassword: string, newPassword: string) => Promise<{ ok: boolean; error?: string }>
  /** Admin-only: reset a user's password by email */
  resetPassword: (email: string, newPassword: string) => Promise<{ ok: boolean; error?: string }>
  /** Public self-serve reset (Login screen). No auth; sets a new password if email exists. */
  selfResetPassword: (email: string, newPassword: string) => Promise<{ ok: boolean; error?: string }>
  /** Admin-only: set a user's role */
  setUserRole: (email: string, role: 'admin' | 'staff') => Promise<{ ok: boolean; error?: string }>
}

const USERS_KEY = 'rkm_users'
const SESSION_KEY = 'rkm_current_user'

/**
 * Admin allowlist:
 * - Only these emails are considered admins.
 * - Case-insensitive comparison.
 */
const ADMIN_EMAILS = new Set<string>(['naekitakado@gmail.com'])

const AuthContext = createContext<AuthContextType | undefined>(undefined)

/**
 * Load users array from localStorage
 */
function loadUsers(): UserStoreItem[] {
  try {
    const raw = localStorage.getItem(USERS_KEY)
    const arr: UserStoreItem[] = raw ? (JSON.parse(raw) as UserStoreItem[]) : []
    // Migration: ensure role exists; default to 'staff'; elevate allowlisted emails to admin.
    let changed = false
    const out = arr.map((u) => {
      const email = String(u.email || '').toLowerCase()
      const role: 'admin' | 'staff' = ADMIN_EMAILS.has(email) ? 'admin' : (u.role || 'staff')
      if (u.role !== role) changed = true
      return { ...u, role }
    })
    if (changed) saveUsers(out)
    return out
  } catch {
    return []
  }
}

/**
 * Persist users array to localStorage
 */
function saveUsers(users: UserStoreItem[]) {
  localStorage.setItem(USERS_KEY, JSON.stringify(users))
}

/**
 * AuthProvider: Handles auth state and exposes operations
 */
export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null)

  // Load current session at startup
  useEffect(() => {
    try {
      const raw = localStorage.getItem(SESSION_KEY)
      if (raw) {
        const parsed = JSON.parse(raw) as User
        setUser(parsed)
      }
    } catch {
      // ignore
    }
  }, [])

  const isAuthenticated = !!user

  /**
   * Derive admin role from allowlist
   */
  const isAdmin = useMemo(() => {
    if (!user?.email) return false
    const email = user.email.toLowerCase()
    const users = loadUsers()
    const rec = users.find((u) => u.email.toLowerCase() === email)
    const roleAdmin = rec?.role === 'admin'
    const allowlistAdmin = ADMIN_EMAILS.has(email)
    return roleAdmin || allowlistAdmin
  }, [user?.email])

  /**
   * login: Accepts any existing user with matching email/password
   * - In demo: create user implicitly if not exists to simplify testing
   */
  const login = async (email: string, password: string): Promise<boolean> => {
    const users = loadUsers()
    let found = users.find((u) => u.email.toLowerCase() === email.toLowerCase())

    // If user not found, allow implicit create to reduce friction for demos
    if (!found) {
      found = {
        id: crypto.randomUUID(),
        name: email.split('@')[0] || 'User',
        email,
        password,
      }
      users.push(found)
      saveUsers(users)
    }

    // Simple password check (demo only)
    if (found.password !== password) {
      return false
    }

    const sessionUser: User = { id: found.id, name: found.name, email: found.email }
    localStorage.setItem(SESSION_KEY, JSON.stringify(sessionUser))
    setUser(sessionUser)
    return true
  }

  /**
   * signup: Enforce unique email, then log in immediately
   */
  const signup = async (name: string, email: string, password: string): Promise<boolean> => {
    const users = loadUsers()
    const exists = users.some((u) => u.email.toLowerCase() === email.toLowerCase())
    if (exists) return false

    const newUser: UserStoreItem = {
      id: crypto.randomUUID(),
      name,
      email,
      password,
    }
    users.push(newUser)
    saveUsers(users)

    const sessionUser: User = { id: newUser.id, name: newUser.name, email: newUser.email }
    localStorage.setItem(SESSION_KEY, JSON.stringify(sessionUser))
    setUser(sessionUser)
    return true
  }

  /**
   * logout: Clears session
   */
  const logout = () => {
    localStorage.removeItem(SESSION_KEY)
    setUser(null)
  }

  /**
   * listUsers: Admin helper for Manage Users UI
   */
  const listUsers = (): UserStoreItem[] => {
    return loadUsers()
  }

  /**
   * deleteUser: Remove a user by email
   * - If the current user deletes themselves, logout.
   */
  const deleteUser = (email: string) => {
    const users = loadUsers().filter((u) => u.email.toLowerCase() !== email.toLowerCase())
    saveUsers(users)
    // If current user deleted themselves, logout
    if (user?.email.toLowerCase() === email.toLowerCase()) {
      logout()
    }
  }

  /**
   * createUser: Admin-only creation that doesn't change the current session.
   * - Returns { ok: true } on success or { ok: false, error } on failure.
   */
  const createUser = async (
    name: string,
    email: string,
    password: string
  ): Promise<{ ok: boolean; error?: string }> => {
    const users = loadUsers()
    const exists = users.some((u) => u.email.toLowerCase() === email.toLowerCase())
    if (exists) return { ok: false, error: 'Email already exists' }

    const newUser: UserStoreItem = {
      id: crypto.randomUUID(),
      name,
      email,
      password,
      role: ADMIN_EMAILS.has(email.toLowerCase()) ? 'admin' : 'staff',
    }
    users.push(newUser)
    saveUsers(users)
    return { ok: true }
  }

  /**
   * changePassword: Current user updates their own password.
   * - Verifies current password before changing.
   */
  const changePassword = async (
    currentPassword: string,
    newPassword: string
  ): Promise<{ ok: boolean; error?: string }> => {
    if (!user?.email) return { ok: false, error: 'Not authenticated' }
    if (!newPassword || newPassword.length < 6) return { ok: false, error: 'New password must be at least 6 characters' }
    const users = loadUsers()
    const idx = users.findIndex((u) => u.email.toLowerCase() === user.email.toLowerCase())
    if (idx < 0) return { ok: false, error: 'User not found' }
    if (users[idx].password !== currentPassword) return { ok: false, error: 'Current password is incorrect' }
    users[idx].password = newPassword
    saveUsers(users)
    return { ok: true }
  }

  /**
   * resetPassword: Admin-only reset by email.
   */
  const resetPassword = async (
    email: string,
    newPassword: string
  ): Promise<{ ok: boolean; error?: string }> => {
    if (!isAdmin) return { ok: false, error: 'Not authorized' }
    if (!newPassword || newPassword.length < 6) return { ok: false, error: 'New password must be at least 6 characters' }
    const users = loadUsers()
    const idx = users.findIndex((u) => u.email.toLowerCase() === email.toLowerCase())
    if (idx < 0) return { ok: false, error: 'User not found' }
    users[idx].password = newPassword
    saveUsers(users)
    return { ok: true }
  }

  /**
   * selfResetPassword: Public reset used from the Login screen (no auth). Demo-only.
   */
  const selfResetPassword = async (
    email: string,
    newPassword: string
  ): Promise<{ ok: boolean; error?: string }> => {
    if (!newPassword || newPassword.length < 6) return { ok: false, error: 'New password must be at least 6 characters' }
    const users = loadUsers()
    const idx = users.findIndex((u) => u.email.toLowerCase() === email.toLowerCase())
    if (idx < 0) return { ok: false, error: 'User not found' }
    users[idx].password = newPassword
    saveUsers(users)
    return { ok: true }
  }

  /**
   * setUserRole: Admin-only role assignment.
   */
  const setUserRole = async (
    email: string,
    role: 'admin' | 'staff'
  ): Promise<{ ok: boolean; error?: string }> => {
    if (!isAdmin) return { ok: false, error: 'Not authorized' }
    const users = loadUsers()
    const idx = users.findIndex((u) => u.email.toLowerCase() === email.toLowerCase())
    if (idx < 0) return { ok: false, error: 'User not found' }
    users[idx].role = role
    saveUsers(users)
    return { ok: true }
  }

  const value = useMemo<AuthContextType>(
    () => ({
      user,
      isAuthenticated,
      isAdmin,
      login,
      signup,
      logout,
      listUsers,
      deleteUser,
      createUser,
      changePassword,
      resetPassword,
      selfResetPassword,
      setUserRole,
    }),
    [user, isAuthenticated, isAdmin]
  )

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

/**
 * useAuth: Hook to consume the auth context
 */
export const useAuth = () => {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used within an AuthProvider')
  return ctx
}
