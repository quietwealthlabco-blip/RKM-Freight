/**
 * SyncRulesDialog: Configure Gmail sync behavior for newly fetched messages.
 * - Mark as read
 * - Move to a chosen custom folder (optional)
 */

import React, { useMemo, useState } from 'react'
import { Button } from '../ui/button'
import { Label } from '../ui/label'
import { listFolders, UserFolder } from '../../services/mailStore'
import { getSyncRules, setSyncRules } from '../../services/syncRules'

interface SyncRulesDialogProps {
  open: boolean
  onClose: () => void
}

const SyncRulesDialog: React.FC<SyncRulesDialogProps> = ({ open, onClose }) => {
  const initial = useMemo(() => getSyncRules(), [])
  const [markAsRead, setMarkAsRead] = useState<boolean>(!!initial.markAsRead)
  const [moveToFolderId, setMoveToFolderId] = useState<string | ''>(initial.moveToFolderId || '')
  const folders: UserFolder[] = listFolders()

  if (!open) return null

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/50" onClick={onClose} />
      <div className="relative w-full max-w-md rounded-md border bg-white/95 dark:bg-white/5 text-black dark:text-white p-4">
        <div className="mb-3 font-semibold text-lg">Sync Rules</div>

        <div className="space-y-4">
          <label className="flex items-center gap-3 cursor-pointer">
            <input type="checkbox" checked={markAsRead} onChange={(e) => setMarkAsRead(e.target.checked)} />
            <span>Mark new Gmail synced messages as read</span>
          </label>

          <div className="space-y-2">
            <Label htmlFor="sr-target">Move new Gmail synced messages to</Label>
            <select
              id="sr-target"
              className="w-full h-9 rounded border border-[#1a1a38]/20 dark:border-white/20 bg-transparent px-2 text-sm"
              value={moveToFolderId}
              onChange={(e) => setMoveToFolderId(e.target.value)}
            >
              <option value="">None (keep in Inbox)</option>
              {folders.map((f) => (
                <option key={f.id} value={f.id}>
                  {f.name}
                </option>
              ))}
            </select>
            <p className="text-xs text-gray-600 dark:text-gray-300">If a folder is chosen, new synced messages will be moved there after sync.</p>
          </div>
        </div>

        <div className="mt-4 flex items-center justify-end gap-2">
          <Button variant="outline" className="bg-transparent" onClick={onClose}>Cancel</Button>
          <Button
            className="bg-[#f47b20] hover:bg-[#f47b20]/90 text-white"
            onClick={() => {
              setSyncRules({ markAsRead, moveToFolderId: moveToFolderId || null })
              onClose()
            }}
          >
            Save
          </Button>
        </div>
      </div>
    </div>
  )
}

export default SyncRulesDialog
