/**
 * EmailIntegrationSettings modal
 * - Configure Apps Script, Sheety, and Gmail API send (per user)
 * - Connect/Disconnect Gmail with status and email readout
 * - Shows current app origin to add to OAuth "Authorized JavaScript origins"
 * - Enhancements: auto-save gmailClientId per user (debounced), still editable
 */

import React, { useEffect, useMemo, useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card'
import { Input } from '../ui/input'
import { Label } from '../ui/label'
import { Button } from '../ui/button'
import { useUserSettings } from '../../contexts/UserSettingsContext'
import { connectGmail, disconnectGmail, getSignedInEmail, isGmailSignedIn } from '../../services/gmailApi'

interface Props {
  open: boolean
  onClose: () => void
}

/** Basic URL check */
function looksLikeUrl(s: string) {
  if (!s) return false
  try {
    // eslint-disable-next-line no-new
    new URL(s)
    return true
  } catch {
    return false
  }
}

/** Quick-fill Client ID (provided) */
const QUICK_FILL_CLIENT_ID = '922201026656-kkaipnck0nbvmdhbfcjf0359nreqg1q1.apps.googleusercontent.com'

/** Simple debounce helper (per render) */
function useDebouncedCallback<T extends (...args: any[]) => void>(fn: T, delay = 300) {
  const [handle, setHandle] = useState<number | null>(null)
  return (...args: Parameters<T>) => {
    if (handle) {
      window.clearTimeout(handle)
    }
    const h = window.setTimeout(() => fn(...args), delay)
    setHandle(h)
  }
}

/**
 * Email Integration Settings
 */
const EmailIntegrationSettings: React.FC<Props> = ({ open, onClose }) => {
  const { settings, updateSettings } = useUserSettings()

  const [appsScriptUrl, setAppsScriptUrl] = useState(settings.appsScriptUrl)
  const [sheetyUrl, setSheetyUrl] = useState(settings.sheetyEmailsUrl)
  const [sheetyToken, setSheetyToken] = useState(settings.sheetyToken || '')
  const [syncQuery, setSyncQuery] = useState(settings.syncQuery)
  const [syncMaxThreads, setSyncMaxThreads] = useState<number>(settings.syncMaxThreads)

  // Gmail API send
  const [gmailClientId, setGmailClientId] = useState(settings.gmailClientId)
  const [useGmailApiSend, setUseGmailApiSend] = useState(settings.useGmailApiSend)

  // Auto-save gmailClientId as user types (so it persists across refresh without pressing Save)
  const debouncedSaveClientId = useDebouncedCallback((id: string) => {
    updateSettings({ gmailClientId: id.trim() })
  }, 400)

  // Connection state
  const [connecting, setConnecting] = useState(false)
  const [connected, setConnected] = useState<boolean>(false)
  const [connectedEmail, setConnectedEmail] = useState<string | null>(null)
  const [statusMsg, setStatusMsg] = useState<string>('')

  // App origin to add in Google Console -> OAuth Client -> Authorized JavaScript origins
  const appOrigin = typeof window !== 'undefined' ? window.location.origin : ''

  /** Check connection status and fetch email if connected */
  const refreshConnection = async (cid: string) => {
    if (!cid) {
      setConnected(false)
      setConnectedEmail(null)
      setStatusMsg('Client ID is required to connect')
      return
    }
    try {
      const ok = await isGmailSignedIn(cid)
      setConnected(ok)
      if (ok) {
        const email = await getSignedInEmail(cid)
        setConnectedEmail(email)
        setStatusMsg(email ? `Connected as ${email}` : 'Connected to Google')
      } else {
        setConnectedEmail(null)
        setStatusMsg('Not connected')
      }
    } catch (e: any) {
      console.error('Status check error', e)
      setConnected(false)
      setConnectedEmail(null)
      const msg = e?.error || e?.details || e?.message || 'Not connected'
      setStatusMsg(String(msg))
    }
  }

  useEffect(() => {
    if (open) {
      setAppsScriptUrl(settings.appsScriptUrl)
      setSheetyUrl(settings.sheetyEmailsUrl)
      setSheetyToken(settings.sheetyToken || '')
      setSyncQuery(settings.syncQuery)
      setSyncMaxThreads(settings.syncMaxThreads)
      setGmailClientId(settings.gmailClientId)
      setUseGmailApiSend(settings.useGmailApiSend)
      // Refresh connection status when opening
      refreshConnection(settings.gmailClientId)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, settings])

  useEffect(() => {
    if (open) {
      // keep status in sync when clientId changes
      const t = setTimeout(() => refreshConnection(gmailClientId), 200)
      return () => clearTimeout(t)
    }
    return
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [gmailClientId])

  // Persist gmailClientId as the user types (without needing "Save Settings")
  useEffect(() => {
    if (!open) return
    debouncedSaveClientId(gmailClientId)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [gmailClientId, open])

  const canSave =
    (appsScriptUrl.trim().length > 0 || (useGmailApiSend && gmailClientId.trim().length > 0)) &&
    (sheetyUrl.trim().length > 0 || true) // Sheety optional for sending

  const handleSave = () => {
    updateSettings({
      appsScriptUrl: appsScriptUrl.trim(),
      sheetyEmailsUrl: sheetyUrl.trim(),
      sheetyToken: sheetyToken.trim(),
      syncQuery: syncQuery.trim() || 'in:inbox newer_than:7d -from:me',
      syncMaxThreads: Number.isFinite(syncMaxThreads) && syncMaxThreads > 0 ? syncMaxThreads : 50,
      gmailClientId: gmailClientId.trim(),
      useGmailApiSend,
    })
    onClose()
  }

  const handleConnect = async () => {
    if (!gmailClientId.trim()) {
      setStatusMsg('Please provide a Gmail OAuth Client ID first')
      return
    }
    setConnecting(true)
    setStatusMsg('Opening Google sign-in...')
    try {
      await connectGmail(gmailClientId.trim())
      await refreshConnection(gmailClientId.trim())
      setStatusMsg('Connected')
    } catch (e: any) {
      console.error('Gmail connect error', e)
      const msg = e?.error || e?.details || e?.message || 'Failed to connect'
      setStatusMsg(`Failed to connect: ${String(msg)}`)
    } finally {
      setConnecting(false)
    }
  }

  const handleDisconnect = async () => {
    setConnecting(true)
    setStatusMsg('Signing out...')
    try {
      await disconnectGmail()
      await refreshConnection(gmailClientId.trim())
    } catch (e) {
      console.error('Disconnect error', e)
    } finally {
      setConnecting(false)
    }
  }

  const savedHint = useMemo(() => {
    // Tiny visual hint to user that Client ID persists
    const v = gmailClientId?.trim()
    if (!v) return 'Enter a Client ID. It will be saved for your account on this device.'
    return 'Client ID is saved for your user and will persist after refresh. You can edit it anytime.'
  }, [gmailClientId])

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/50" onClick={onClose} />
      <Card className="relative w-full max-w-2xl bg-white/95 dark:bg-white/5 text-black dark:text-white backdrop-blur-sm border-white/20 dark:border-white/10">
        <CardHeader>
          <CardTitle>Email Integration Settings</CardTitle>
          <CardDescription>Configure Apps Script, Sheety, and Gmail API send (per user)</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Gmail API Send */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label htmlFor="useGmailApiSend">Use Gmail API to send (OAuth)</Label>
              <input
                id="useGmailApiSend"
                type="checkbox"
                checked={useGmailApiSend}
                onChange={(e) => setUseGmailApiSend(e.target.checked)}
                className="h-4 w-4"
              />
            </div>
            <p className="text-xs text-gray-600 dark:text-gray-300">
              When enabled, Compose will send via your signed-in Gmail account with OAuth (attachments supported).
            </p>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="gmailClientId">Gmail OAuth Client ID</Label>
                <div className="flex items-center gap-2">
                  <Button
                    type="button"
                    variant="outline"
                    className="bg-transparent h-8 px-2"
                    onClick={() => setGmailClientId(QUICK_FILL_CLIENT_ID)}
                    title="Quick-fill the provided Client ID"
                  >
                    Use provided ID
                  </Button>
                </div>
              </div>

              <Input
                id="gmailClientId"
                placeholder="xxxxxxxxxxxx-abc123.apps.googleusercontent.com"
                value={gmailClientId}
                onChange={(e) => setGmailClientId(e.target.value)}
              />
              <p className="text-xs text-gray-600 dark:text-gray-300">{savedHint}</p>

              {/* Authorized JavaScript origin helper */}
              <div className="space-y-2 mt-2">
                <Label>Authorized JavaScript origin (add this in Google Console)</Label>
                <div className="flex items-center gap-2">
                  <Input value={appOrigin} readOnly />
                  <Button
                    type="button"
                    variant="outline"
                    className="bg-transparent h-8 px-2"
                    onClick={() => navigator.clipboard.writeText(appOrigin).then(() => setStatusMsg('Origin copied'))}
                  >
                    Copy
                  </Button>
                  <a
                    className="text-sm underline text-[#1a1a38] dark:text-white"
                    href="https://console.cloud.google.com/apis/credentials"
                    target="_blank"
                    rel="noreferrer"
                  >
                    Open Google Console
                  </a>
                </div>
                <p className="text-xs text-gray-600 dark:text-gray-300">
                  Paste this value into Credentials → your OAuth Client → Authorized JavaScript origins.
                </p>
              </div>

              {/* Connect / Status row */}
              <div className="flex flex-col gap-2 md:flex-row md:items-center md:justify-between pt-2">
                <div className="flex items-center gap-2">
                  <span
                    className={
                      'inline-block h-2 w-2 rounded-full ' +
                      (connected ? 'bg-green-600' : 'bg-gray-400')
                    }
                    aria-hidden
                  />
                  <span className="text-sm text-gray-700 dark:text-gray-300">
                    {statusMsg || (connected ? 'Connected to Google' : 'Not connected')}
                  </span>
                  {connectedEmail && (
                    <span className="text-sm text-gray-500">({connectedEmail})</span>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  {!connected ? (
                    <Button
                      type="button"
                      onClick={handleConnect}
                      disabled={connecting || !gmailClientId.trim() || !useGmailApiSend}
                      className="bg-[#1a1a38] hover:bg-[#1a1a38]/90 text-white"
                    >
                      {connecting ? 'Connecting…' : 'Connect Gmail'}
                    </Button>
                  ) : (
                    <Button
                      type="button"
                      variant="outline"
                      onClick={handleDisconnect}
                      disabled={connecting}
                      className="bg-transparent border-red-200 text-red-600 hover:bg-red-50 dark:border-red-300/30 dark:text-red-300 dark:hover:bg-white/10"
                    >
                      {connecting ? 'Disconnecting…' : 'Disconnect'}
                    </Button>
                  )}
                </div>
              </div>

              {/* Troubleshooting tips */}
              <div className="text-xs text-gray-600 dark:text-gray-300 mt-2 space-y-1">
                <p>• Ensure Gmail API is enabled in the same project as this Client ID.</p>
                <p>• OAuth consent: add your Google account as a Test user (if Testing) and include gmail.send scope.</p>
                <p>• Popup blockers and strict tracking may prevent sign-in inside iframes. Allow popups or open the app in a new tab.</p>
              </div>
            </div>
          </div>

          <div className="h-px bg-gray-200 dark:bg-white/10" />

          {/* Apps Script */}
          <div className="space-y-2">
            <Label htmlFor="appsScriptUrl">Apps Script Web App URL</Label>
            <Input
              id="appsScriptUrl"
              placeholder="https://script.google.com/macros/s/AKfycb.../exec"
              value={appsScriptUrl}
              onChange={(e) => setAppsScriptUrl(e.target.value)}
            />
            {!looksLikeUrl(appsScriptUrl) && appsScriptUrl && (
              <p className="text-xs text-red-600">This does not look like a valid URL.</p>
            )}
            <p className="text-xs text-gray-600 dark:text-gray-300">
              Optional when Gmail API send is enabled. Used for send fallback and inbox sync.
            </p>
          </div>

          {/* Sheety */}
          <div className="space-y-2">
            <Label htmlFor="sheetyUrl">Sheety Emails Endpoint URL</Label>
            <Input
              id="sheetyUrl"
              placeholder="https://api.sheety.co/.../rkmEmails/emails"
              value={sheetyUrl}
              onChange={(e) => setSheetyUrl(e.target.value)}
            />
            {!looksLikeUrl(sheetyUrl) && sheetyUrl && (
              <p className="text-xs text-red-600">This does not look like a valid URL.</p>
            )}
            <p className="text-xs text-gray-600 dark:text-gray-300">Used by Apps Script syncInbox and server-side logging.</p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="sheetyToken">Sheety Token (optional)</Label>
            <Input
              id="sheetyToken"
              placeholder="Your Sheety bearer token (without the 'Bearer ' prefix)"
              value={sheetyToken}
              onChange={(e) => setSheetyToken(e.target.value)}
            />
            <p className="text-xs text-gray-600 dark:text-gray-300">Leave blank if your Sheety endpoint is public.</p>
          </div>

          {/* Sync options */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="md:col-span-2 space-y-2">
              <Label htmlFor="syncQuery">Sync Gmail Query</Label>
              <Input
                id="syncQuery"
                placeholder="in:inbox newer_than:7d -from:me"
                value={syncQuery}
                onChange={(e) => setSyncQuery(e.target.value)}
              />
              <p className="text-xs text-gray-600 dark:text-gray-300">Used by GmailApp.search when syncing via Apps Script.</p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="syncMaxThreads">Max Threads</Label>
              <Input
                id="syncMaxThreads"
                type="number"
                min={1}
                value={String(syncMaxThreads)}
                onChange={(e) => setSyncMaxThreads(parseInt(e.target.value || '50', 10))}
              />
              <p className="text-xs text-gray-600 dark:text-gray-300">How many threads to scan per sync.</p>
            </div>
          </div>

          <div className="flex items-center justify-end gap-2 pt-2">
            <Button variant="outline" onClick={onClose} className="bg-transparent">
              Cancel
            </Button>
            <Button
              onClick={handleSave}
              disabled={!canSave}
              className="bg-[#1a1a38] hover:bg-[#1a1a38]/90 text-white"
            >
              Save Settings
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export default EmailIntegrationSettings
