/** 
 * Header component with logo and theme toggle
 * - Dark mode uses deep navy (#0b1220) for strong contrast
 */
import React from 'react'
import { useTheme } from '../contexts/ThemeContext'
import { Button } from './ui/button'
import { Moon, Sun } from 'lucide-react'

/**
 * Header: shows brand and theme toggle
 */
const Header: React.FC = () => {
  const { isDark, toggleTheme } = useTheme()

  return (
    <header className={isDark ? 'bg-[#0b1220] text-white py-4 shadow-lg' : 'bg-[#1a1a38] text-white py-4 shadow-lg'}>
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between">
          {/* Logo + title */}
          <div className="flex items-center justify-center flex-1">
            <div className="flex items-center space-x-4">
              <img
                src="https://rkmfreightinc.com/wp-content/uploads/2025/05/logo-white.png"
                alt="RKM Freight Inc"
                className="h-12 w-auto object-contain"
              />
              <div className="text-center">
                <h1 className="text-xl font-bold">RKM Freight Inc</h1>
                <p className="text-sm opacity-80">CRM Lead Management</p>
              </div>
            </div>
          </div>

          {/* Theme toggle */}
          <Button
            variant="outline"
            size="icon"
            onClick={toggleTheme}
            className="bg-transparent border-white/20 text-white hover:bg-white/10 hover:text-white"
            aria-label="Toggle theme"
          >
            {isDark ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
          </Button>
        </div>
      </div>
    </header>
  )
}

export default Header
