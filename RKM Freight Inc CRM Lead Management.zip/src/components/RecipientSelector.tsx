/**
 * RecipientSelector component
 * - Searchable, multi-select modal to choose lead emails
 * - Provides Select All (on the filtered set), Clear, and Apply actions
 *
 * Props:
 * - leads: Lead[] (from Sheety)
 * - initialSelected: string[] (emails already selected)
 * - onApply(emails: string[]): void
 * - onClose(): void
 */

import React, { useMemo, useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card'
import { Button } from './ui/button'
import { Input } from './ui/input'
import { Lead } from '../services/sheetyApi'
import { Check, Search, X } from 'lucide-react'

interface RecipientSelectorProps {
  leads: Lead[]
  initialSelected?: string[]
  onApply: (emails: string[]) => void
  onClose: () => void
}

/** Normalize an email string for deduplication */
function norm(email: string) {
  return email.trim().toLowerCase()
}

/**
 * RecipientSelector: modal with search + multi-select for recipients
 */
const RecipientSelector: React.FC<RecipientSelectorProps> = ({ leads, initialSelected = [], onApply, onClose }) => {
  const [query, setQuery] = useState('')
  const [selected, setSelected] = useState<Record<string, boolean>>(() => {
    const map: Record<string, boolean> = {}
    initialSelected.forEach((e) => (map[norm(e)] = true))
    return map
  })

  const filtered = useMemo(() => {
    const q = query.toLowerCase()
    if (!q) return leads
    return leads.filter((l) =>
      [l.name, l.email, l.company]
        .filter(Boolean)
        .some((v) => String(v).toLowerCase().includes(q))
    )
  }, [leads, query])

  const allVisibleSelected = filtered.length > 0 && filtered.every((l) => selected[norm(l.email)] === true)
  const anyVisibleSelected = filtered.some((l) => selected[norm(l.email)] === true)
  const selectedCount = Object.values(selected).filter(Boolean).length

  const toggleItem = (email: string) => {
    const k = norm(email)
    setSelected((prev) => ({ ...prev, [k]: !prev[k] }))
  }

  const selectAllVisible = () => {
    setSelected((prev) => {
      const next = { ...prev }
      filtered.forEach((l) => (next[norm(l.email)] = true))
      return next
    })
  }

  const clearAllVisible = () => {
    setSelected((prev) => {
      const next = { ...prev }
      filtered.forEach((l) => (next[norm(l.email)] = false))
      return next
    })
  }

  const apply = () => {
    const emails = leads
      .map((l) => l.email)
      .filter((e) => !!e)
      .filter((e) => selected[norm(e)])
    onApply(Array.from(new Set(emails.map(norm))))
  }

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-3xl bg-white/95 backdrop-blur-sm border-white/20">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Select Recipients</CardTitle>
              <CardDescription>Search and choose multiple leads to email</CardDescription>
            </div>
            <Button variant="ghost" size="icon" className="bg-transparent hover:bg-gray-100" onClick={onClose}>
              <X className="h-4 w-4" />
            </Button>
          </div>
        </CardHeader>

        <CardContent className="space-y-4">
          <div className="flex gap-2 items-center">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search by name, email, or company"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <Button
              variant="outline"
              className="bg-transparent border-[#1a1a38]/20 text-[#1a1a38] hover:bg-[#1a1a38]/10"
              onClick={anyVisibleSelected ? clearAllVisible : selectAllVisible}
            >
              <Check className="h-4 w-4 mr-2" />
              {anyVisibleSelected ? 'Clear visible' : 'Select visible'}
            </Button>
          </div>

          <div className="max-h-[50vh] overflow-auto rounded-md border border-gray-200 divide-y bg-white/80">
            {filtered.length === 0 ? (
              <div className="p-6 text-center text-gray-600">No leads match your search.</div>
            ) : (
              filtered.map((l) => {
                const key = norm(l.email)
                const isSel = !!selected[key]
                return (
                  <label key={l.id || l.email} className="flex items-center gap-3 p-3 cursor-pointer hover:bg-gray-50">
                    <input
                      type="checkbox"
                      checked={isSel}
                      onChange={() => toggleItem(l.email)}
                      className="h-4 w-4 accent-[#1a1a38]"
                    />
                    <div className="flex-1">
                      <div className="font-medium text-[#1a1a38]">{l.name || l.email}</div>
                      <div className="text-xs text-gray-600">
                        {l.email}
                        {l.company ? ` • ${l.company}` : ''}
                      </div>
                    </div>
                  </label>
                )
              })
            )}
          </div>

          <div className="flex items-center justify-between">
            <div className="text-sm text-gray-600">
              Selected: <span className="font-medium text-[#1a1a38]">{selectedCount}</span>{' '}
              {allVisibleSelected ? '(All visible)' : ''}
            </div>
            <div className="flex gap-2">
              <Button variant="outline" onClick={onClose} className="bg-transparent">
                Cancel
              </Button>
              <Button onClick={apply} className="bg-[#1a1a38] hover:bg-[#1a1a38]/90 text-white">
                Add selected
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export default RecipientSelector
