/**
 * Add/Edit Lead Form component for creating or updating leads
 * - Extended fields: numberOfEmployees, jobTitle, industries, keywords
 * - Duplicate prevention: checks existing leads by email before create/update
 */

import React, { useEffect, useState } from 'react'
import { Button } from './ui/button'
import { Input } from './ui/input'
import { Label } from './ui/label'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card'
import { X, User, Mail, Building, MapPin, Phone, Briefcase, Hash, Tag } from 'lucide-react'
import { useToast } from '../hooks/use-toast'
import { createLead, updateLead, getLeads, Lead } from '../services/sheetyApi'

/** Props for the Add/Edit form */
interface AddLeadFormProps {
  /** Close the modal */
  onClose: () => void
  /** Called after a successful create/update (parent can reload list) */
  onSuccess: () => void
  /** If provided, the form will act in edit mode and prefill values */
  initial?: Partial<Lead> & { id?: string }
  /** Mode defaults to 'create' */
  mode?: 'create' | 'edit'
}

/** Local shape for managing input state */
interface LeadFormState {
  name: string
  email: string
  company: string
  address: string
  city: string
  state: string
  zipCode: string
  phone: string
  notes: string
  numberOfEmployees: string
  jobTitle: string
  industries: string
  keywords: string
}

/**
 * Map local form state to Lead payload for API
 */
function toLeadPayload(s: LeadFormState): Lead {
  const employees = s.numberOfEmployees.trim()
  const parsedEmployees = employees ? Number(employees.replace(/[^0-9]/g, '')) : undefined
  return {
    name: s.name.trim(),
    email: s.email.trim(),
    company: s.company.trim(),
    address: s.address.trim(),
    city: s.city.trim(),
    state: s.state.trim(),
    zipCode: s.zipCode.trim(),
    phone: s.phone.trim(),
    notes: s.notes.trim(),
    status: 'New',
    numberOfEmployees: parsedEmployees,
    jobTitle: s.jobTitle.trim(),
    industries: s.industries.trim(),
    keywords: s.keywords.trim(),
  }
}

/**
 * AddLeadForm (also supports editing when mode='edit')
 */
const AddLeadForm: React.FC<AddLeadFormProps> = ({ onClose, onSuccess, initial, mode = 'create' }) => {
  const [formData, setFormData] = useState<LeadFormState>({
    name: '',
    email: '',
    company: '',
    address: '',
    city: '',
    state: '',
    zipCode: '',
    phone: '',
    notes: '',
    numberOfEmployees: '',
    jobTitle: '',
    industries: '',
    keywords: '',
  })
  const [isLoading, setIsLoading] = useState(false)
  const { toast } = useToast()

  // Prefill when editing
  useEffect(() => {
    if (mode === 'edit' && initial) {
      setFormData({
        name: initial.name || '',
        email: initial.email || '',
        company: initial.company || '',
        address: initial.address || '',
        city: initial.city || '',
        state: initial.state || '',
        zipCode: initial.zipCode || '',
        phone: initial.phone || '',
        notes: initial.notes || '',
        numberOfEmployees: initial.numberOfEmployees ? String(initial.numberOfEmployees) : '',
        jobTitle: initial.jobTitle || '',
        industries: initial.industries || '',
        keywords: initial.keywords || '',
      })
    }
  }, [mode, initial])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    try {
      const payload = toLeadPayload(formData)
      // Duplicate prevention by email
      const all = await getLeads().catch(() => [])
      const emailKey = payload.email.toLowerCase()
      const conflict = (all || []).find((l: any) => String(l.email || '').toLowerCase() === emailKey)

      if (mode === 'edit') {
        const editingId = String(initial?.id || '')
        if (conflict && String(conflict.id) !== editingId) {
          toast({
            title: 'Duplicate email',
            description: 'Another lead with this email already exists.',
            variant: 'destructive',
          })
          setIsLoading(false)
          return
        }
        await updateLead(editingId, { ...(payload as Lead), status: initial?.status || 'New', id: editingId })
        toast({ title: 'Lead updated', description: 'Changes have been saved' })
      } else {
        if (conflict) {
          toast({
            title: 'Duplicate email',
            description: 'A lead with this email already exists. Creation blocked.',
            variant: 'destructive',
          })
          setIsLoading(false)
          return
        }
        await createLead({ ...payload })
        toast({ title: 'Lead created', description: 'New lead has been successfully added' })
      }

      onSuccess()
      onClose()
    } catch (error) {
      toast({
        title: mode === 'edit' ? 'Error updating lead' : 'Error creating lead',
        description: 'Please try again later.',
        variant: 'destructive',
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData((prev) => ({
      ...prev,
      [e.target.name]: e.target.value,
    }))
  }

  const isEdit = mode === 'edit'
  const inputDark = 'dark:bg-white/10 dark:text-white dark:placeholder:text-gray-400 dark:border-white/10'

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-2xl bg-white/95 backdrop-blur-sm border-white/20 dark:bg-white/5 dark:border-white/10">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>{isEdit ? 'Edit Lead' : 'Add New Lead'}</CardTitle>
              <CardDescription>
                {isEdit ? 'Update the lead information below' : 'Enter the lead information below'}
              </CardDescription>
            </div>
            <Button variant="ghost" size="icon" onClick={onClose} className="bg-transparent hover:bg-gray-100 dark:hover:bg-white/10" aria-label="Close">
              <X className="h-4 w-4" />
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Name */}
              <div className="space-y-2">
                <Label htmlFor="name" className="dark:text-white">Full Name</Label>
                <div className="relative">
                  <User className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                  <Input
                    id="name"
                    name="name"
                    placeholder="John Smith"
                    value={formData.name}
                    onChange={handleChange}
                    className={`pl-10 ${inputDark}`}
                    required
                  />
                </div>
              </div>

              {/* Email */}
              <div className="space-y-2">
                <Label htmlFor="email" className="dark:text-white">Email</Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    placeholder="john@example.com"
                    value={formData.email}
                    onChange={handleChange}
                    className={`pl-10 ${inputDark}`}
                    required
                  />
                </div>
              </div>

              {/* Company */}
              <div className="space-y-2">
                <Label htmlFor="company" className="dark:text-white">Company</Label>
                <div className="relative">
                  <Building className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                  <Input
                    id="company"
                    name="company"
                    placeholder="ABC Logistics"
                    value={formData.company}
                    onChange={handleChange}
                    className={`pl-10 ${inputDark}`}
                    required
                  />
                </div>
              </div>

              {/* Phone */}
              <div className="space-y-2">
                <Label htmlFor="phone" className="dark:text-white">Phone</Label>
                <div className="relative">
                  <Phone className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                  <Input
                    id="phone"
                    name="phone"
                    placeholder="(555) 123-4567"
                    value={formData.phone}
                    onChange={handleChange}
                    className={`pl-10 ${inputDark}`}
                  />
                </div>
              </div>

              {/* Address */}
              <div className="md:col-span-2 space-y-2">
                <Label htmlFor="address" className="dark:text-white">Address</Label>
                <div className="relative">
                  <MapPin className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                  <Input
                    id="address"
                    name="address"
                    placeholder="123 Main Street"
                    value={formData.address}
                    onChange={handleChange}
                    className={`pl-10 ${inputDark}`}
                    required
                  />
                </div>
              </div>

              {/* City */}
              <div className="space-y-2">
                <Label htmlFor="city" className="dark:text-white">City</Label>
                <Input
                  id="city"
                  name="city"
                  placeholder="Dallas"
                  value={formData.city}
                  onChange={handleChange}
                  className={inputDark}
                  required
                />
              </div>

              {/* State */}
              <div className="space-y-2">
                <Label htmlFor="state" className="dark:text-white">State</Label>
                <Input
                  id="state"
                  name="state"
                  placeholder="TX"
                  value={formData.state}
                  onChange={handleChange}
                  className={inputDark}
                  maxLength={2}
                  required
                />
              </div>

              {/* Zip */}
              <div className="space-y-2">
                <Label htmlFor="zipCode" className="dark:text-white">ZIP Code</Label>
                <Input
                  id="zipCode"
                  name="zipCode"
                  placeholder="75001"
                  value={formData.zipCode}
                  onChange={handleChange}
                  className={inputDark}
                  required
                />
              </div>

              {/* Job Title */}
              <div className="space-y-2">
                <Label htmlFor="jobTitle" className="dark:text-white">Job Title</Label>
                <div className="relative">
                  <Briefcase className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                  <Input
                    id="jobTitle"
                    name="jobTitle"
                    placeholder="Logistics Manager"
                    value={formData.jobTitle}
                    onChange={handleChange}
                    className={`pl-10 ${inputDark}`}
                  />
                </div>
              </div>

              {/* Number of Employees */}
              <div className="space-y-2">
                <Label htmlFor="numberOfEmployees" className="dark:text-white">Number of Employees</Label>
                <div className="relative">
                  <Hash className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                  <Input
                    id="numberOfEmployees"
                    name="numberOfEmployees"
                    placeholder="e.g., 200"
                    value={formData.numberOfEmployees}
                    onChange={handleChange}
                    className={`pl-10 ${inputDark}`}
                    inputMode="numeric"
                  />
                </div>
              </div>

              {/* Industries */}
              <div className="space-y-2">
                <Label htmlFor="industries" className="dark:text-white">Industries</Label>
                <div className="relative">
                  <Tag className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                  <Input
                    id="industries"
                    name="industries"
                    placeholder="Transportation; Logistics"
                    value={formData.industries}
                    onChange={handleChange}
                    className={`pl-10 ${inputDark}`}
                  />
                </div>
              </div>

              {/* Keywords */}
              <div className="space-y-2">
                <Label htmlFor="keywords" className="dark:text-white">Keywords</Label>
                <div className="relative">
                  <Tag className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                  <Input
                    id="keywords"
                    name="keywords"
                    placeholder="FTL; LTL; Dry Van"
                    value={formData.keywords}
                    onChange={handleChange}
                    className={`pl-10 ${inputDark}`}
                  />
                </div>
              </div>

              {/* Notes */}
              <div className="md:col-span-2 space-y-2">
                <Label htmlFor="notes" className="dark:text-white">Notes</Label>
                <Input
                  id="notes"
                  name="notes"
                  placeholder="Additional notes about this lead..."
                  value={formData.notes}
                  onChange={handleChange}
                  className={inputDark}
                />
              </div>
            </div>

            <div className="flex justify-end space-x-3 pt-4">
              <Button type="button" variant="outline" onClick={onClose} className="bg-transparent dark:border-white/15 dark:text-white dark:hover:bg-white/10">
                Cancel
              </Button>
              <Button type="submit" disabled={isLoading} className="bg-[#1a1a38] hover:bg-[#1a1a38]/90">
                {isLoading ? (isEdit ? 'Saving...' : 'Adding Lead...') : isEdit ? 'Save Changes' : 'Add Lead'}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}

export default AddLeadForm
