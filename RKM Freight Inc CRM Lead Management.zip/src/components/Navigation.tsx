/** 
 * Navigation component for authenticated users
 * - Dark theme: nav buttons use #0c0d19 background with white text
 * - Light theme: active = dark blue, inactive = outline dark blue
 */
import React from 'react'
import { Link, useLocation } from 'react-router'
import { useAuth } from '../contexts/AuthContext'
import { useTheme } from '../contexts/ThemeContext'
import { Button } from './ui/button'
import { LayoutDashboard, Users, Mail, LogOut, UserCog } from 'lucide-react'

/**
 * Navigation: shows app sections and logout
 */
const Navigation: React.FC = () => {
  const { user, logout } = useAuth()
  const location = useLocation()
  const { isDark } = useTheme()

  const navItems = [
    { path: '/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
    { path: '/leads', icon: Users, label: 'Manage Leads' },
    { path: '/users', icon: UserCog, label: 'Manage Users' },
    { path: '/inbox', icon: Mail, label: 'Inbox' },
  ]

  /** Build button classes per theme and active state */
  const btnClasses = (active: boolean) => {
    if (isDark) {
      // Dark theme: all nav buttons use #0c0d19
      return 'bg-[#0c0d19] text-white hover:bg-[#0c0d19]/90 border-white/10'
    }
    // Light theme: active filled, inactive outline
    return active
      ? 'bg-[#1a1a38] text-white hover:bg-[#1a1a38]/90'
      : 'bg-transparent border-[#1a1a38]/20 text-[#1a1a38] hover:bg-[#1a1a38]/10'
  }

  return (
    <nav className="bg-white/80 dark:bg-white/10 backdrop-blur-sm rounded-lg shadow-sm border border-white/20 dark:border-white/10 p-4 mb-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          {navItems.map((item) => {
            const Icon = item.icon
            const isActive = location.pathname === item.path

            return (
              <Link key={item.path} to={item.path}>
                <Button
                  variant="outline"
                  className={btnClasses(isActive)}
                >
                  <Icon className="h-4 w-4 mr-2" />
                  {item.label}
                </Button>
              </Link>
            )
          })}
        </div>

        <div className="flex items-center space-x-4">
          <span className="text-sm text-gray-700 dark:text-gray-300">Welcome, {user?.name}</span>
          <Button
            variant="outline"
            onClick={logout}
            className="bg-transparent border-red-200 text-red-600 hover:bg-red-50 dark:hover:bg-white/10 dark:text-red-300 dark:border-red-300/30"
          >
            <LogOut className="h-4 w-4 mr-2" />
            Logout
          </Button>
        </div>
      </div>
    </nav>
  )
}

export default Navigation
