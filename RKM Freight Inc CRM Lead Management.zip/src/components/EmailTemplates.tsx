/**
 * EmailTemplates: Small picker of canned email templates.
 * Props:
 * - onSelect: callback receiving subject and html body
 */

import React from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card'
import { Button } from './ui/button'

interface EmailTemplatesProps {
  onSelect: (subject: string, body: string) => void
}

interface Template {
  id: string
  name: string
  subject: string
  body: string
}

/** Static templates for quick composing */
const templates: Template[] = [
  {
    id: 'intro',
    name: 'Introduction',
    subject: 'Freight solutions for your logistics needs',
    body: `<p>Hello,</p>
<p>I'm reaching out from RKM Freight Inc. We provide reliable and cost-effective freight solutions across Texas and beyond.</p>
<p>Would you be open to a quick call to discuss your current lanes and challenges?</p>
<p>Best regards,<br/>RKM Freight Inc</p>`,
  },
  {
    id: 'followup',
    name: 'Follow Up',
    subject: 'Quick follow-up regarding freight support',
    body: `<p>Hi,</p>
<p>Just following up on my previous email. If you have any upcoming loads or current service gaps, we can help.</p>
<p>Happy to share a lane proposal tailored to your needs.</p>
<p>Thanks,<br/>RKM Freight Inc</p>`,
  },
  {
    id: 'quote',
    name: 'Request a Quote',
    subject: 'Can we quote your upcoming loads?',
    body: `<p>Hello,</p>
<p>We'd love the opportunity to quote your upcoming shipments. Please share lanes, volumes, and requirements.</p>
<p>We'll respond quickly with competitive rates and capacity.</p>
<p>Regards,<br/>RKM Freight Inc</p>`,
  },
]

/**
 * EmailTemplates component: list with "Use Template" actions
 */
const EmailTemplates: React.FC<EmailTemplatesProps> = ({ onSelect }) => {
  return (
    <Card className="bg-white/80 backdrop-blur-sm border-white/20">
      <CardHeader>
        <CardTitle>Email Templates</CardTitle>
        <CardDescription>Speed up composing with curated templates</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {templates.map((t) => (
            <div key={t.id} className="border rounded-lg p-4 bg-white/70">
              <h4 className="font-semibold text-[#1a1a38]">{t.name}</h4>
              <p className="text-xs text-gray-600 mt-1 line-clamp-3">{t.subject}</p>
              <Button
                className="mt-3 bg-[#1a1a38] hover:bg-[#1a1a38]/90 text-white w-full"
                onClick={() => onSelect(t.subject, t.body)}
              >
                Use Template
              </Button>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}

export default EmailTemplates
