/**
 * RichTextEditor: Minimal WYSIWYG HTML editor with Bold/Italic, color, and text size controls.
 * - Uses a contenteditable div and document.execCommand for broad browser compatibility.
 * - Emits HTML via onChange so parent can store/send raw HTML.
 */

import React, { useEffect, useRef } from 'react'
import { Button } from '../../components/ui/button'
import { Label } from '../../components/ui/label'
import { Bold, Italic, Palette, Type as TypeIcon } from 'lucide-react'

/** Props for RichTextEditor */
export interface RichTextEditorProps {
  /** HTML content value */
  value: string
  /** Emit new HTML on user input */
  onChange: (html: string) => void
  /** Optional placeholder text (visual only when empty) */
  placeholder?: string
  /** Optional additional classes */
  className?: string
}

/**
 * runCommand: Execute a document.execCommand with optional value.
 * Ensures the editor is focused before running the command.
 */
function runCommand(editor: HTMLDivElement | null, command: string, value?: string) {
  if (!editor) return
  editor.focus()
  try {
    document.execCommand(command, false, value)
  } catch {
    // swallow; execCommand can be unsupported in some niche environments
  }
}

/** Preset size mapping to execCommand('fontSize') levels (1-7). */
const SIZE_MAP: Record<string, string> = {
  small: '2',
  normal: '3',
  large: '4',
  title: '5',
}

/**
 * RichTextEditor component
 * - Toolbar: Bold, Italic, Color, Size
 * - Content: contenteditable host reflecting `value` as innerHTML
 */
const RichTextEditor: React.FC<RichTextEditorProps> = ({
  value,
  onChange,
  placeholder = 'Write your message...',
  className,
}) => {
  const editorRef = useRef<HTMLDivElement | null>(null)
  const internalHtmlRef = useRef<string>('')

  // Sync external value -> editor when it changes.
  useEffect(() => {
    if (!editorRef.current) return
    if (internalHtmlRef.current !== value) {
      editorRef.current.innerHTML = value || ''
      internalHtmlRef.current = value || ''
    }
  }, [value])

  /** Handle input events and bubble up new HTML */
  const handleInput: React.FormEventHandler<HTMLDivElement> = () => {
    const html = editorRef.current?.innerHTML || ''
    internalHtmlRef.current = html
    onChange(html)
  }

  /** Apply foreColor with color input */
  const handleColorChange: React.ChangeEventHandler<HTMLInputElement> = (e) => {
    const color = e.target.value
    runCommand(editorRef.current, 'foreColor', color)
  }

  /** Apply font size preset */
  const handleSizeChange: React.ChangeEventHandler<HTMLSelectElement> = (e) => {
    const key = e.target.value
    const mapped = SIZE_MAP[key] || SIZE_MAP.normal
    runCommand(editorRef.current, 'fontSize', mapped)
    // Keep focus on editor for continuous editing
    editorRef.current?.focus()
  }

  // For visual placeholder: render a subdued text hint when empty
  const isEmpty = !value || value.replace(/<[^>]+>/g, '').trim().length === 0

  return (
    <div className={className}>
      {/* Toolbar */}
      <div className="flex flex-wrap items-center gap-2 p-2 rounded-t-md border border-b-0 border-[#1a1a38]/20 dark:border-white/20 bg-white/60 dark:bg-white/10">
        <div className="flex items-center gap-1">
          <Button
            type="button"
            variant="outline"
            className="h-8 px-2 bg-transparent text-[#1a1a38] border-[#1a1a38]/20 hover:bg-[#1a1a38]/10 dark:text-white dark:border-white/20 dark:hover:bg-white/10"
            onMouseDown={(e) => e.preventDefault()}
            onClick={() => runCommand(editorRef.current, 'bold')}
            aria-label="Bold"
            title="Bold"
          >
            <Bold className="h-4 w-4" />
          </Button>
          <Button
            type="button"
            variant="outline"
            className="h-8 px-2 bg-transparent text-[#1a1a38] border-[#1a1a38]/20 hover:bg-[#1a1a38]/10 dark:text-white dark:border-white/20 dark:hover:bg-white/10"
            onMouseDown={(e) => e.preventDefault()}
            onClick={() => runCommand(editorRef.current, 'italic')}
            aria-label="Italic"
            title="Italic"
          >
            <Italic className="h-4 w-4" />
          </Button>
        </div>

        <div className="h-5 w-px bg-black/10 dark:bg-white/20 mx-1" />

        {/* Color picker */}
        <div className="flex items-center gap-2">
          <Palette className="h-4 w-4 text-[#1a1a38] dark:text-white" />
          <input
            type="color"
            onChange={handleColorChange}
            onMouseDown={(e) => e.preventDefault()}
            className="h-8 w-10 p-0 border rounded cursor-pointer bg-transparent"
            aria-label="Text color"
            title="Text color"
          />
          {/* Quick swatches */}
          <div className="flex items-center gap-1">
            {['#1a1a38', '#f47b20', '#2563eb', '#16a34a', '#ef4444', '#374151'].map((c) => (
              <button
                key={c}
                type="button"
                onMouseDown={(e) => e.preventDefault()}
                onClick={() => handleColorChange({ target: { value: c } } as any)}
                className="h-5 w-5 rounded border border-black/10 dark:border-white/20"
                style={{ backgroundColor: c }}
                aria-label={`Apply color ${c}`}
                title={c}
              />
            ))}
          </div>
        </div>

        <div className="h-5 w-px bg-black/10 dark:bg-white/20 mx-1" />

        {/* Font size */}
        <div className="flex items-center gap-2">
          <TypeIcon className="h-4 w-4 text-[#1a1a38] dark:text-white" />
          <Label htmlFor="rte-size" className="text-xs text-[#1a1a38] dark:text-white">
            Size
          </Label>
          <select
            id="rte-size"
            onChange={handleSizeChange}
            onMouseDown={(e) => e.preventDefault()}
            className="h-8 rounded border border-[#1a1a38]/20 dark:border-white/20 bg-transparent px-2 text-sm"
            defaultValue="normal"
            aria-label="Text size"
            title="Text size"
          >
            <option value="small">Small</option>
            <option value="normal">Normal</option>
            <option value="large">Large</option>
            <option value="title">Title</option>
          </select>
        </div>
      </div>

      {/* Editable area */}
      <div
        ref={editorRef}
        role="textbox"
        aria-multiline="true"
        contentEditable
        spellCheck={true}
        onInput={handleInput}
        className="min-h-[220px] p-3 rounded-b-md border border-t-0 border-[#1a1a38]/20 dark:border-white/20 bg-white/90 dark:bg-transparent text-sm prose prose-sm max-w-none dark:prose-invert focus:outline-none"
        data-placeholder={placeholder}
        // Visual placeholder pattern: show hint when empty
        style={
          isEmpty
            ? {
                position: 'relative',
                backgroundImage:
                  `linear-gradient(transparent, transparent), linear-gradient(transparent, transparent)`,
              }
            : undefined
        }
        suppressContentEditableWarning
      />

      {isEmpty && (
        <div className="pointer-events-none -mt-[200px] ml-4 text-gray-400 text-sm select-none">
          {placeholder}
        </div>
      )}
    </div>
  )
}

export default RichTextEditor
