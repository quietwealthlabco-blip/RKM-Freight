/**
 * LeadsTable: Filterable, sortable, groupable leads table with optional frozen columns and selection.
 * - Per-column filters appear in a second header row under labels.
 * - Sorting: click header to toggle asc/desc; distance supports nearest/farthest.
 * - Group by: status, city (address), employees (bucketed), industries.
 * - Selection: leftmost checkbox per row + header "select all" (applies to the current filtered view).
 * - Optional frozen columns: sticky selection and name columns for better usability on wide tables.
 */

import React, { useMemo } from 'react'
import { Button } from '../ui/button'
import { Input } from '../ui/input'
import { Card, CardContent } from '../ui/card'
import { Edit, Mail, Trash2, ArrowUpDown } from 'lucide-react'
import type { Lead } from '../../services/sheetyApi'

/** Sortable keys supported by the table */
export type SortKey =
  | 'name'
  | 'email'
  | 'company'
  | 'city'
  | 'state'
  | 'zipCode'
  | 'status'
  | 'numberOfEmployees'
  | 'distance'

/** Sort specification */
export interface SortSpec {
  key: SortKey
  dir: 'asc' | 'desc'
}

/** Group by options */
export type GroupByOption = 'none' | 'status' | 'city' | 'employees' | 'industries'

/** Column-level filters */
export interface LeadsFilters {
  name?: string
  email?: string
  company?: string
  city?: string
  state?: string
  zipCode?: string
  status?: string
  jobTitle?: string
  industries?: string
  keywords?: string
  minEmployees?: string
  maxEmployees?: string
}

/** Props for LeadsTable */
interface LeadsTableProps {
  /** Full leads dataset (already loaded) */
  leads: Lead[]
  /** Loading flag for spinner/empty state */
  loading?: boolean
  /** Global query from page-level search (applied in addition to column filters) */
  globalQuery?: string

  /** Selection state (ids) */
  selectedIds: Set<string>
  onToggleSelect: (id: string, checked: boolean) => void
  onToggleSelectAll: (checked: boolean, idsInView: string[]) => void

  /** Row actions */
  onEdit: (lead: Lead) => void
  onDelete: (id: string) => void
  onComposeLead: (lead: Lead) => void

  /** UI state: filters, sort, group, frozen columns */
  filters: LeadsFilters
  setFilters: (next: LeadsFilters) => void
  sort: SortSpec
  setSort: (next: SortSpec) => void
  groupBy: GroupByOption
  setGroupBy: (v: GroupByOption) => void
  freezeColumns?: boolean
}

/** Case-insensitive includes helper */
function includesI(hay: string | undefined, needle: string | undefined): boolean {
  if (!needle) return true
  return (hay || '').toLowerCase().includes(needle.toLowerCase())
}

/** Parse an integer safely from string filter */
function parseIntSafe(s?: string): number | null {
  if (!s || !s.trim()) return null
  const n = parseInt(s.replace(/[^0-9-]/g, ''), 10)
  return Number.isFinite(n) ? n : null
}

/** Sort comparator factory */
function comparator(sort: SortSpec) {
  const dir = sort.dir === 'asc' ? 1 : -1
  return (a: Lead, b: Lead) => {
    const k = sort.key
    let va: any
    let vb: any
    switch (k) {
      case 'numberOfEmployees':
        va = typeof a.numberOfEmployees === 'number' ? a.numberOfEmployees : Number.NEGATIVE_INFINITY
        vb = typeof b.numberOfEmployees === 'number' ? b.numberOfEmployees : Number.NEGATIVE_INFINITY
        break
      case 'distance':
        // Undefined distances should go to the end in asc (nearest first)
        va = typeof a.distance === 'number' ? a.distance : Number.POSITIVE_INFINITY
        vb = typeof b.distance === 'number' ? b.distance : Number.POSITIVE_INFINITY
        break
      default:
        va = String((a as any)[k] || '').toLowerCase()
        vb = String((b as any)[k] || '').toLowerCase()
    }
    if (va < vb) return -1 * dir
    if (va > vb) return 1 * dir
    return 0
  }
}

/** Bucket employees for grouping */
function employeesBucket(n?: number): string {
  if (!n || n <= 0) return 'Unknown'
  if (n < 50) return '1–49'
  if (n < 200) return '50–199'
  if (n < 1000) return '200–999'
  return '1000+'
}

/** Apply filters and global search */
function applyFilters(leads: Lead[], filters: LeadsFilters, global?: string): Lead[] {
  const minEmp = parseIntSafe(filters.minEmployees)
  const maxEmp = parseIntSafe(filters.maxEmployees)

  return leads.filter((l) => {
    // Global search across common fields
    if (global && global.trim()) {
      const g = global.toLowerCase()
      const hay =
        [
          l.name,
          l.email,
          l.company,
          l.address,
          l.city,
          l.state,
          l.zipCode,
          l.jobTitle,
          l.industries,
          l.keywords,
        ]
          .map((x) => (x || '').toLowerCase())
          .join(' ')
      if (!hay.includes(g)) return false
    }

    // Column filters
    if (!includesI(l.name, filters.name)) return false
    if (!includesI(l.email, filters.email)) return false
    if (!includesI(l.company, filters.company)) return false
    if (!includesI(l.city, filters.city)) return false
    if (!includesI(l.state, filters.state)) return false
    if (!includesI(l.zipCode, filters.zipCode)) return false
    if (!includesI(l.jobTitle, filters.jobTitle)) return false
    if (!includesI(l.industries, filters.industries)) return false
    if (!includesI(l.keywords, filters.keywords)) return false
    if (filters.status && String(l.status || '').toLowerCase() !== filters.status.toLowerCase()) return false

    // Employee range
    const emp = typeof l.numberOfEmployees === 'number' ? l.numberOfEmployees : null
    if (minEmp !== null && (emp === null || emp < minEmp)) return false
    if (maxEmp !== null && (emp === null || emp > maxEmp)) return false

    return true
  })
}

/** Build grouping map */
function groupItems(items: Lead[], groupBy: GroupByOption): Array<{ key: string; items: Lead[] }> {
  if (!items.length || groupBy === 'none') {
    return [{ key: 'All', items }]
  }
  const map = new Map<string, Lead[]>()

  for (const l of items) {
    let g = 'Other'
    if (groupBy === 'status') g = String(l.status || 'Other')
    else if (groupBy === 'city') g = String(l.city || 'Unknown')
    else if (groupBy === 'industries') g = String(l.industries || 'Unknown')
    else if (groupBy === 'employees') g = employeesBucket(l.numberOfEmployees)

    const arr = map.get(g) || []
    arr.push(l)
    map.set(g, arr)
  }

  // Sort groups alphabetically, but keep 'Unknown' or 'Other' last
  const entries = Array.from(map.entries())
  entries.sort((a, b) => {
    const special = (s: string) => (s === 'Unknown' || s === 'Other' ? '~~~' : s.toLowerCase())
    return special(a[0]).localeCompare(special(b[0]))
  })
  return entries.map(([key, arr]) => ({ key, items: arr }))
}

/** Column header with sort toggle */
function SortableHeader({
  label,
  sortKey,
  current,
  onChange,
}: {
  label: string
  sortKey: SortKey
  current: SortSpec
  onChange: (next: SortSpec) => void
}) {
  const active = current.key === sortKey
  const dir = active ? current.dir : undefined
  return (
    <button
      type="button"
      className="flex items-center gap-1 font-medium text-left"
      onClick={() =>
        onChange({
          key: sortKey,
          dir: active && current.dir === 'asc' ? 'desc' : 'asc',
        })
      }
      title="Toggle sort"
    >
      {label}
      <ArrowUpDown className={'h-3.5 w-3.5 ' + (active ? 'text-[#1a1a38] dark:text-white' : 'text-gray-400')} />
      {dir ? <span className="sr-only">({dir})</span> : null}
    </button>
  )
}

/**
 * LeadsTable component
 */
const LeadsTable: React.FC<LeadsTableProps> = ({
  leads,
  loading,
  globalQuery,
  selectedIds,
  onToggleSelect,
  onToggleSelectAll,
  onEdit,
  onDelete,
  onComposeLead,
  filters,
  setFilters,
  sort,
  setSort,
  groupBy,
  setGroupBy,
  freezeColumns = true,
}) => {
  const filtered = useMemo(() => applyFilters(leads, filters, globalQuery), [leads, filters, globalQuery])
  const sorted = useMemo(() => {
    const arr = [...filtered]
    arr.sort(comparator(sort))
    return arr
  }, [filtered, sort])

  const groups = useMemo(() => groupItems(sorted, groupBy), [sorted, groupBy])

  // IDs in view for "select all"
  const visibleIds = useMemo(() => sorted.map((l) => String(l.id)), [sorted])

  // Helpers
  const isAllSelected = visibleIds.length > 0 && visibleIds.every((id) => selectedIds.has(String(id)))
  const isSomeSelected = !isAllSelected && visibleIds.some((id) => selectedIds.has(String(id)))

  const stickyBase =
    'sticky z-20 bg-white/95 dark:bg-[#0b1020]/60 backdrop-blur-sm border-b border-white/20 dark:border-white/10'
  const stickyCell =
    'sticky z-10 bg-white/95 dark:bg-[#0b1020]/60 backdrop-blur-sm border-b border-white/20 dark:border-white/10'

  return (
    <Card className="bg-white/80 backdrop-blur-sm border-white/20 dark:bg-white/5 dark:border-white/10">
      <CardContent className="pt-4 overflow-x-auto">
        {/* Controls row */}
        <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between mb-3">
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2">
              <label className="text-sm">Group by</label>
              <select
                className="text-sm rounded-md border bg-white/70 dark:bg-white/10 dark:border-white/15"
                value={groupBy}
                onChange={(e) => setGroupBy(e.target.value as GroupByOption)}
              >
                <option value="none">None</option>
                <option value="status">Status</option>
                <option value="city">Address (City)</option>
                <option value="employees"># of Employees (bucket)</option>
                <option value="industries">Industry</option>
              </select>
            </div>

            <div className="flex items-center gap-2">
              <label className="text-sm">Freeze columns</label>
              <input
                type="checkbox"
                checked={freezeColumns}
                onChange={() => {
                  // Toggle via parent by flipping boolean in props if needed; kept internal for ui feel
                }}
                className="h-4 w-4"
                onClick={(e) => e.preventDefault()}
                title="This demo table always freezes first columns for best UX"
              />
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs text-gray-600 dark:text-gray-300">
              Showing {sorted.length} of {leads.length}
            </span>
            <Button
              variant="outline"
              className="bg-transparent h-8"
              onClick={() =>
                setFilters({
                  name: '',
                  email: '',
                  company: '',
                  city: '',
                  state: '',
                  zipCode: '',
                  status: '',
                  jobTitle: '',
                  industries: '',
                  keywords: '',
                  minEmployees: '',
                  maxEmployees: '',
                })
              }
            >
              Clear filters
            </Button>
          </div>
        </div>

        {/* Table */}
        <div className="min-w-[1200px]">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-white/20 dark:border-white/10">
                {/* Select all */}
                <th
                  className={(freezeColumns ? stickyBase : '') + ' w-10 p-2'}
                  style={freezeColumns ? { left: 0 } : undefined}
                >
                  <input
                    type="checkbox"
                    checked={isAllSelected}
                    ref={(el) => {
                      if (el) el.indeterminate = isSomeSelected
                    }}
                    onChange={(e) => onToggleSelectAll(e.target.checked, visibleIds)}
                    aria-label="Select all"
                    className="h-4 w-4"
                  />
                </th>

                {/* Name (frozen second) */}
                <th
                  className={(freezeColumns ? stickyBase : '') + ' p-2 text-left'}
                  style={freezeColumns ? { left: 40 } : undefined}
                >
                  <SortableHeader label="Name" sortKey="name" current={sort} onChange={setSort} />
                </th>

                <th className="p-2 text-left">
                  <SortableHeader label="Email" sortKey="email" current={sort} onChange={setSort} />
                </th>
                <th className="p-2 text-left">
                  <SortableHeader label="Company" sortKey="company" current={sort} onChange={setSort} />
                </th>
                <th className="p-2 text-left">
                  <SortableHeader label="City" sortKey="city" current={sort} onChange={setSort} />
                </th>
                <th className="p-2 text-left">
                  <SortableHeader label="State" sortKey="state" current={sort} onChange={setSort} />
                </th>
                <th className="p-2 text-left">
                  <SortableHeader label="ZIP" sortKey="zipCode" current={sort} onChange={setSort} />
                </th>
                <th className="p-2 text-left">
                  <SortableHeader label="Job Title" sortKey="status" current={sort} onChange={setSort} />
                </th>
                <th className="p-2 text-left">
                  <SortableHeader label="# Employees" sortKey="numberOfEmployees" current={sort} onChange={setSort} />
                </th>
                <th className="p-2 text-left">
                  <SortableHeader label="Industry" sortKey="industries" current={sort} onChange={setSort} />
                </th>
                <th className="p-2 text-left">
                  <SortableHeader label="Keywords" sortKey="name" current={sort} onChange={setSort} />
                </th>
                <th className="p-2 text-left">
                  <SortableHeader label="Status" sortKey="status" current={sort} onChange={setSort} />
                </th>
                <th className="p-2 text-left">
                  <SortableHeader label="Distance (mi)" sortKey="distance" current={sort} onChange={setSort} />
                </th>
                <th className="p-2 text-left">Actions</th>
              </tr>

              {/* Filters row */}
              <tr className="border-b border-white/20 dark:border-white/10">
                {/* select all spacer */}
                <th
                  className={(freezeColumns ? stickyBase : '') + ' w-10 p-2'}
                  style={freezeColumns ? { left: 0 } : undefined}
                />
                {/* Name (frozen) */}
                <th
                  className={(freezeColumns ? stickyBase : '') + ' p-2'}
                  style={freezeColumns ? { left: 40 } : undefined}
                >
                  <Input
                    placeholder="Filter name"
                    value={filters.name || ''}
                    onChange={(e) => setFilters({ ...filters, name: e.target.value })}
                    className="h-8 text-xs dark:bg-white/10 dark:border-white/10"
                  />
                </th>

                <th className="p-2">
                  <Input
                    placeholder="Filter email"
                    value={filters.email || ''}
                    onChange={(e) => setFilters({ ...filters, email: e.target.value })}
                    className="h-8 text-xs dark:bg-white/10 dark:border-white/10"
                  />
                </th>
                <th className="p-2">
                  <Input
                    placeholder="Filter company"
                    value={filters.company || ''}
                    onChange={(e) => setFilters({ ...filters, company: e.target.value })}
                    className="h-8 text-xs dark:bg-white/10 dark:border-white/10"
                  />
                </th>
                <th className="p-2">
                  <Input
                    placeholder="Filter city"
                    value={filters.city || ''}
                    onChange={(e) => setFilters({ ...filters, city: e.target.value })}
                    className="h-8 text-xs dark:bg-white/10 dark:border-white/10"
                  />
                </th>
                <th className="p-2">
                  <Input
                    placeholder="Filter state"
                    value={filters.state || ''}
                    onChange={(e) => setFilters({ ...filters, state: e.target.value })}
                    className="h-8 text-xs dark:bg-white/10 dark:border-white/10"
                  />
                </th>
                <th className="p-2">
                  <Input
                    placeholder="Filter ZIP"
                    value={filters.zipCode || ''}
                    onChange={(e) => setFilters({ ...filters, zipCode: e.target.value })}
                    className="h-8 text-xs dark:bg-white/10 dark:border-white/10"
                  />
                </th>
                <th className="p-2">
                  <Input
                    placeholder="Filter job title"
                    value={filters.jobTitle || ''}
                    onChange={(e) => setFilters({ ...filters, jobTitle: e.target.value })}
                    className="h-8 text-xs dark:bg-white/10 dark:border-white/10"
                  />
                </th>
                <th className="p-2">
                  <div className="flex items-center gap-1">
                    <Input
                      placeholder="Min"
                      value={filters.minEmployees || ''}
                      onChange={(e) => setFilters({ ...filters, minEmployees: e.target.value })}
                      className="h-8 text-xs w-20 dark:bg-white/10 dark:border-white/10"
                    />
                    <span className="text-xs text-gray-500">–</span>
                    <Input
                      placeholder="Max"
                      value={filters.maxEmployees || ''}
                      onChange={(e) => setFilters({ ...filters, maxEmployees: e.target.value })}
                      className="h-8 text-xs w-20 dark:bg-white/10 dark:border-white/10"
                    />
                  </div>
                </th>
                <th className="p-2">
                  <Input
                    placeholder="Filter industry"
                    value={filters.industries || ''}
                    onChange={(e) => setFilters({ ...filters, industries: e.target.value })}
                    className="h-8 text-xs dark:bg-white/10 dark:border-white/10"
                  />
                </th>
                <th className="p-2">
                  <Input
                    placeholder="Filter keywords"
                    value={filters.keywords || ''}
                    onChange={(e) => setFilters({ ...filters, keywords: e.target.value })}
                    className="h-8 text-xs dark:bg-white/10 dark:border-white/10"
                  />
                </th>
                <th className="p-2">
                  <Input
                    placeholder="Filter status"
                    value={filters.status || ''}
                    onChange={(e) => setFilters({ ...filters, status: e.target.value })}
                    className="h-8 text-xs dark:bg-white/10 dark:border-white/10"
                  />
                </th>
                <th className="p-2 text-xs text-gray-500">—</th>
                <th className="p-2 text-xs text-gray-500">—</th>
              </tr>
            </thead>

            <tbody>
              {loading ? (
                <tr>
                  <td colSpan={14} className="py-8 text-center">
                    <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-[#1a1a38] dark:border-white mx-auto" />
                    <p className="text-gray-700 dark:text-gray-300 mt-2 text-sm">Loading leads...</p>
                  </td>
                </tr>
              ) : groups.every((g) => g.items.length === 0) ? (
                <tr>
                  <td colSpan={14} className="py-8 text-center text-gray-600 dark:text-gray-300">
                    No results. Try adjusting filters.
                  </td>
                </tr>
              ) : (
                groups.map((g, gi) => (
                  <React.Fragment key={gi}>
                    {/* Group header */}
                    {groupBy !== 'none' && (
                      <tr>
                        <td colSpan={14} className="bg-white/60 dark:bg-white/5 text-xs uppercase tracking-wide p-2">
                          <span className="font-semibold">{g.key}</span>
                          <span className="text-gray-500 ml-2">{g.items.length}</span>
                        </td>
                      </tr>
                    )}
                    {g.items.map((lead) => {
                      const checked = selectedIds.has(String(lead.id))
                      return (
                        <tr
                          key={lead.id}
                          className="border-b border-gray-100 dark:border-white/10 hover:bg-white/50 dark:hover:bg-white/5 transition-colors"
                        >
                          {/* Selection cell (frozen) */}
                          <td
                            className={(freezeColumns ? stickyCell : '') + ' w-10 p-2'}
                            style={freezeColumns ? { left: 0 } : undefined}
                          >
                            <input
                              type="checkbox"
                              className="h-4 w-4"
                              checked={checked}
                              onChange={(e) => onToggleSelect(String(lead.id), e.target.checked)}
                              aria-label={`Select ${lead.name}`}
                            />
                          </td>

                          {/* Name (frozen) */}
                          <td
                            className={(freezeColumns ? stickyCell : '') + ' p-2 font-medium whitespace-nowrap'}
                            style={freezeColumns ? { left: 40 } : undefined}
                          >
                            {lead.name || '—'}
                          </td>

                          <td className="p-2 whitespace-nowrap">{lead.email || '—'}</td>
                          <td className="p-2 whitespace-nowrap">{lead.company || '—'}</td>
                          <td className="p-2 whitespace-nowrap">{lead.city || '—'}</td>
                          <td className="p-2 whitespace-nowrap">{lead.state || '—'}</td>
                          <td className="p-2 whitespace-nowrap">{lead.zipCode || '—'}</td>
                          <td className="p-2 whitespace-nowrap">{lead.jobTitle || '—'}</td>
                          <td className="p-2 whitespace-nowrap">
                            {typeof lead.numberOfEmployees === 'number' ? lead.numberOfEmployees : '—'}
                          </td>
                          <td className="p-2">
                            <div className="max-w-[12rem] truncate">{lead.industries || '—'}</div>
                          </td>
                          <td className="p-2">
                            <div className="max-w-[12rem] truncate">{lead.keywords || '—'}</div>
                          </td>
                          <td className="p-2 whitespace-nowrap">{lead.status || '—'}</td>
                          <td className="p-2 whitespace-nowrap">
                            {typeof lead.distance === 'number' ? `${lead.distance.toFixed(1)} mi` : '—'}
                          </td>
                          <td className="p-2">
                            <div className="flex space-x-2">
                              <Button
                                variant="outline"
                                size="sm"
                                className="bg-transparent border-[#1a1a38]/20 text-[#1a1a38] hover:bg-[#1a1a38]/10 dark:border-white/15 dark:text-white dark:hover:bg-white/10"
                                onClick={() => onEdit(lead)}
                                title="Edit"
                              >
                                <Edit className="h-3 w-3 mr-1" />
                                Edit
                              </Button>
                              <Button
                                variant="outline"
                                size="sm"
                                className="bg-transparent border-[#f47b20] text-[#f47b20] hover:bg-[#f47b20]/10"
                                onClick={() => onComposeLead(lead)}
                                title="Email"
                              >
                                <Mail className="h-3 w-3 mr-1" />
                                Email
                              </Button>
                              <Button
                                variant="outline"
                                size="sm"
                                className="bg-transparent border-red-200 text-red-600 hover:bg-red-50 dark:border-red-300/30 dark:text-red-300 dark:hover:bg-white/10"
                                onClick={() => onDelete(lead.id!)}
                                title="Delete"
                              >
                                <Trash2 className="h-3 w-3 mr-1" />
                                Delete
                              </Button>
                            </div>
                          </td>
                        </tr>
                      )
                    })}
                  </React.Fragment>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Select all footer helper for mobile (optional)
            Left out to keep UI compact.
        */}
      </CardContent>
    </Card>
  )
}

export default LeadsTable
