/**
 * CSV Upload component for bulk lead imports with robust header mapping and heuristics.
 * - Parses CSV in-browser (supports quoted fields and commas/newlines inside quotes)
 * - Auto-maps a wide range of header variations to canonical fields
 * - Heuristically detects columns if headers are unclear (email/phone/zip/state/address patterns)
 * - Location parsing: Accepts "Location" and combined address strings -> address/city/state/zip
 * - New fields: numberOfEmployees, jobTitle, industries, keywords (with header synonyms)
 * - Lenient validation: only "email" is required; everything else best-effort
 * - Dedupe: skips rows with emails that already exist in DB or duplicate within the same CSV
 * - Creates leads via sheetyApi.createLead
 */

import React, { useMemo, useState } from 'react'
import { Button } from './ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card'
import { X, Upload, Download } from 'lucide-react'
import { useToast } from '../hooks/use-toast'
import * as sheetyApi from '../services/sheetyApi'

interface CsvUploadProps {
  onClose: () => void
  onUploadSuccess: () => void
}

/**
 * Minimal CSV parser that supports quoted fields and commas/newlines inside quotes.
 * Returns a 2D array of strings (rows x cells).
 */
function parseCsv(text: string): string[][] {
  const rows: string[][] = []
  let cur = ''
  let row: string[] = []
  let inQuotes = false

  for (let i = 0; i < text.length; i++) {
    const ch = text[i]
    if (inQuotes) {
      if (ch === '"') {
        if (text[i + 1] === '"') {
          cur += '"'
          i++
        } else {
          inQuotes = false
        }
      } else {
        cur += ch
      }
    } else {
      if (ch === '"') {
        inQuotes = true
      } else if (ch === ',') {
        row.push(cur)
        cur = ''
      } else if (ch === '\n') {
        row.push(cur)
        rows.push(row)
        row = []
        cur = ''
      } else if (ch === '\r') {
        // ignore
      } else {
        cur += ch
      }
    }
  }
  if (cur.length > 0 || row.length > 0) {
    row.push(cur)
    rows.push(row)
  }
  return rows.filter((r) => r.some((v) => (v ?? '').trim().length > 0))
}

/** Canonical keys we target in our data model */
type CanonicalKey =
  | 'name'
  | 'email'
  | 'company'
  | 'address'
  | 'city'
  | 'state'
  | 'zipCode'
  | 'phone'
  | 'notes'
  | 'numberOfEmployees'
  | 'jobTitle'
  | 'industries'
  | 'keywords'

/** Normalize text for header matching */
function norm(s: string): string {
  return (s || '')
    .toLowerCase()
    .replace(/[_\-\/]+/g, ' ')
    .replace(/[^\p{L}\p{N}\s]/gu, ' ')
    .replace(/\s+/g, ' ')
    .trim()
}

/** Simple validators */
function looksLikeEmail(v: string): boolean {
  return /[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}/i.test(v || '')
}
function looksLikePhone(v: string): boolean {
  const digits = (v || '').replace(/\D+/g, '')
  return digits.length >= 7
}
function looksLikeZip(v: string): boolean {
  const trimmed = (v || '').trim()
  return /^\d{5}(-\d{4})?$/.test(trimmed) || /^[A-Z0-9 ]{3,8}$/i.test(trimmed)
}

/** US States */
const US_STATES = new Set([
  'AL','AK','AZ','AR','CA','CO','CT','DE','FL','GA','HI','ID','IL','IN','IA','KS','KY','LA','ME','MD','MA','MI',
  'MN','MS','MO','MT','NE','NV','NH','NJ','NM','NY','NC','ND','OH','OK','OR','PA','RI','SC','SD','TN','TX','UT',
  'VT','VA','WA','WV','WI','WY','DC'
])
const STATE_NAME_TO_CODE: Record<string, string> = {
  alabama: 'AL', alaska: 'AK', arizona: 'AZ', arkansas: 'AR', california: 'CA', colorado: 'CO',
  connecticut: 'CT', delaware: 'DE', florida: 'FL', georgia: 'GA', hawaii: 'HI', idaho: 'ID',
  illinois: 'IL', indiana: 'IN', iowa: 'IA', kansas: 'KS', kentucky: 'KY', louisiana: 'LA',
  maine: 'ME', maryland: 'MD', massachusetts: 'MA', michigan: 'MI', minnesota: 'MN',
  mississippi: 'MS', missouri: 'MO', montana: 'MT', nebraska: 'NE', nevada: 'NV',
  'new hampshire': 'NH', 'new jersey': 'NJ', 'new mexico': 'NM', 'new york': 'NY',
  'north carolina': 'NC', 'north dakota': 'ND', ohio: 'OH', oklahoma: 'OK', oregon: 'OR',
  pennsylvania: 'PA', 'rhode island': 'RI', 'south carolina': 'SC', 'south dakota': 'SD',
  tennessee: 'TN', texas: 'TX', utah: 'UT', vermont: 'VT', virginia: 'VA', washington: 'WA',
  'west virginia': 'WV', wisconsin: 'WI', wyoming: 'WY', 'district of columbia': 'DC'
}
function parseStateToken(v: string): string {
  const s = (v || '').trim()
  if (!s) return ''
  if (s.length === 2 && US_STATES.has(s.toUpperCase())) return s.toUpperCase()
  const key = norm(s)
  if (STATE_NAME_TO_CODE[key]) return STATE_NAME_TO_CODE[key]
  return ''
}

/** Address heuristics */
const STREET_WORDS = /\b(st|street|ave|avenue|rd|road|blvd|boulevard|ln|lane|dr|drive|way|hwy|highway|ct|court|pkwy|parkway|trl|trail|cir|circle)\b/i
function looksLikeAddress(v: string): boolean {
  const hasNum = /\d/.test(v || '')
  return hasNum && STREET_WORDS.test(v || '')
}

/**
 * Parse combined location into address/city/state/zip.
 */
function parseLocation(value: string): { address?: string; city?: string; state?: string; zipCode?: string } {
  const s = (value || '').trim()
  if (!s) return {}

  const zipMatch = s.match(/\b(\d{5}(?:-\d{4})?)\b/)
  const zipCode = zipMatch ? zipMatch[1] : ''

  const parts = s.split(',').map((p) => p.trim()).filter(Boolean)

  // "123 Main St, Dallas, TX 75201"
  if (parts.length >= 3) {
    const first = parts[0]
    const second = parts[1]
    const third = parts.slice(2).join(', ')
    const stateTokenMatch = third.match(/\b([A-Za-z]{2})\b/)
    const stateNameCandidate = third.replace(/\d{5}(-\d{4})?/, '').trim()
    const state =
      parseStateToken(stateTokenMatch?.[1] || '') ||
      (parseStateToken(stateNameCandidate) || '')
    return {
      address: looksLikeAddress(first) ? first : '',
      city: second || '',
      state: state || '',
      zipCode: zipCode || '',
    }
  }

  // "Dallas, TX" or "Dallas, Texas"
  if (parts.length === 2) {
    const city = parts[0]
    const state = parseStateToken(parts[1]) || ''
    return { city, state, zipCode: zipCode || '' }
  }

  // "Houston TX 77001"
  const tokens = s.split(/\s+/)
  if (tokens.length >= 2) {
    const lastToken = tokens[tokens.length - 1]
    const maybeZip = /^\d{5}(-\d{4})?$/.test(lastToken) ? lastToken : ''
    const stateToken = parseStateToken(tokens[tokens.length - (maybeZip ? 2 : 1)])
    if (stateToken) {
      const city = tokens.slice(0, tokens.length - (maybeZip ? 2 : 1)).join(' ')
      return { city, state: stateToken, zipCode: maybeZip || '' }
    }
  }

  if (looksLikeAddress(s)) return { address: s }
  return { city: s }
}

/** Title-case helper */
function toTitleCase(s: string): string {
  return (s || '')
    .toLowerCase()
    .split(/\s+/)
    .filter(Boolean)
    .map((w) => w[0]?.toUpperCase() + w.slice(1))
    .join(' ')
}

/**
 * Match a header cell to a canonical key using rich synonyms.
 */
function matchHeaderCell(header: string): {
  key?:
    | CanonicalKey
    | 'firstName'
    | 'lastName'
    | 'address2'
    | 'location'
} {
  const s = norm(header)
  const tests: Array<{ key: any; re: RegExp }> = [
    // Email
    { key: 'email', re: /^(email|e mail|email address|work email|contact email|mail)$/ },
    // Phone
    { key: 'phone', re: /^(phone|phone number|telephone|tel|mobile|mobile number|cell|cell phone|contact number|contact no|contact #|whatsapp)$/ },
    // Name
    { key: 'name', re: /^(name|full name|fullname|contact|contact name|contact person|lead name|client name|customer name)$/ },
    { key: 'firstName', re: /^(first name|firstname|given name|fname)$/ },
    { key: 'lastName', re: /^(last name|lastname|surname|family name|lname)$/ },
    // Company
    { key: 'company', re: /^(company|company name|organization|organisation|org|org name|business|business name|employer|firm|vendor)$/ },
    // Address lines
    { key: 'address', re: /^(address|street|street address|addr|address 1|address line 1|addr1|line 1|mailing address)$/ },
    { key: 'address2', re: /^(address 2|address line 2|addr2|line 2|suite|unit|apt|apartment)$/ },
    // Location (combined)
    { key: 'location', re: /^(location|site|place|area|city state zip|city state|city zip|city and state)$/ },
    // City/State/Zip
    { key: 'city', re: /^(city|town|locality)$/ },
    { key: 'state', re: /^(state|province|region|state province|state\/province)$/ },
    { key: 'zipCode', re: /^(zip|zip code|zipcode|postal|postal code|post code|pin code|pincode)$/ },
    // Notes
    { key: 'notes', re: /^(notes|note|remarks|comments|comment|memo)$/ },
    // New fields
    { key: 'numberOfEmployees', re: /^(number of employees|employees|employee count|headcount|staff|team size|company size|no\.? of employees)$/ },
    { key: 'jobTitle', re: /^(job title|title|role|position)$/ },
    { key: 'industries', re: /^(industry|industries|sector|vertical)$/ },
    { key: 'keywords', re: /^(keywords|tags|labels|interests)$/ },
  ]

  for (const t of tests) {
    if (t.re.test(s)) return { key: t.key }
  }
  return {}
}

/**
 * Build an index mapping for canonical keys using:
 * 1) Header synonyms
 * 2) Heuristics over sample rows (email/phone/zip/state/address patterns)
 */
function buildHeaderIndex(
  headerRow: string[],
  sampleRows: string[][]
): {
  idx: Partial<Record<CanonicalKey, number>>
  extras: { firstNameIdx?: number; lastNameIdx?: number; address2Idx?: number; locationIdx?: number }
} {
  const idx: Partial<Record<CanonicalKey, number>> = {}
  const used = new Set<number>()
  const extras: { firstNameIdx?: number; lastNameIdx?: number; address2Idx?: number; locationIdx?: number } = {}

  // Pass 1: direct header matching
  headerRow.forEach((cell, i) => {
    const match = matchHeaderCell(cell)
    if (match.key === 'firstName') extras.firstNameIdx = i
    else if (match.key === 'lastName') extras.lastNameIdx = i
    else if (match.key === 'address2') extras.address2Idx = i
    else if (match.key === 'location') extras.locationIdx = i
    else if (match.key) {
      if (idx[match.key] === undefined) {
        idx[match.key] = i
        used.add(i)
      }
    }
  })

  // Heuristic scoring to fill missing keys
  const samples = sampleRows.slice(0, 20)
  const cols = headerRow.length
  const emailScore = Array(cols).fill(0)
  const phoneScore = Array(cols).fill(0)
  const zipScore = Array(cols).fill(0)
  const stateScore = Array(cols).fill(0)
  const addrScore = Array(cols).fill(0)
  const nameScore = Array(cols).fill(0)
  const companyScore = Array(cols).fill(0)
  const cityScore = Array(cols).fill(0)

  for (const r of samples) {
    for (let c = 0; c < cols; c++) {
      const v = r[c] || ''
      if (looksLikeEmail(v)) emailScore[c]++
      if (looksLikePhone(v)) phoneScore[c]++
      if (looksLikeZip(v)) zipScore[c]++
      if (parseStateToken(v)) stateScore[c]++
      if (looksLikeAddress(v)) addrScore[c]++
      if (v && !looksLikeEmail(v) && !/\d/.test(v)) {
        if (/\s/.test(v)) nameScore[c]++
      }
      if (/\b(inc|llc|ltd|corp|co\.|company|logistics|transport|freight|group)\b/i.test(v || '')) {
        companyScore[c]++
      }
      if (v && !looksLikeEmail(v) && !/\d/.test(v) && !/\s.*\s.*\s/.test(v)) {
        cityScore[c]++
      }
    }
  }

  function pickBestByScore(scoreByCol: number[]): number | undefined {
    let bestIdx: number | undefined
    let bestScore = -1
    for (let i = 0; i < scoreByCol.length; i++) {
      if ((used as any).has(i)) continue
      const sc = scoreByCol[i] || 0
      if (sc > bestScore) {
        bestScore = sc
        bestIdx = i
      }
    }
    return bestScore > 0 ? bestIdx : undefined
  }

  const need: CanonicalKey[] = [
    'email',
    'phone',
    'zipCode',
    'state',
    'address',
    'name',
    'company',
    'city',
  ]
  for (const k of need) {
    if (idx[k] !== undefined) continue
    let pick: number | undefined
    if (k === 'email') pick = pickBestByScore(emailScore)
    else if (k === 'phone') pick = pickBestByScore(phoneScore)
    else if (k === 'zipCode') pick = pickBestByScore(zipScore)
    else if (k === 'state') pick = pickBestByScore(stateScore)
    else if (k === 'address') pick = pickBestByScore(addrScore)
    else if (k === 'company') pick = pickBestByScore(companyScore)
    else if (k === 'city') pick = pickBestByScore(cityScore)
    else if (k === 'name') pick = pickBestByScore(nameScore)

    if (pick !== undefined) {
      idx[k] = pick
      used.add(pick)
    }
  }

  return { idx, extras }
}

/** Parse employees from string */
function parseEmployees(v: string): number | undefined {
  const s = (v || '').trim()
  if (!s) return undefined
  const m = s.replace(/[, ]/g, '').match(/\d{1,7}/)
  if (!m) return undefined
  const n = Number(m[0])
  return Number.isFinite(n) ? n : undefined
}

/**
 * Build a row payload using header index + extras with smart fallbacks.
 */
function buildRowPayload(
  row: string[],
  idx: Partial<Record<CanonicalKey, number>>,
  extras: { firstNameIdx?: number; lastNameIdx?: number; address2Idx?: number; locationIdx?: number }
): Record<CanonicalKey, any> {
  const get = (k: CanonicalKey) => {
    const i = idx[k]
    return i !== undefined ? (row[i] || '').trim() : ''
  }

  const first = extras.firstNameIdx !== undefined ? (row[extras.firstNameIdx] || '').trim() : ''
  const last = extras.lastNameIdx !== undefined ? (row[extras.lastNameIdx] || '').trim() : ''
  const addr2 = extras.address2Idx !== undefined ? (row[extras.address2Idx] || '').trim() : ''
  const locationRaw = extras.locationIdx !== undefined ? (row[extras.locationIdx] || '').trim() : ''

  // Compose name
  let name = get('name')
  if (!name) {
    if (first || last) name = toTitleCase(`${first} ${last}`.trim())
  }
  if (!name) {
    const email = get('email')
    const local = email.split('@')[0] || ''
    if (local) name = toTitleCase(local.replace(/[._-]+/g, ' '))
  }

  // Address fields
  let address = get('address')
  let city = get('city')
  let state = get('state')
  let zipCode = get('zipCode')

  // If we have "location", parse it for any missing fields
  if (locationRaw) {
    const parsed = parseLocation(locationRaw)
    address = address || parsed.address || ''
    city = city || parsed.city || ''
    state = state || parsed.state || ''
    zipCode = zipCode || parsed.zipCode || ''
  }

  // If address looks combined, parse too
  if (address && (!city || !state || !zipCode)) {
    const parsed = parseLocation(address)
    city = city || parsed.city || ''
    state = state || parsed.state || ''
    zipCode = zipCode || parsed.zipCode || ''
    address = parsed.address || address
  }

  // Merge address line 2
  if (addr2) {
    address = address ? `${address}, ${addr2}` : addr2
  }
  // Normalize state
  state = parseStateToken(state) || state

  // Extract ZIP if mixed
  if (!zipCode) {
    const zipInCity = city.match(/\b(\d{5}(?:-\d{4})?)\b/)
    if (zipInCity) {
      zipCode = zipInCity[1]
      city = city.replace(zipInCity[0], '').trim().replace(/,\s*$/, '')
    }
    const zipInState = state.match(/\b(\d{5}(?:-\d{4})?)\b/)
    if (zipInState) {
      zipCode = zipInState[1]
      state = state.replace(zipInState[0], '').trim()
    }
  }

  // New fields
  const employeesStr = get('numberOfEmployees')
  const numberOfEmployees = parseEmployees(employeesStr)
  const jobTitle = get('jobTitle')
  const industries = get('industries')
  const keywords = get('keywords')

  return {
    name,
    email: get('email'),
    company: get('company'),
    address,
    city,
    state,
    zipCode,
    phone: get('phone'),
    notes: get('notes'),
    numberOfEmployees: numberOfEmployees ?? undefined,
    jobTitle,
    industries,
    keywords,
  }
}

/** Validate a payload: only email is required */
function validateRequired(payload: Record<CanonicalKey, any>): string[] {
  const missing: string[] = []
  if (!payload.email || String(payload.email).trim() === '') missing.push('email')
  return missing
}

const CsvUpload: React.FC<CsvUploadProps> = ({ onClose, onUploadSuccess }) => {
  const { toast } = useToast()
  const [isDragging, setIsDragging] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [progress, setProgress] = useState({ done: 0, total: 0 })
  const [errors, setErrors] = useState<Array<{ row: number; error: string }>>([])

  const canCreateLead = useMemo(() => typeof (sheetyApi as any).createLead === 'function', [])

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(true)
  }
  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)
  }
  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)
    const files = e.dataTransfer.files
    if (files.length > 0) handleFile(files[0])
  }
  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (files && files.length > 0) handleFile(files[0])
  }

  /**
   * Main CSV processing:
   * - Lenient: only email is required
   * - Smart header mapping including "Location"
   * - Dedupe by email against existing DB + within current file
   */
  async function handleFile(file: File) {
    if (file.type && file.type !== 'text/csv' && !file.name.toLowerCase().endsWith('.csv')) {
      toast({
        title: 'Invalid file type',
        description: 'Please upload a CSV file',
        variant: 'destructive',
      })
      return
    }
    if (!canCreateLead) {
      toast({
        title: 'Upload not configured',
        description: 'Backend createLead() is not available. Please configure services/sheetyApi.ts.',
        variant: 'destructive',
      })
      return
    }

    setIsLoading(true)
    setErrors([])
    setProgress({ done: 0, total: 0 })

    try {
      // Fetch existing leads to prevent duplicates
      let existingEmails = new Set<string>()
      try {
        const existing = await (sheetyApi as any).getLeads()
        existingEmails = new Set(
          (existing || []).map((l: any) => (String(l.email || '').trim().toLowerCase()))
        )
      } catch {
        // If we can't fetch, we still proceed (best-effort), but duplicates within file are prevented
      }

      const text = await file.text()
      const grid = parseCsv(text)
      if (grid.length < 2) throw new Error('CSV has no data rows')

      const headerRow = grid[0]
      const dataRows = grid.slice(1)

      const { idx, extras } = buildHeaderIndex(headerRow, dataRows)
      const total = dataRows.length
      setProgress({ done: 0, total })

      let created = 0
      const rowErrors: Array<{ row: number; error: string }> = []
      const seenEmails = new Set<string>()

      for (let i = 0; i < dataRows.length; i++) {
        const r = dataRows[i]
        const payload = buildRowPayload(r, idx, extras)

        const missingRow = validateRequired(payload)
        if (missingRow.length) {
          rowErrors.push({ row: i + 2, error: `Missing: ${missingRow.join(', ')}` })
          setProgress((p) => ({ ...p, done: p.done + 1 }))
          continue
        }

        const emailKey = String(payload.email).trim().toLowerCase()
        if (!emailKey) {
          rowErrors.push({ row: i + 2, error: 'Invalid email' })
          setProgress((p) => ({ ...p, done: p.done + 1 }))
          continue
        }

        // Duplicate prevention (DB + file)
        if (existingEmails.has(emailKey) || seenEmails.has(emailKey)) {
          rowErrors.push({ row: i + 2, error: 'Duplicate email, skipped' })
          setProgress((p) => ({ ...p, done: p.done + 1 }))
          continue
        }

        try {
          await (sheetyApi as any).createLead({
            name: payload.name || '',
            email: payload.email,
            phone: payload.phone || '',
            address: payload.address || '',
            company: payload.company || '',
            status: 'New',
            city: payload.city || '',
            state: payload.state || '',
            zipCode: payload.zipCode || '',
            notes: payload.notes || '',
            numberOfEmployees: payload.numberOfEmployees,
            jobTitle: payload.jobTitle || '',
            industries: payload.industries || '',
            keywords: payload.keywords || '',
          })
          created++
          seenEmails.add(emailKey)
        } catch (err: any) {
          const msg = err?.message || String(err) || 'Failed to create lead'
          rowErrors.push({ row: i + 2, error: msg })
        } finally {
          setProgress((p) => ({ ...p, done: p.done + 1 }))
          await new Promise((res) => setTimeout(res, 0))
        }
      }

      setErrors(rowErrors)

      if (created > 0) {
        toast({ title: 'CSV imported', description: `${created} lead(s) created` })
        onUploadSuccess()
      }
      if (rowErrors.length) {
        toast({
          title: 'Some rows were skipped',
          description: `${rowErrors.length} row(s) had issues (missing email or duplicates)`,
          variant: 'destructive',
        })
      }
      if (created > 0 && rowErrors.length === 0) onClose()
    } catch (error: any) {
      toast({
        title: 'Upload failed',
        description: error?.message || 'Failed to process CSV file',
        variant: 'destructive',
      })
    } finally {
      setIsLoading(false)
    }
  }

  const downloadTemplate = () => {
    const csvContent =
      'name,email,company,location,phone,job title,number of employees,industries,keywords,notes\n' +
      'John Smith,john@example.com,ABC Logistics,"123 Main St, Dallas, TX 75201",(555) 123-4567,Logistics Manager,200,Transportation; Logistics,"FTL; LTL; Dry Van",Interested in freight services'
    const blob = new Blob([csvContent], { type: 'text/csv' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = 'leads_template_extended.csv'
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-2xl bg-white/95 backdrop-blur-sm border-white/20 dark:bg-white/10 dark:border-white/10">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Upload CSV File</CardTitle>
              <CardDescription>Import leads from a CSV file (smart mapping, duplicates prevented)</CardDescription>
            </div>
            <Button variant="ghost" size="icon" onClick={onClose} className="bg-transparent hover:bg-gray-100 dark:hover:bg-white/10" aria-label="Close">
              <X className="h-4 w-4" />
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            {/* Download Template */}
            <div className="text-center">
              <Button
                variant="outline"
                onClick={downloadTemplate}
                className="bg-transparent border-[#1a1a38]/20 text-[#1a1a38] hover:bg-[#1a1a38]/10 dark:text-white dark:border-white/15 dark:hover:bg-white/10"
              >
                <Download className="h-4 w-4 mr-2" />
                Download CSV Template
              </Button>
              <p className="text-sm text-gray-600 dark:text-gray-300 mt-2">
                Accepts varied headers like "Location", "Postal Code", "Mobile", "Headcount", "Role", "Industry", "Tags".
              </p>
            </div>

            {/* Upload Area */}
            <div
              className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
                isDragging ? 'border-[#1a1a38] bg-[#1a1a38]/5' : 'border-gray-300 hover:border-[#1a1a38]'
              }`}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
            >
              <Upload className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-lg font-medium text-gray-900 dark:text-white mb-2">Drop your CSV file here</p>
              <p className="text-sm text-gray-600 dark:text-gray-300 mb-4">or click to browse files</p>
              <input type="file" accept=".csv,text/csv" onChange={handleFileInput} className="hidden" id="csv-upload" />
              <Button asChild className="bg-[#1a1a38] hover:bg-[#1a1a38]/90 text-white" disabled={isLoading}>
                <label htmlFor="csv-upload">{isLoading ? 'Uploading...' : 'Browse Files'}</label>
              </Button>

              {/* Progress */}
              {isLoading && (
                <div className="mt-4 text-sm text-gray-700 dark:text-gray-300">
                  {progress.total > 0 ? `Importing ${progress.done}/${progress.total}…` : 'Parsing CSV…'}
                </div>
              )}
            </div>

            {/* Tips */}
            <div className="bg-blue-50 dark:bg-white/10 rounded-lg p-4">
              <h4 className="font-medium text-blue-900 dark:text-white mb-2">CSV Tips:</h4>
              <ul className="text-sm text-blue-800 dark:text-gray-300 space-y-1">
                <li>• Only "email" is required. We derive name from email if missing.</li>
                <li>• Use "Location" or combined strings (e.g., "Dallas, TX 75201"); we auto-parse city/state/zip.</li>
                <li>• New fields supported: Number of Employees, Job Title, Industries, Keywords.</li>
                <li>• Duplicate emails are skipped automatically (existing DB + within file).</li>
              </ul>
            </div>

            {/* Error list */}
            {errors.length > 0 && (
              <div className="rounded-lg p-4 bg-red-50 dark:bg-white/10 border border-red-200 dark:border-white/15">
                <div className="font-medium text-red-700 dark:text-red-300 mb-2">
                  {errors.length} row(s) skipped (missing email, duplicates, or save errors)
                </div>
                <ul className="text-sm text-red-700 dark:text-red-300 max-h-40 overflow-auto space-y-1">
                  {errors.slice(0, 80).map((e, idx) => (
                    <li key={idx}>
                      Row {e.row}: {e.error}
                    </li>
                  ))}
                  {errors.length > 80 && <li>…and more</li>}
                </ul>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export default CsvUpload
