/**
 * Main layout component with header and navigation
 * - Provides a scoped CSS helper for improving readability on light theme
 *   inside grey/muted surfaces via the `.light-readable` wrapper.
 * - Also applies global dark-theme form control readability fixes to ensure
 *   inputs, selects, and textareas are legible on dark surfaces (e.g., Mailbox compose).
 */

import React from 'react'
import { useAuth } from '../contexts/AuthContext'
import { useTheme } from '../contexts/ThemeContext'
import Header from './Header'
import Navigation from './Navigation'

/**
 * LayoutProps: wraps the app with header/nav and theming
 */
interface LayoutProps {
  children: React.ReactNode
}

/**
 * Layout
 * - Sets page background/text based on theme
 * - Injects small global styles:
 *   1) Light-only `.light-readable` wrapper to keep text dark on grey surfaces.
 *   2) Dark-only form control overrides to ensure inputs and textareas have
 *      a darker background and readable text/placeholder (applies across app).
 */
const Layout: React.FC<LayoutProps> = ({ children }) => {
  const { isAuthenticated } = useAuth()
  const { isDark } = useTheme()

  return (
    <div
      className={`min-h-screen transition-colors duration-300 ${
        isDark ? 'bg-[#1a1a38] text-white' : 'bg-white text-[#1a1a38]'
      }`}
    >
      {/* Scoped readability overrides */}
      <style>
        {`
          /* ------------------------------
           * Light theme readability helper
           * ------------------------------ */
          /* Only apply when NOT in dark mode */
          :root:not(.dark) .light-readable {
            color: #1a1a38;
          }

          /* Typical text-bearing elements become readable on grey boxes */
          :root:not(.dark) .light-readable :is(p, span, li, div, label, dt, dd, th, td, h1, h2, h3, h4, h5, h6) {
            color: #1a1a38;
          }

          /* Inputs / selects / textareas readable text + placeholders */
          :root:not(.dark) .light-readable input,
          :root:not(.dark) .light-readable select,
          :root:not(.dark) .light-readable textarea {
            color: #1a1a38;
          }
          :root:not(.dark) .light-readable input::placeholder,
          :root:not(.dark) .light-readable textarea::placeholder {
            color: #475569; /* slate-600 for subtle placeholder contrast */
            opacity: 1;    /* ensure visibility across browsers */
          }

          /* Keep subtle borders darker in light theme for visibility */
          :root:not(.dark) .light-readable :is(input, select, textarea, .border, .card, .popover, .dropdown) {
            border-color: rgba(30, 41, 59, 0.2); /* slate-800 at 20% */
          }

          /* Do NOT force dark text inside button contents in light theme.
             Ensure inner spans and icons follow the button's own color. */
          :root:not(.dark) .light-readable button :is(span, svg) {
            color: inherit !important;
          }

          /* ----------------------------------------
           * Dark theme global form readability fix
           * ----------------------------------------
           * Ensures inputs, selects, and textareas are legible on dark surfaces
           * (e.g., Mailbox compose panel). We use !important to reliably
           * override component-level bg-transparent or other classes.
           */
          :root.dark :is(input, select, textarea) {
            background-color: rgba(255, 255, 255, 0.06) !important; /* subtle dark surface */
            color: #ffffff !important; /* readable text */
            border-color: rgba(255, 255, 255, 0.18) !important; /* visible border */
          }

          :root.dark :is(input, select, textarea)::placeholder {
            color: rgba(255, 255, 255, 0.65) !important; /* readable placeholder */
            opacity: 1;
          }

          /* Optional: slightly stronger borders on cards/popovers in dark */
          :root.dark :is(.card, .popover, .dropdown) {
            border-color: rgba(255, 255, 255, 0.12);
          }
        `}
      </style>

      <Header />
      <div className="container mx-auto px-4 py-6">
        {isAuthenticated && <Navigation />}
        <main className={isAuthenticated ? 'mt-6' : ''}>{children}</main>
      </div>
    </div>
  )
}

export default Layout
