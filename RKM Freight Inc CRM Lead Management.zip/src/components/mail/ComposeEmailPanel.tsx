/**
 * ComposeEmailPanel: Rich compose panel with recipients picker, templates, and attachments.
 * - Now includes a RichTextEditor for Bold/Italic, color, and text size controls.
 * - Uses sendEmail (Apps Script fallback) or Gmail API send (OAuth) depending on settings.
 * - Provides Save to Drafts via mailStore, system notification, and success sound.
 */

import React, { useEffect, useMemo, useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../components/ui/card'
import { Input } from '../../components/ui/input'
import { Button } from '../../components/ui/button'
import { Label } from '../../components/ui/label'
import { Paperclip, Save, Send, Users, X, ChevronDown, ChevronRight, Sparkles } from 'lucide-react'
import { useToast } from '../../hooks/use-toast'
import EmailTemplates from '../EmailTemplates'
import RecipientSelector from '../RecipientSelector'
import { Lead } from '../../services/sheetyApi'
import { EmailAttachment, sendEmail } from '../../services/emailService'
import { sendViaGmail } from '../../services/gmailApi'
import { useUserSettings } from '../../contexts/UserSettingsContext'
import { addSent, saveDraft, MailItem } from '../../services/mailStore'
import { useAuth } from '../../contexts/AuthContext'
import RichTextEditor from '../editor/RichTextEditor'

/** File item kept in local state with base64 payload */
interface FileItem {
  /** The selected File object */
  file: File
  /** Base64 data string (no data: prefix) */
  base64: string
}

interface ComposeEmailPanelProps {
  /** Whether the panel is shown */
  open: boolean
  /** Close handler (parent controls visibility) */
  onClose: () => void
  /** Leads list used by RecipientSelector */
  leads: Lead[]
  /** Optional draft to load for editing */
  draft?: Partial<MailItem>
  /** Callback after a successful send (parent can refresh list) */
  onSent?: () => void
  /** Callback after a draft save (parent can refresh list) */
  onDraftSaved?: () => void
}

/** Very light email validator */
const isEmail = (s: string) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s)

/**
 * Parse comma/space/semi-colon separated emails into a unique, normalized list.
 */
function parseEmails(input: string): string[] {
  const parts = input.split(/[,;\s]+/g).map((x) => x.trim()).filter(Boolean)
  const uniq = Array.from(new Set(parts.map((e) => e.toLowerCase())))
  return uniq.filter(isEmail)
}

/**
 * playSuccessSound: Non-blocking, tiny "ping" using Web Audio API (no external files).
 */
function playSuccessSound() {
  try {
    const ctx = new (window.AudioContext || (window as any).webkitAudioContext)()
    const osc = ctx.createOscillator()
    const gain = ctx.createGain()
    osc.type = 'triangle'
    osc.frequency.value = 880 // A5
    gain.gain.value = 0.001 // start silent
    osc.connect(gain).connect(ctx.destination)
    const now = ctx.currentTime
    // Envelope: quick ramp up, quick decay
    gain.gain.exponentialRampToValueAtTime(0.03, now + 0.01)
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.2)
    osc.start(now)
    osc.stop(now + 0.25)
  } catch {
    // ignore if not supported
  }
}

/**
 * showSystemNotification: Uses the Notification API for an OS-level toast.
 */
async function showSystemNotification(title: string, body: string) {
  try {
    if (!('Notification' in window)) return
    if (Notification.permission === 'default') {
      await Notification.requestPermission()
    }
    if (Notification.permission === 'granted') {
      new Notification(title, { body })
    }
  } catch {
    // ignore
  }
}

/**
 * ComposeEmailPanel component
 */
const ComposeEmailPanel: React.FC<ComposeEmailPanelProps> = ({
  open,
  onClose,
  leads,
  draft,
  onSent,
  onDraftSaved,
}) => {
  const { user } = useAuth()
  const { settings } = useUserSettings()
  const { toast } = useToast()
  const [to, setTo] = useState('')
  const [subject, setSubject] = useState('')
  const [body, setBody] = useState('<p>Hello,</p><p></p><p>Best regards,</p>')
  const [files, setFiles] = useState<FileItem[]>([])
  const [sending, setSending] = useState(false)
  const [showRecipientSelector, setShowRecipientSelector] = useState(false)
  const [showTemplates, setShowTemplates] = useState(false)

  const recipients = useMemo(() => parseEmails(to), [to])

  useEffect(() => {
    if (draft && open) {
      setTo((draft.to || []).join(', '))
      setSubject(draft.subject || '')
      setBody(draft.bodyHtml || '')
      // Attachments in drafts are metadata-only; skip loading actual files
      setFiles([])
    }
  }, [draft, open])

  if (!open) return null

  /** Convert a File to base64 (no data: prefix) */
  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader()
      reader.onload = () => {
        const result = String(reader.result || '')
        const idx = result.indexOf('base64,')
        resolve(idx >= 0 ? result.slice(idx + 7) : result)
      }
      reader.onerror = () => reject(reader.error)
      reader.readAsDataURL(file)
    })
  }

  /** Handle file input change => push to state with base64 */
  const onFilesSelected = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const selected = e.target.files
    if (!selected || selected.length === 0) return
    const newItems: FileItem[] = []
    for (const file of Array.from(selected)) {
      const base64 = await fileToBase64(file)
      newItems.push({ file, base64 })
    }
    setFiles((prev) => [...prev, ...newItems])
    e.target.value = ''
  }

  /** Remove file from list */
  const removeFile = (idx: number) => {
    setFiles((prev) => prev.filter((_, i) => i !== idx))
  }

  /** Apply email template (subject + HTML body) */
  const handleUseTemplate = (tplSubject: string, tplBody: string) => {
    setSubject(tplSubject)
    setBody(tplBody)
    toast({ title: 'Template applied', description: tplSubject || 'Subject updated' })
  }

  /** Merge selected recipients from selector modal */
  const handleApplyRecipients = (emails: string[]) => {
    const combined = Array.from(new Set([...recipients, ...emails.map((e) => e.toLowerCase())]))
    setTo(combined.join(', '))
    setShowRecipientSelector(false)
    toast({ title: 'Recipients added', description: `${emails.length} selected` })
  }

  /** Save to drafts in local store */
  const handleSaveDraft = () => {
    const draftItem = saveDraft({
      from: user?.email || 'me@rkmfreight.com',
      to: recipients,
      subject,
      bodyHtml: body,
      attachments: files.map((f) => ({ name: f.file.name, type: f.file.type, size: f.file.size })),
    })
    toast({ title: 'Draft saved', description: draftItem.subject || '(No subject)' })
    onDraftSaved?.()
    onClose()
  }

  /**
   * Send email with strict provider rules:
   * - If settings.useGmailApiSend is true, require Gmail OAuth client and do NOT fallback to Apps Script.
   * - If Gmail API is off, use Apps Script only if an Apps Script URL is configured; otherwise show a clear error.
   */
  const handleSend = async () => {
    if (recipients.length === 0) {
      toast({
        title: 'Recipient required',
        description: 'Please enter at least one recipient email',
        variant: 'destructive',
      })
      return
    }
    setSending(true)
    try {
      const attachments: EmailAttachment[] = files.map((f) => ({
        fileName: f.file.name,
        mimeType: f.file.type || 'application/octet-stream',
        content: f.base64,
      }))

      if (settings.useGmailApiSend) {
        // Gmail-only path (no fallback)
        if (!settings.gmailClientId?.trim()) {
          toast({
            title: 'Gmail not configured',
            description:
              'Provide a Gmail OAuth Client ID and connect Gmail in Email Settings to send via Gmail API.',
            variant: 'destructive',
          })
          return
        }

        await sendViaGmail({
          clientId: settings.gmailClientId,
          to: recipients.join(','),
          subject,
          html: body,
          attachments,
          from: user?.email,
        })

        // Store to Sent locally for UX
        addSent({
          from: user?.email || 'me@rkmfreight.com',
          to: recipients,
          subject,
          bodyHtml: body,
          attachments: files.map((f) => ({ name: f.file.name, type: f.file.type, size: f.file.size })),
        })

        toast({ title: 'Email sent via Gmail', description: `Sent to ${recipients.length} recipient(s)` })
        playSuccessSound()
        showSystemNotification('Email sent', `Sent to ${recipients.length} recipient(s)`)
      } else {
        // Apps Script path only if configured
        if (!settings.appsScriptUrl?.trim()) {
          toast({
            title: 'No sending service configured',
            description: 'Enable Gmail API send or set an Apps Script URL in Email Settings.',
            variant: 'destructive',
          })
          return
        }

        const res = await sendEmail(
          {
            to: recipients.join(','),
            subject,
            body,
            attachments,
          },
          { appsScriptUrlOverride: settings.appsScriptUrl }
        )

        // Always store to Sent for UX (mock or real)
        addSent({
          from: user?.email || 'me@rkmfreight.com',
          to: recipients,
          subject,
          bodyHtml: body,
          attachments: files.map((f) => ({ name: f.file.name, type: f.file.type, size: f.file.size })),
        })

        if (res.success) {
          toast({ title: 'Email sent', description: res.message || 'Your email has been sent.' })
          playSuccessSound()
          showSystemNotification('Email sent', `Sent to ${recipients.length} recipient(s)`)
        } else {
          toast({ title: 'Send failed', description: res.error || 'Unknown error', variant: 'destructive' })
        }
      }

      onSent?.()
      onClose()
    } catch (err: any) {
      console.error('Send error', err)
      toast({ title: 'Error', description: String(err?.message || err), variant: 'destructive' })
    } finally {
      setSending(false)
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/50" onClick={onClose} />
      <Card className="relative w-full max-w-4xl bg-white/95 dark:bg-white/5 text-black dark:text-white backdrop-blur-sm border-white/20 dark:border-white/10">
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>New Message</CardTitle>
            <CardDescription>Write your email, add recipients and attachments</CardDescription>
          </div>
          <Button variant="ghost" size="icon" className="bg-transparent" onClick={onClose} aria-label="Close">
            <X className="h-4 w-4" />
          </Button>
        </CardHeader>

        <CardContent className="space-y-4">
          {/* Recipients row */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="md:col-span-2 space-y-2">
              <Label htmlFor="to">To</Label>
              <Input
                id="to"
                placeholder="Type email(s) separated by commas or use Choose recipients"
                value={to}
                onChange={(e) => setTo(e.target.value)}
              />
              <p className="text-xs text-gray-500">{recipients.length} recipient(s)</p>
            </div>
            <div className="md:flex md:items-end">
              <Button
                type="button"
                onClick={() => setShowRecipientSelector(true)}
                className="w-full md:w-auto bg-[#1a1a38] hover:bg-[#1a1a38]/90 text-white"
                disabled={!leads || leads.length === 0}
              >
                <Users className="h-4 w-4 mr-2" />
                Choose recipients
              </Button>
            </div>
          </div>

          {/* Subject */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label htmlFor="subject">Subject</Label>
              <Button
                type="button"
                variant="outline"
                className="bg-transparent border-[#1a1a38]/20 text-[#1a1a38] hover:bg-[#1a1a38]/10 h-8 px-2 dark:border-white/20 dark:text-white dark:hover:bg-white/10"
                onClick={() => setShowTemplates((s) => !s)}
                aria-expanded={showTemplates}
              >
                {showTemplates ? <ChevronDown className="h-4 w-4 mr-1" /> : <ChevronRight className="h-4 w-4 mr-1" />}
                Templates
              </Button>
            </div>
            <Input id="subject" placeholder="Subject" value={subject} onChange={(e) => setSubject(e.target.value)} />
          </div>

          {/* Body: RichTextEditor with formatting controls */}
          <div className="space-y-2">
            <Label htmlFor="body">Message</Label>
            <RichTextEditor
              value={body}
              onChange={setBody}
              placeholder="Write your message. Use the toolbar to apply Bold, Italic, colors, and sizes."
              className="w-full"
            />
            <p className="text-xs text-gray-500">
              Tip: You can paste HTML or rich text. The email service sends HTML content.
            </p>
          </div>

          {/* Attachments */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Label>Attachments</Label>
              <div className="text-xs text-gray-500 flex items-center">
                <Sparkles className="h-3 w-3 mr-1 text-[#f47b20]" />
                Optional
              </div>
            </div>
            <div className="flex items-center gap-3">
              <input type="file" multiple onChange={onFilesSelected} className="hidden" id="attach-input" />
              <Button asChild className="bg-[#1a1a38] hover:bg-[#1a1a38]/90 text-white">
                <label htmlFor="attach-input" className="flex items-center cursor-pointer">
                  <Paperclip className="h-4 w-4 mr-2" />
                  Add files
                </label>
              </Button>
              {files.length > 0 && (
                <span className="text-sm text-gray-600 dark:text-gray-300">
                  {files.length} file(s) attached
                </span>
              )}
            </div>

            {files.length > 0 && (
              <div className="border rounded-md divide-y bg-white/70 dark:bg-white/10 dark:border-white/10">
                {files.map((f, idx) => (
                  <div key={idx} className="flex items-center justify-between p-2">
                    <div className="text-sm">
                      <div className="font-medium text-[#1a1a38] dark:text-white">{f.file.name}</div>
                      <div className="text-xs text-gray-500">
                        {(f.file.size / 1024).toFixed(1)} KB • {f.file.type || 'file'}
                      </div>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      className="bg-transparent border-red-200 text-red-600 hover:bg-red-50 dark:border-red-300/30 dark:text-red-300 dark:hover:bg-white/10"
                      onClick={() => removeFile(idx)}
                    >
                      Remove
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Templates (inline, collapsible) */}
          {showTemplates && (
            <div>
              <EmailTemplates onSelect={handleUseTemplate} />
            </div>
          )}

          {/* Actions */}
          <div className="flex items-center justify-end gap-2">
            <Button
              variant="outline"
              onClick={handleSaveDraft}
              className="bg-transparent text-[#1a1a38] border-[#1a1a38]/20 hover:bg-[#1a1a38]/10 dark:text-white dark:border-white/20 dark:hover:bg-white/10"
            >
              <Save className="h-4 w-4 mr-2" />
              Save draft
            </Button>
            <Button onClick={handleSend} disabled={sending} className="bg-[#f47b20] hover:bg-[#f47b20]/90 text-white">
              <Send className="h-4 w-4 mr-2" />
              {sending ? 'Sending...' : 'Send Email'}
            </Button>
          </div>
        </CardContent>
      </Card>

      {showRecipientSelector && (
        <RecipientSelector
          leads={leads}
          initialSelected={recipients}
          onApply={handleApplyRecipients}
          onClose={() => setShowRecipientSelector(false)}
        />
      )}
    </div>
  )
}

export default ComposeEmailPanel
