/**
 * MailList: Searchable list of messages with selection and actions.
 * - Draggable rows: supports HTML5 drag-and-drop to move messages to folders (handled in MailSidebar).
 * - Keeps API compatible with existing usage in Inbox.
 */

import React, { useMemo } from 'react'
import { Input } from '../ui/input'
import { Button } from '../ui/button'
import { Trash2, CheckCircle2, Circle } from 'lucide-react'
import type { MailItem } from '../../services/mailStore'

/** Props for MailList */
interface MailListProps {
  /** Items to show */
  items: MailItem[]
  /** Search query string */
  query: string
  /** Update query */
  onQueryChange: (s: string) => void
  /** Currently selected id */
  selectedId: string | null
  /** Select an item */
  onSelect: (id: string) => void
  /** Toggle read state */
  onToggleRead: (id: string, read: boolean) => void
  /** Move to trash */
  onTrash: (id: string) => void
}

/** Strip HTML tags to make a plain snippet */
function stripHtml(html: string): string {
  try {
    const txt = html.replace(/<style[\s\S]*?<\/style>/gi, '').replace(/<script[\s\S]*?<\/script>/gi, '')
    return txt.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim()
  } catch {
    return html
  }
}

/** Format time compactly */
function formatTime(ts: number): string {
  try {
    return new Date(ts).toLocaleString(undefined, {
      month: 'short',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
    })
  } catch {
    return ''
  }
}

/**
 * MailList component
 * - Renders a search input and a virtualized-like simple list (sufficient for moderate sizes).
 * - Each row is draggable with payload { id } in dataTransfer for folder drop targets.
 */
const MailList: React.FC<MailListProps> = ({
  items,
  query,
  onQueryChange,
  selectedId,
  onSelect,
  onToggleRead,
  onTrash,
}) => {
  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase()
    if (!q) return items
    return items.filter((m) => {
      const body = stripHtml(m.bodyHtml || '')
      return (
        (m.subject || '').toLowerCase().includes(q) ||
        (m.from || '').toLowerCase().includes(q) ||
        body.toLowerCase().includes(q)
      )
    })
  }, [items, query])

  return (
    <div className="h-full flex flex-col">
      {/* Search */}
      <div className="mb-3">
        <Input
          value={query}
          onChange={(e) => onQueryChange(e.target.value)}
          placeholder="Search subject, sender, or content"
          aria-label="Search messages"
        />
      </div>

      {/* List */}
      <div className="overflow-auto rounded-md border border-white/30 dark:border-white/10 bg-white/70 dark:bg-white/5">
        {filtered.length === 0 ? (
          <div className="p-6 text-sm text-gray-600 dark:text-gray-300">No messages</div>
        ) : (
          <ul role="list" className="divide-y divide-white/40 dark:divide-white/10">
            {filtered.map((m) => {
              const isSelected = m.id === selectedId
              const snippet = stripHtml(m.bodyHtml || '').slice(0, 140)
              return (
                <li
                  key={m.id}
                  role="button"
                  tabIndex={0}
                  onClick={() => onSelect(m.id)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' || e.key === ' ') onSelect(m.id)
                  }}
                  className={[
                    'group px-3 py-2 cursor-pointer flex items-start gap-3',
                    isSelected
                      ? 'bg-white/90 dark:bg-white/10 ring-1 ring-[#f47b20]'
                      : 'hover:bg-white/70 dark:hover:bg-white/10',
                  ].join(' ')}
                  draggable
                  onDragStart={(e) => {
                    e.dataTransfer.setData('application/x-mail-id', m.id)
                    e.dataTransfer.setData('text/plain', m.id)
                    e.dataTransfer.effectAllowed = 'move'
                  }}
                >
                  {/* Read state dot */}
                  <div className="pt-1">
                    {m.read ? (
                      <CheckCircle2 className="h-3.5 w-3.5 text-gray-400" aria-label="Read" />
                    ) : (
                      <Circle className="h-3.5 w-3.5 text-[#1a1a38]" aria-label="Unread" />
                    )}
                  </div>

                  {/* Main content */}
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between gap-3">
                      <div className="truncate font-medium text-[#1a1a38] dark:text-white">
                        {m.subject || '(No subject)'}
                      </div>
                      <div className="shrink-0 text-xs text-gray-500">{formatTime(m.date)}</div>
                    </div>
                    <div className="text-xs text-gray-700 dark:text-gray-300 truncate">
                      {m.from} • {snippet}
                    </div>
                    {m.attachments?.length ? (
                      <div className="mt-1 text-[10px] text-gray-500">{m.attachments.length} attachment(s)</div>
                    ) : null}
                  </div>

                  {/* Row actions */}
                  <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition">
                    <Button
                      variant="outline"
                      size="sm"
                      className="h-7 bg-transparent text-xs"
                      onClick={(e) => {
                        e.stopPropagation()
                        onToggleRead(m.id, !m.read)
                      }}
                      title={m.read ? 'Mark as unread' : 'Mark as read'}
                    >
                      {m.read ? 'Unread' : 'Read'}
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="h-7 bg-transparent text-red-600 border-red-200 dark:border-red-300/30 dark:text-red-300"
                      onClick={(e) => {
                        e.stopPropagation()
                        onTrash(m.id)
                      }}
                      title="Move to Trash"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </li>
              )
            })}
          </ul>
        )}
      </div>
    </div>
  )
}

export default MailList
