/**
 * MailSidebar: System folders, custom folders, Compose, and quick actions.
 * - Shows counts for system folders (provided via props) and custom folders (computed here).
 * - Create Folder: modal for name + color.
 * - Sync Rules: open dialog to set mark-as-read and target folder for Gmail sync.
 */

import React, { useMemo, useState } from 'react'
import { Button } from '../ui/button'
import { Input } from '../ui/input'
import { Label } from '../ui/label'
import { Plus, FolderPlus, Settings, Inbox as InboxIcon, Send, FileText, Trash2, Circle } from 'lucide-react'
import { list, listFolders, createFolder, UserFolder } from '../../services/mailStore'
import type { MailFolder } from '../../services/mailStore'
import SyncRulesDialog from '../settings/SyncRulesDialog'

/** Props for MailSidebar */
interface MailSidebarProps {
  /** Active folder key */
  active: MailFolder
  /** System counts object: { inbox, sent, drafts, trash } */
  counts: { inbox: number; sent: number; drafts: number; trash: number }
  /** Change selected folder */
  onSelect: (f: MailFolder) => void
  /** Open compose panel */
  onCompose: () => void
  /** Called when a message is dropped on a folder row */
  onDropMessage: (target: MailFolder, id: string) => void
}

/** Small colored dot */
function ColorDot({ color }: { color: string }) {
  return <span className="inline-block h-3 w-3 rounded-full border" style={{ backgroundColor: color, borderColor: '#00000022' }} />
}

/** Create Folder modal */
function CreateFolderModal({ open, onClose, onCreated }: { open: boolean; onClose: () => void; onCreated: (f: UserFolder) => void }) {
  const [name, setName] = useState('')
  const [color, setColor] = useState('#1a1a38')

  const swatches = ['#1a1a38', '#f47b20', '#2563eb', '#16a34a', '#ef4444', '#7c3aed', '#374151']

  if (!open) return null
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/50" onClick={onClose} />
      <div className="relative w-full max-w-md rounded-md border bg-white/95 dark:bg-white/5 text-black dark:text-white p-4">
        <div className="mb-3 font-semibold text-lg">Create Folder</div>
        <div className="space-y-3">
          <div className="space-y-1.5">
            <Label htmlFor="cf-name">Name</Label>
            <Input id="cf-name" value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g., Replies, Clients, Finance" />
          </div>
          <div className="space-y-2">
            <Label htmlFor="cf-color">Color</Label>
            <div className="flex items-center gap-2">
              <input id="cf-color" type="color" value={color} onChange={(e) => setColor(e.target.value)} className="h-9 w-12 p-0 border rounded cursor-pointer bg-transparent" />
              <div className="flex items-center gap-1">
                {swatches.map((c) => (
                  <button
                    key={c}
                    type="button"
                    onClick={() => setColor(c)}
                    className="h-6 w-6 rounded border"
                    style={{ backgroundColor: c, borderColor: '#00000022' }}
                    aria-label={`Choose ${c}`}
                    title={c}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>

        <div className="mt-4 flex items-center justify-end gap-2">
          <Button variant="outline" className="bg-transparent" onClick={onClose}>Cancel</Button>
          <Button
            className="bg-[#f47b20] hover:bg-[#f47b20]/90 text-white"
            onClick={() => {
              const f = createFolder(name.trim(), color)
              onCreated(f)
              onClose()
            }}
          >
            <FolderPlus className="h-4 w-4 mr-2" />
            Create
          </Button>
        </div>
      </div>
    </div>
  )
}

/**
 * MailSidebar component
 */
const MailSidebar: React.FC<MailSidebarProps> = ({ active, counts, onSelect, onCompose, onDropMessage }) => {
  const [showCreate, setShowCreate] = useState(false)
  const [showSyncRules, setShowSyncRules] = useState(false)

  const folders = useMemo(() => listFolders(), [])
  const customCounts = useMemo(() => {
    const map: Record<string, number> = {}
    for (const f of folders) {
      map[f.id] = list(`custom:${f.id}`).length
    }
    return map
  }, [folders])

  const isActive = (f: MailFolder) => f === active

  const [dropTarget, setDropTarget] = useState<MailFolder | null>(null)

  const makeDroppable = (target: MailFolder) => ({
    onDragOver: (e: React.DragEvent) => {
      e.preventDefault()
      e.dataTransfer.dropEffect = 'move'
      setDropTarget(target)
    },
    onDragLeave: () => setDropTarget((cur) => (cur === target ? null : cur)),
    onDrop: (e: React.DragEvent) => {
      e.preventDefault()
      const id = e.dataTransfer.getData('application/x-mail-id') || e.dataTransfer.getData('text/plain')
      setDropTarget(null)
      if (id) onDropMessage(target, id)
    },
  })

  return (
    <div className="space-y-3">
      <Button className="w-full bg-[#f47b20] hover:bg-[#f47b20]/90 text-white" onClick={onCompose}>
        <Plus className="h-4 w-4 mr-2" />
        Compose
      </Button>

      {/* System folders */}
      <div className="space-y-1">
        <div
          role="button"
          tabIndex={0}
          onClick={() => onSelect('inbox')}
          onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') onSelect('inbox') }}
          className={[
            'flex items-center justify-between rounded-md px-2 py-2 cursor-pointer transition',
            isActive('inbox') ? 'bg-white/80 dark:bg-white/10 ring-1 ring-[#f47b20]' : 'hover:bg-white/60 dark:hover:bg-white/5',
            dropTarget === 'inbox' ? 'ring-2 ring-[#f47b20] bg-white/80 dark:bg-white/10' : ''
          ].join(' ')}
          {...makeDroppable('inbox')}
        >
          <div className="flex items-center gap-2">
            <InboxIcon className="h-4 w-4" />
            <span>Inbox</span>
          </div>
          <span className="text-xs text-gray-600 dark:text-gray-300">{counts.inbox}</span>
        </div>

        <div
          role="button"
          tabIndex={0}
          onClick={() => onSelect('sent')}
          onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') onSelect('sent') }}
          className={[
            'flex items-center justify-between rounded-md px-2 py-2 cursor-pointer transition',
            isActive('sent') ? 'bg-white/80 dark:bg-white/10 ring-1 ring-[#f47b20]' : 'hover:bg-white/60 dark:hover:bg-white/5',
            dropTarget === 'sent' ? 'ring-2 ring-[#f47b20] bg-white/80 dark:bg-white/10' : ''
          ].join(' ')}
          {...makeDroppable('sent')}
        >
          <div className="flex items-center gap-2">
            <Send className="h-4 w-4" />
            <span>Sent</span>
          </div>
          <span className="text-xs text-gray-600 dark:text-gray-300">{counts.sent}</span>
        </div>

        <div
          role="button"
          tabIndex={0}
          onClick={() => onSelect('drafts')}
          onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') onSelect('drafts') }}
          className={[
            'flex items-center justify-between rounded-md px-2 py-2 cursor-pointer transition',
            isActive('drafts') ? 'bg-white/80 dark:bg-white/10 ring-1 ring-[#f47b20]' : 'hover:bg-white/60 dark:hover:bg-white/5',
            dropTarget === 'drafts' ? 'ring-2 ring-[#f47b20] bg-white/80 dark:bg-white/10' : ''
          ].join(' ')}
          {...makeDroppable('drafts')}
        >
          <div className="flex items-center gap-2">
            <FileText className="h-4 w-4" />
            <span>Drafts</span>
          </div>
          <span className="text-xs text-gray-600 dark:text-gray-300">{counts.drafts}</span>
        </div>

        <div
          role="button"
          tabIndex={0}
          onClick={() => onSelect('trash')}
          onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') onSelect('trash') }}
          className={[
            'flex items-center justify-between rounded-md px-2 py-2 cursor-pointer transition',
            isActive('trash') ? 'bg-white/80 dark:bg-white/10 ring-1 ring-[#f47b20]' : 'hover:bg-white/60 dark:hover:bg-white/5',
            dropTarget === 'trash' ? 'ring-2 ring-[#f47b20] bg-white/80 dark:bg-white/10' : ''
          ].join(' ')}
          {...makeDroppable('trash')}
        >
          <div className="flex items-center gap-2">
            <Trash2 className="h-4 w-4" />
            <span>Trash</span>
          </div>
          <span className="text-xs text-gray-600 dark:text-gray-300">{counts.trash}</span>
        </div>
      </div>

      {/* Custom folders */}
      <div className="mt-4">
        <div className="flex items-center justify-between mb-2">
          <div className="text-xs uppercase tracking-wide text-gray-600 dark:text-gray-300">My Folders</div>
          <div className="flex items-center gap-1">
            <Button variant="outline" size="sm" className="h-7 bg-transparent" onClick={() => setShowSyncRules(true)} title="Sync Rules">
              <Settings className="h-3.5 w-3.5 mr-1" />
              Sync Rules
            </Button>
            <Button variant="outline" size="sm" className="h-7 bg-transparent" onClick={() => setShowCreate(true)} title="Create Folder">
              <FolderPlus className="h-3.5 w-3.5 mr-1" />
              New
            </Button>
          </div>
        </div>

        {folders.length === 0 ? (
          <div className="text-xs text-gray-600 dark:text-gray-300">No folders yet. Create one.</div>
        ) : (
          <div className="space-y-1">
            {folders.map((f) => {
              const key: MailFolder = `custom:${f.id}`
              const activeRow = isActive(key)
              return (
                <div
                  key={f.id}
                  role="button"
                  tabIndex={0}
                  onClick={() => onSelect(key)}
                  onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') onSelect(key) }}
                  className={[
                    'flex items-center justify-between rounded-md px-2 py-2 cursor-pointer transition',
                    activeRow ? 'bg-white/80 dark:bg-white/10 ring-1 ring-[#f47b20]' : 'hover:bg-white/60 dark:hover:bg-white/5',
                    dropTarget === key ? 'ring-2 ring-[#f47b20] bg-white/80 dark:bg-white/10' : ''
                  ].join(' ')}
                  {...makeDroppable(key)}
                >
                  <div className="flex items-center gap-2">
                    <Circle className="h-3 w-3" style={{ color: f.color }} />
                    <span className="truncate">{f.name}</span>
                  </div>
                  <span className="text-xs text-gray-600 dark:text-gray-300">{customCounts[f.id] ?? 0}</span>
                </div>
              )
            })}
          </div>
        )}
      </div>

      {/* Modals */}
      <CreateFolderModal
        open={showCreate}
        onClose={() => setShowCreate(false)}
        onCreated={() => {
          // Refresh by forcing React to recalc (folders are read once). In a larger app, lift state up.
          setShowCreate(false)
          // no-op; counts update when parent reloads messages
        }}
      />
      {showSyncRules && <SyncRulesDialog open={showSyncRules} onClose={() => setShowSyncRules(false)} />}
    </div>
  )
}

export default MailSidebar
