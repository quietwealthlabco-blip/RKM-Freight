/**
 * MailViewer: Displays a selected mail item with subject, metadata, HTML body, and attachments.
 * - Metadata includes From and To for all folders (Inbox, Sent, Drafts, Trash).
 * - Renders HTML body safely via `dangerouslySetInnerHTML` (trusted local store).
 * - Header actions for Reply, Reply all, and Forward.
 * - Attachments panel:
 *    - Lists attachments with name and size.
 *    - Preview/Download:
 *       - Uses local base64 if available.
 *       - If attachment is from Gmail, fetches the content on demand via Gmail API.
 */

import React, { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card'
import type { MailItem, MailAttachment } from '../../services/mailStore'
import { Button } from '../ui/button'
import { Reply, ReplyAll, Forward, Paperclip, Download, Eye } from 'lucide-react'
import { useToast } from '../../hooks/use-toast'
import { fetchGmailAttachment } from '../../services/gmailApi'

/** Props for MailViewer */
interface MailViewerProps {
  /** The currently selected item, or null when none is selected */
  item: MailItem | null
  /** Trigger a reply compose with smart defaults */
  onReply?: () => void
  /** Trigger a reply-all compose with smart defaults */
  onReplyAll?: () => void
  /** Trigger a forward compose with smart defaults */
  onForward?: () => void
  /**
   * Optional Gmail client ID for fetching Gmail attachments on demand.
   * If omitted, Gmail attachment download will be disabled with a helpful notice.
   */
  gmailClientId?: string
}

/** Format date/time for header */
function formatDate(ts: number): string {
  try {
    return new Date(ts).toLocaleString(undefined, {
      weekday: 'short',
      year: 'numeric',
      month: 'short',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
    })
  } catch {
    return ''
  }
}

/** Convert byte size into a human-readable string */
function formatSize(size?: number): string {
  if (!size || size <= 0) return ''
  const units = ['B', 'KB', 'MB', 'GB']
  let i = 0
  let s = size
  while (s >= 1024 && i < units.length - 1) {
    s /= 1024
    i++
  }
  return `${s.toFixed(i === 0 ? 0 : 1)} ${units[i]}`
}

/** Create a Blob URL from base64 content */
function blobUrlFromBase64(base64: string, mimeType = 'application/octet-stream'): string {
  const byteChars = atob(base64)
  const byteNumbers = new Array(byteChars.length)
  for (let i = 0; i < byteChars.length; i++) {
    byteNumbers[i] = byteChars.charCodeAt(i)
  }
  const byteArray = new Uint8Array(byteNumbers)
  const blob = new Blob([byteArray], { type: mimeType })
  return URL.createObjectURL(blob)
}

/**
 * MailViewer component
 * - Subject at top, then From/To lines, then message body and attachments.
 * - Action buttons appear when an item is selected.
 */
const MailViewer: React.FC<MailViewerProps> = ({ item, onReply, onReplyAll, onForward, gmailClientId }) => {
  const { toast } = useToast()
  const [downloadingId, setDownloadingId] = useState<string | null>(null)

  if (!item) {
    return (
      <Card className="bg-white/60 dark:bg-white/5 border-white/20 dark:border-white/10">
        <CardHeader>
          <CardTitle className="text-[#1a1a38] dark:text-white">No message selected</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-700 dark:text-gray-300">
            Choose a message from the list to view its content.
          </p>
        </CardContent>
      </Card>
    )
  }

  /** Resolve data for an attachment:
   * - Use local `dataBase64` if present.
   * - If Gmail attachment: fetch content using Gmail API with messageId + attachmentId.
   */
  const resolveAttachmentData = async (att: MailAttachment): Promise<string> => {
    if (att.dataBase64) return att.dataBase64
    if (att.source === 'gmail') {
      if (!gmailClientId) {
        throw new Error('Connect Gmail in Settings to download attachments.')
      }
      if (!att.messageId || !att.id) {
        throw new Error('Attachment is missing Gmail identifiers (messageId/attachmentId).')
      }
      const { dataBase64 } = await fetchGmailAttachment(gmailClientId, att.messageId, att.id)
      return dataBase64
    }
    throw new Error('Attachment content is not available.')
  }

  /** Preview attachment in a new tab when possible */
  const handlePreview = async (att: MailAttachment) => {
    /**
     * Open a preview window synchronously to avoid blockers; inject a small HTML shell
     * that listens for a postMessage containing { base64, mimeType, fileName }.
     * The child then builds a Blob and renders it inside an iframe while exposing a Download link.
     */
    const previewWin = window.open('', '_blank', 'noopener,noreferrer')
    if (previewWin) {
      const html = `<!doctype html>
<html>
  <head>
    <meta charset="utf-8" />
    <title>Attachment Preview</title>
    <style>
      html, body { height: 100%; margin: 0; font-family: system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial, sans-serif; background: #0b1020; color: #fff; }
      .bar { display: flex; align-items: center; justify-content: space-between; padding: 10px 12px; background: #111638; border-bottom: 1px solid #ffffff22; }
      .btn { color: #fff; text-decoration: none; background: #f47b20; padding: 6px 10px; border-radius: 6px; font-size: 12px; }
      .name { font-weight: 600; font-size: 14px; }
      .wrap { height: calc(100% - 46px); }
      iframe { width: 100%; height: 100%; border: 0; background: #0b1020; }
      .muted { color: #cbd5e1; font-size: 12px; }
    </style>
  </head>
  <body>
    <div class="bar">
      <div>
        <div class="name" id="filename">Opening…</div>
        <div class="muted">If preview fails, use Download.</div>
      </div>
      <a id="download" class="btn" href="#" download>Download</a>
    </div>
    <div class="wrap">
      <iframe id="frame" title="Attachment preview"></iframe>
    </div>
    <script>
      (function () {
        function toBlobUrlFromBase64(base64, mime) {
          try {
            var byteStr = atob(base64);
            var len = byteStr.length;
            var bytes = new Uint8Array(len);
            for (var i = 0; i < len; i++) bytes[i] = byteStr.charCodeAt(i);
            var blob = new Blob([bytes], { type: mime || 'application/octet-stream' });
            return URL.createObjectURL(blob);
          } catch (e) {
            console.error('Blob build failed', e);
            return null;
          }
        }
        window.addEventListener('message', function (e) {
          var msg = e && e.data;
          if (!msg || msg.type !== 'PREVIEW_DATA') return;
          try {
            var url = toBlobUrlFromBase64(msg.base64, msg.mimeType);
            var iframe = document.getElementById('frame');
            var a = document.getElementById('download');
            var nameEl = document.getElementById('filename');
            if (nameEl && msg.fileName) nameEl.textContent = msg.fileName;
            if (url && iframe && a) {
              iframe.src = url;
              a.href = url;
              if (msg.fileName) a.download = msg.fileName;
            } else {
              document.body.innerHTML = '<p style="padding:16px;color:#fecaca">Failed to display preview. Please use Download.</p>';
            }
          } catch (err) {
            console.error(err);
            document.body.innerHTML = '<p style="padding:16px;color:#fecaca">Failed to display preview. Please use Download.</p>';
          }
        }, false);
      })();
    </script>
  </body>
</html>`;
      previewWin.document.open();
      previewWin.document.write(html);
      previewWin.document.close();
    }
    try {
      setDownloadingId(att.id || att.name);
      const data = await resolveAttachmentData(att);
      // Send data to the child window to render
      previewWin?.postMessage(
        {
          type: 'PREVIEW_DATA',
          base64: data,
          mimeType: att.type || 'application/octet-stream',
          fileName: att.name || 'attachment'
        },
        '*'
      );
    } catch (e: any) {
      if (previewWin && !previewWin.closed) {
        previewWin.document.body.innerHTML = '<p style="padding:16px;color:#fecaca">Failed to open preview.</p>';
      }
      toast({ title: 'Cannot preview attachment', description: e?.message || String(e), variant: 'destructive' });
    } finally {
      setDownloadingId(null);
    }
  }

  /** Download attachment via anchor */
  const handleDownload = async (att: MailAttachment) => {
    try {
      setDownloadingId(att.id || att.name)
      const data = await resolveAttachmentData(att)
      const url = blobUrlFromBase64(data, att.type || 'application/octet-stream')
      const a = document.createElement('a')
      a.href = url
      a.download = att.name || 'attachment'
      document.body.appendChild(a)
      a.click()
      a.remove()
      // Revoke shortly after to free memory
      setTimeout(() => URL.revokeObjectURL(url), 2000)
    } catch (e: any) {
      toast({ title: 'Download failed', description: e?.message || String(e), variant: 'destructive' })
    } finally {
      setDownloadingId(null)
    }
  }

  return (
    <Card className="h-full overflow-hidden bg-white/80 backdrop-blur-sm border-white/20 dark:bg-white/5 dark:border-white/10">
      <CardHeader>
        <div className="flex items-start justify-between gap-4">
          <div className="min-w-0">
            <CardTitle className="truncate text-[#1a1a38] dark:text-white">
              {item.subject || '(No subject)'}
            </CardTitle>
            <div className="mt-2 text-xs md:text-sm text-gray-700 dark:text-gray-300 space-y-1">
              <div>
                <span className="font-medium">From:</span> {item.from}
              </div>
              <div>
                <span className="font-medium">To:</span> {item.to.join(', ')}
              </div>
              <div className="text-gray-500">{formatDate(item.date)}</div>
            </div>
          </div>

          <div className="shrink-0 flex items-center gap-2">
            <Button
              variant="outline"
              className="bg-transparent h-8"
              onClick={onReply}
              title="Reply"
            >
              <Reply className="h-4 w-4 mr-2" />
              Reply
            </Button>
            <Button
              variant="outline"
              className="bg-transparent h-8"
              onClick={onReplyAll}
              title="Reply all"
            >
              <ReplyAll className="h-4 w-4 mr-2" />
              Reply all
            </Button>
            <Button
              variant="outline"
              className="bg-transparent h-8"
              onClick={onForward}
              title="Forward"
            >
              <Forward className="h-4 w-4 mr-2" />
              Forward
            </Button>
          </div>
        </div>
      </CardHeader>

      <CardContent>
        {/* Render HTML body; our content comes from local store or composed HTML */}
        <div
          className="prose prose-sm max-w-none dark:prose-invert prose-headings:mt-4 prose-p:my-2"
          dangerouslySetInnerHTML={{ __html: item.bodyHtml || '<p>(No content)</p>' }}
        />

        {/* Attachments */}
        {!!item.attachments?.length && (
          <div className="mt-6 border-t pt-4">
            <div className="flex items-center gap-2 text-sm font-medium text-[#1a1a38] dark:text-white mb-3">
              <Paperclip className="h-4 w-4" />
              {item.attachments.length} attachment{item.attachments.length > 1 ? 's' : ''}
            </div>

            <ul className="space-y-2">
              {item.attachments.map((att) => {
                const key = att.id || att.name
                const isBusy = downloadingId === key
                return (
                  <li
                    key={key}
                    className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 rounded-md border p-3 bg-white/60 dark:bg-white/5 border-white/30 dark:border-white/10"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <Paperclip className="h-4 w-4 text-gray-600 dark:text-gray-300 shrink-0" />
                      <div className="min-w-0">
                        <div className="truncate font-medium">{att.name}</div>
                        <div className="text-xs text-gray-600 dark:text-gray-400">
                          {att.type || 'file'} {att.size ? `• ${formatSize(att.size)}` : ''}
                          {att.source === 'gmail' && !gmailClientId ? ' • Connect Gmail to download' : ''}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <Button
                        variant="outline"
                        size="sm"
                        className="bg-transparent"
                        disabled={isBusy}
                        onClick={() => handlePreview(att)}
                        title="Preview"
                      >
                        <Eye className="h-3.5 w-3.5 mr-1" />
                        {isBusy ? 'Opening…' : 'Preview'}
                      </Button>

                      <Button
                        variant="outline"
                        size="sm"
                        className="bg-transparent"
                        disabled={isBusy}
                        onClick={() => handleDownload(att)}
                        title="Download"
                      >
                        <Download className="h-3.5 w-3.5 mr-1" />
                        {isBusy ? 'Downloading…' : 'Download'}
                      </Button>
                    </div>
                  </li>
                )
              })}
            </ul>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

export default MailViewer
