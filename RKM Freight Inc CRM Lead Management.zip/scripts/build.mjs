import * as esbuild from 'esbuild'
import pkg from 'esbuild-style-plugin'
const { stylePlugin } = pkg
import { rimraf } from 'rimraf'

// Clean dist directory
await rimraf('dist')

// Build configuration
const config = {
  entryPoints: ['src/main.tsx'],
  bundle: true,
  outdir: 'dist',
  plugins: [
    stylePlugin({
      postcss: {
        plugins: [require('tailwindcss'), require('autoprefixer')]
      }
    })
  ],
  loader: {
    '.png': 'file',
    '.jpg': 'file',
    '.svg': 'file'
  },
  assetNames: 'assets/[name]-[hash]',
  publicPath: '/',
  define: {
    'process.env.NODE_ENV': JSON.stringify(process.env.NODE_ENV || 'production')
  }
}

// Build for production
await esbuild.build(config)
console.log('Build completed successfully!')