import * as esbuild from 'esbuild'
import { rimraf } from 'rimraf'

// Clean dist directory
await rimraf('dist')

// Simple build configuration without style plugin
const config = {
  entryPoints: ['src/main.tsx'],
  bundle: true,
  outdir: 'dist',
  loader: {
    '.css': 'text',
    '.png': 'file',
    '.jpg': 'file',
    '.svg': 'file'
  },
  assetNames: 'assets/[name]-[hash]',
  publicPath: '/',
  define: {
    'process.env.NODE_ENV': JSON.stringify(process.env.NODE_ENV || 'production')
  }
}

// Build for production
await esbuild.build(config)
console.log('Build completed successfully!')